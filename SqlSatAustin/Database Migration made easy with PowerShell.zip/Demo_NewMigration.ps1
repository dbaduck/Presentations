﻿Install-Module dbatools # -AllowClobber

#$configCred = Get-Credential -Message "Enter the credentials for the source and destination SQL Server instances."

$migservers = @{
	Source = "SQLAG01"
	Destination = "SQLAG02"
}

$backup = @{
	BackupRestore = $true
	WithReplace = $true
	ReuseSourceFolderStructure = $true
	SharedPath = "\\sqlag01\sqlbackup"
}

$migration = @{
	Exclude = @("CentralManagementServer", "BackupDevices", "Audits", "ServerAuditSpecifications", "DataCollector")
	DisableJobsOnSource = $true
}

<# Exclude
Databases
Logins
AgentServer
Credentials
LinkedServers
SpConfigure
CentralManagementServer
DatabaseMail
SysDbUserObjects
SystemTriggers
BackupDevices
Audits
Endpoints
ExtendedEvents
PolicyManagement
ResourceGovernor
ServerAuditSpecifications
CustomErrors
DataCollector
StartupProcedures
AgentServerProperties
MasterCertificates
#>

Import-Module dbatools

#region Show Configuration

Set-DbatoolsInsecureConnection

# or
get-dbatoolsconfig

Set-DbaToolsConfig -FullName sql.connection.trustcert -Value $true -Register

$config = Connect-DbaInstance -SqlInstance $migservers.Source -SqlCredential $configCred -TrustServerCertificate

$cfgMaxServerMemory = $config.Configuration.MaxServerMemory.ConfigValue 
$cfgOptimizeAdHoc = $config.Configuration.OptimizeAdhocWorkloads.ConfigValue
$cfgCostThreshold = $config.Configuration.CostThresholdForParallelism.ConfigValue
$cfgMaxDOP = $config.Configuration.MaxDegreeOfParallelism.ConfigValue

$configvalues = "" | select "Max Server Memory", "Optimize Ad Hoc", "Cost Threshold", "Max DOP"
$configvalues."Max Server Memory" = $cfgMaxServerMemory
$configvalues."Optimize Ad Hoc" = $cfgOptimizeAdHoc
$configvalues."Cost Threshold" = $cfgCostThreshold
$configvalues."Max DOP" = $cfgMaxDOP

$configvalues | Format-Table -AutoSize

$config.JobServer | select Name, ServiceAccount | ft -AutoSize

$agent = $config.JobServer

$agent.AlertSystem | select @{ n = "FailsafeOperator"; e = { $_.FailsafeOperator } }

$agent.Operators | select Name, EmailAddress | ft -AutoSize

$agent.ProxyAccounts | select Name, CredentialName, CredentialIdentity | ft -AutoSize

$agent.Alerts | select Name, Severity | ft -AutoSize

$agent.Jobs | select Name | ft -AutoSize

$config.Logins | select Name | ft -AutoSize

$config.Databases

$config.Mail.Profiles
$config.Mail.Accounts

$agent.DatabaseMailProfile


#endregion


#region Starting Line

Copy-DbaSpConfigure @migservers -SourceSqlCredential $configCred -DestinationSqlCredential $configCred

Copy-DbaDatabase @migservers @backup -AllDatabases


Copy-DbaLogin @migservers -SourceSqlCredential $configCred -DestinationSqlCredential $configCred -force


Copy-DbaCredential @migservers -SourceSqlCredential $configCred -DestinationSqlCredential $configCred

Copy-DbaResourceGovernor @migservers

Copy-DbaLinkedServer @migservers

Copy-DbaPolicyManagement @migservers

Copy-DbaDbMail @migservers -SourceSqlCredential $configCred -DestinationSqlCredential $configCred


Copy-DbaAgentServer @migservers

Copy-DbaAgentProxy @migservers

Copy-DbaAgentOperator @migservers

Copy-DbaAgentJobCategory @migservers

Copy-DbaAgentJob @migservers

Copy-DbaAgentAlert @migservers -SourceSqlCredential $configCred -DestinationSqlCredential $configCred


#endregion









#region Ready Set Migrate!
# Ready Set GO!
Start-DbaMigration @migservers @backup @migration

#	-BackupRestore -SharedPath \\win19a\backups -ReuseSourceFolderStructure

#endregion



 






#region Cleanup
$cred = Get-Credential sa

$server = Connect-DbaInstance -ServerInstance WIN19C -SqlCredential $cred

$server.Configuration.MaxServerMemory.ConfigValue = $server.Configuration.MaxServerMemory.Maximum
$server.Configuration.OptimizeAdhocWorkloads.ConfigValue = 0
$server.Configuration.CostThresholdForParallelism.ConfigValue = 5
$server.Configuration.MaxDegreeOfParallelism.ConfigValue = 0

$server.Configuration.Alter()

$agent = $server.JobServer
$server.JobServer.AlertSystem.Failsafeoperator = ""
$server.JobServer.AlertSystem.Alter()

$agent.Operators[0].DropIfExists()

$agent.ProxyAccounts[0].DropIfExists()

$agent.Alerts[1].DropIfExists()
$agent.Alerts[0].DropIfExists()

$agent.Jobs["TestJob1"].DropIfExists()

$server.Credentials["TestCred1"].DropIfExists()
$server.Credentials["TestCred2"].DropIfExists()

$server.Logins["DBADUCK\cjmiller"].DropIfExists()
$server.Logins["sqllogin1"].Drop()
$server.Logins["sqllogin2"].Drop()

$server.Databases["pubs"].Drop()
$server.Databases["Northwind"].Drop()
$server.Databases["Adventureworks"].Drop()

if ($server.Mail.Profiles[0]) { $server.Mail.Profiles[0].Drop() }
if ($server.Mail.Accounts[0]) { $server.Mail.Accounts[0].Drop() }

$server.Configuration.DatabaseMailEnabled.ConfigValue = 0
$server.Configuration.Alter()

$server.JobServer.DatabaseMailProfile = ""
$server.JobServer.Alter()

#endregion



