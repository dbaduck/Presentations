$query = "SELECT Name, Id,4 as iterationid FROM sys.databases order by name"

$dt = Invoke-SqlCmd -ServerInstance BENDESK -Database master -Query $query -OutputAs DataTables

Write-SqlTableData -ServerInstance BENDESK -Database GatheringData -SchemaName dbo -TableName stats_Database2 -InputData $dt -Force

