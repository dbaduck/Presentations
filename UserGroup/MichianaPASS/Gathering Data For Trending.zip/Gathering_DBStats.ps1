﻿
Import-Module dbatools
Import-Module SqlServer

# Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=14.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91" -ErrorAction Stop
$smo = "Microsoft.SqlServer.Management.Smo"

# [Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

$server = New-Object -TypeName "$smo.Server" -Args BENDESK

<#
ID
Name
Size
DataSpaceUsage
IndexSpaceUsage
LastBackupDate
RecoveryModel
PageVerify
CompatibilityLevel
IsReadCommittedSnapshotOn

CREATE TABLE dbo.stats_Database (
	ID int,
	Name nvarchar(128),
	Size bigint,
	DataSpaceUsage decimal(18,2),
	IndexSpaceUsage decimal(18,2),
	LastBackupDate datetime2(0),
	RecoveryModel varchar(15),
	PageVerify varchar(20),
	CompatibilityLevel varchar(10),
	IsReadCommittedSnapshotOn bit,
	IterationId int NOT NULL
)

#>

# $IterationId = Get-StatsIterationId -ServerInstance localhost\s1 -DatabaseName

[System.Collections.ArrayList]$ary = @()

foreach ($db in ($server.Databases))
{
	$dbobj = "" | select ID, Name, Size, DataSpaceUsage, IndexSpaceUsage, LastBackupDate, RecoveryModel, PageVerify, CompatibilityLevel, IsReadCommittedSnapshotOn, IterationId
	
	$dbobj.ID = $db.ID
	$dbobj.Name = $db.Name
	$dbobj.Size = $db.Size
	$dbobj.DataSpaceUsage = $db.DataSpaceUsage
	$dbobj.IndexSpaceUsage = $db.IndexSpaceUsage
	$dbobj.LastBackupDAte = $db.LastBackupDate
	$dbobj.RecoveryModel = $db.RecoveryModel
	$dbobj.PageVerify = $db.PageVerify
	$dbobj.CompatibilityLevel = $db.CompatibilityLevel
	$dbobj.IsReadCommittedSnapshotOn = $db.IsReadCommittedSnapshotOn
	$dbobj.IterationId = 1
	
	[void]$ary.Add($dbobj)
}
$dt = ConvertTo-DbaDataTable -InputObject $ary

Write-SqlTableData -ServerInstance BENDESK -Databasename GatheringData -SchemaName dbo -TableName stats_Database -InputData $dt


