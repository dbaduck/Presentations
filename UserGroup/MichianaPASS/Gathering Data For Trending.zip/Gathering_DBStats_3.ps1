﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2017 v5.4.140
	 Created on:   	1/25/2018 5:53 PM
	 Created by:   	dbaduck
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$dt = New-Object -TypeName System.Data.DataTable -Args "DBStats"

$col1 = New-Object -TypeName System.Data.DataColumn -Args ID, ([Int])
$col2 = New-Object -TypeName System.Data.DataColumn -Args Name, ([String])
$col2.MaxLength = 256
$col3 = New-Object -TypeName System.Data.DataColumn -Args Size, ([Int64])
$col4 = New-Object -TypeName System.Data.DataColumn -Args DataSpaceUsage, ([decimal])
$col5 = New-Object -TypeName System.Data.DataColumn -Args IndexSpaceUsage, ([decimal])
$col6 = New-Object -TypeName System.Data.DataColumn -Args LastBackupDate, ([Datetime])
$col7 = New-Object -TypeName System.Data.DataColumn -Args RecoveryModel, ([string])
$col7.MaxLength = 15
$col8 = New-Object -TypeName System.Data.DataColumn -Args PageVerify, ([string])
$col8.MaxLength = 20
$col9 = New-Object -TypeName System.Data.DataColumn -Args CompatibilityLevel, ([string])
$col9.MaxLength = 10
$col10 = New-Object -TypeName System.Data.DataColumn -Args IsReadCommittedSnapshotOn, ([boolean])
$col11 = New-Object -TypeName System.Data.DataColumn -Args IterationId, ([Int])

$dt.Columns.Add($col1)
$dt.Columns.Add($col2)
$dt.Columns.Add($col3)
$dt.Columns.Add($col4)
$dt.Columns.Add($col5)
$dt.Columns.Add($col6)
$dt.Columns.Add($col7)
$dt.Columns.Add($col8)
$dt.Columns.Add($col9)
$dt.Columns.Add($col10)
$dt.Columns.Add($col11)

foreach ($db in ($server.Databases))
{
	$row = $dt.NewRow()
	
	$row.ID = $db.ID
	$row.Name = $db.Name
	$row.Size = $db.Size
	$row.DataSpaceUsage = $db.DataSpaceUsage
	$row.IndexSpaceUsage = $db.IndexSpaceUsage
	$row.LastBackupDate = $db.LastBackupDate
	$row.RecoveryModel = $db.RecoveryModel
	$row.PageVerify = $db.PageVerify
	$row.CompatibilityLevel = $db.CompatibilityLevel
	$row.IsReadCommittedSnapshotOn = $db.IsReadCommittedSnapshotOn
	$row.IterationId = 3
	
	$dt.Rows.Add($row)
}
Write-SqlTableData -ServerInstance BENDESK -DatabaseName GatheringData -SchemaName dbo -TableName stats_Database -InputData $dt

