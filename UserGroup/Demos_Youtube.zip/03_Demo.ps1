Backup-SqlDatabase -ServerInstance bendesk\instance1 -Database BEN


Backup-SqlDatabase -Database BEN

dir -force | backup-sqldatabase -CompressionOption On

dir sqlserver:\sql\bendesk\instance1\databases -force | Where name -ne 'tempdb' | Backup-SqlDatabase -CompressionOption On 


$results = Invoke-SqlCmd -ServerInstance bendesk\instance1 -Database BEN -Query "SELECT * FROM sys.indexes" -OutputAs DataTables
$results.gettype()

Write-SqlTableData -ServerInstance bendesk\instance1 -DatabaseName BEN -TableName "sysindexesBEN" -SchemaName dbo -InputData $results -force

get-dbccsqlperf -ServerInstance bendesk\instance1 -DatabaseName Ben

Get-DbaDbFile -SqlInstance bendesk\instance1 -Database Ben