
$server1 = "bendesk"
$server2 = "bendesk\instance1"


$bendesk = "bendesk"
$instance1 = "bendesk\instance1"
$instance2 = "bendesk\instance2"

$allservers = @($bendesk, $instance1, $instance2)

$instance1cred = Get-Credential 
Export-PsCredential -Path .\instance1.clixml -Credential $instance1cred

$newcred = Import-PsCredential -Path .\instance1.clixml

$newcred


$instance1wcred = @{SqlInstance=$instance1; SqlCredential=$newcred;Database="BEN"}
$instance2win = @{SqlInstance="$instance2"; Database="DemoTDE"}


$db = get-dbadatabase @instance1wcred

