$date = Get-Date -f "yyyyMMdd_HHmmss"
Start-Transcript -Path "E:\bin\logs\Transcript_Gather_$date.txt"

Import-Module dbatools
Import-Module SqlServer

# . c:\bin\Import-PsCredential.ps1

. E:\bin\StatsProcesses\GatherStats.ps1

$server01 = "" | Select Name, Credential
$server01.Name = "prod-sql-1"

$server02 = "" | Select Name, Credential
$server02.Name = "prod-sql-2"

$servers = @($server01, $server02)

$iter2 = Get-BmaIterationId -ServerInstance localhost -Database DBA

foreach($server in $servers)
{
	$server.Name
	"Get-BmaCPUByDatabase"
	Get-BmaCPUByDatabase -ServerInstance $server.Name -IterationId $iter2 -ReportSqlInstance localhost
	"Get-BmaCPUByTheMinute"
	Get-BmaCPUByTheMinute -ServerInstance $server.Name -IterationId $iter2 -ReportSqlInstance localhost

}

stop-transcript
