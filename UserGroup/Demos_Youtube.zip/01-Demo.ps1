<#
Modules:
dbatools
dbachecks
PoshRsJob
sqlserver -v5 required
importexcel
pendingreboot
export-pscredential
import-pscredential
psframework
#>
Install-Module dbatools 
Update-Module dbatools
Uninstall-Module
get-psrepository
Set-PsRepository -Name PSGallery -InstallationPolicy Trusted

Install-Module sqlserver -AllowClobber
Install-Module dbachecks -skippublishercheck

Get-Module -ListAvailable sql*
Get-Module -ListAvailable dbacheck*

$env:PsModulePath -split ";"

Install-Module ImportExcel, PoshRSJob, PendingReboot

Install-Module dbatools, sqlserver, ImportExcel, PoshRSJob, PendingReboot -AllowClobber

Get-Module -L dbatools  # etc.
Get-Alias

gmo -L dbatools

Get-Module -ListAvailable dbatools


Save-Module -Name dbatools -Path c:\modules

# xcopy deployment


$profile
$publicprofile = "$pshome\$(split-path $profile -leaf)"

get-psdrive
gci env:
dir variable:

notepad $publicprofile

new-item -path $publicprofile -itemtype file

"$pshome\$(split-path $profile -leaf)"

# x86
"$pshome\$(split-path $profile -leaf)"

# nuget download
<#
www.powershellgallery.com
Manual Download
Rename nupkg file to zip
Unzip and you have the module
#>

# Not about only using $profile
# you can dot source any file in Automations :-)

$servers

$dblist

Get-DbaRegServer

$serverlist = @()
$server = @{Name="sql01";SSPI="$true";}

$server1 = "" | Select Name, SSPI
$server1.Name = "sql01"
$server1.SSPI = $true


. .\Import-PsCredential.ps1
. .\Export-PsCredential.ps1


Start-Transcript -Path "c:\bin\Logs\Transcript_$(Get-Date -f 'yyyyMMdd_HHmmss').txt"

Stop-Transcript

Update-Help
Save-Help -DestinationPath C:\bin\HelpContent

Update-Help -SourcePath c:\bin\HelpContent

Get-Help Get-DbaDbFile -showwindow
Get-Help Get-DbaDbFile -Full



Get-History | Export-CliXml c:\bin\History.clixml

Import-CliXml -Path c:\bin\History.clixml | Add-History


$sql01 = "SQL01\instance"
$sql02 = "SQL02\instance"

$sqlservers = [System.Collections.ArrayList]@()

$sqlservers.add($sql01)
$sqlservers.add($sql02)

$sqlservers

$cred01 = Get-Credential
$cred01

$sql01 $cred01

$object = @{}
$object.Sql01 = "SQL01"
$object.SQL01Cred = $cred01

$object

$object = "" | Select-Object Name, Credential
$object.Name = "SQL01"
$object.Credential = $cred01

$object

if($object.Credential) {
    "Yes"
}
else { 
    "No"
}

$object.Credential
