# SMO
# Open module folder
# Open ps-formattypes
# show the GAC

Get-Command -Module dbatools
# gettype()
Get-DbaDbFile -Sqlinstance bendesk -Database sqlhelp
# Get-MyOsAssemblies

$vars = @{SqlInstance="bendesk"}
$vars2 = @{SqlInstance=@("bendesk","bendesk\instance1")}

$vars3 = @{SqlInstance="bendesk"; Database="sqlhelp"}

$bendesk = "bendesk"
$instance1 = "bendesk\instance1"
$instance2 = "bendesk\instance2"

$allservers = @($bendesk, $instance1, $instance2)

Get-DbaRegServer -SqlInstance bendesk -IncludeLocal

Get-DbaDatabase -SqlInstance $allservers -Database "DemoTDE" -ExcludeSystem | Select InstanceName, Name

$s = @{sqlinstance="bendesk"}
$d = @{Database="sqlhelp"}

Get-DbaDatabase @vars3
Get-DbaDatabase @vars -Database sqlhelp
Get-DbaDatabase @s @d

get-dbadbbackuphistory -sqlinstance "bendesk\instance1" -database "demotde" | restore-dbadatabase 

dir c:\bin\sqlbackup -filter *.bak -file | restore-dbadatabase -sqlinstance "bendesk\instance1" -withreplace

Restore-DbaDatabase -SqlInstance $instance1 

# show spreadsheet with object types


# sqlserver
Get-Command -Module SqlServer

$server= "BENDESK"
$instance = "instance1"
$db = "BEN"
$instance = "DEFAULT"

dir "SQLSERVER:\sql\$server\$instance\databases\$db\tables"

# Script objects
# drop objects - show smo and provider
# Mix modules, even from inside the provider

# Urn are great
$server.Databases["Ben"].urn.value

$db = $server.GetSmoObject("Server[@Name='$bendesk\INSTANCE1']/Database[@Name='$database']")


# look in other window
Invoke-DbcCheck -allchecks -SqlInstance bendesk -passthru | Update-DbcPowerBiDataSource


# ImportExcel
Get-DbaDatabase -SqlInstance bendesk -ExcludeSystem | Export-Excel -Path c:\bin\Excel_Databases.xlsx -WorksheetName Databases -Show

Get-DbaDatabase -SqlInstance bendesk\instance1 -ExcludeSystem | Export-Excel -Path c:\bin\Excel_Databases.xlsx -WorksheetName Databases2 -Show


