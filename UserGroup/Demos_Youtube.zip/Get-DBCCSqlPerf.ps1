
import-module sqlserver

function Get-DBCCSqlPerf {
	param (
		$ServerInstance,
		$DatabaseName,
		$Percentage = 0.0
	)

	$query = "DBCC SQLPERF(LOGSPACE)"

	$results = Invoke-Sqlcmd -ServerInstance $ServerInstance -Database master -Query $query
	if ($DatabaseName)
	{
		$results | Where { ($_."Database Name" -eq $DatabaseName) -and  }
	}
	else
	{
		$results
	}
}
