﻿# Demo 4

# Help Commands
Get-Help

Get-Help Get-MyObject

Get-Help Get-Service -Full

Get-Help Get-Service -ShowWindow

Update-Help

Save-Help -DestinationPath c:\Demos\PowerShellHelp
Update-Help -SourcePath c:\Demos\PowerShellHelp

Get-Help About_CommonParameters -ShowWindow
Get-Help about_Operator -ShowWindow
