﻿# Demo 3

# Variables
dir variable:

Get-Variable


# String Substitution
$firstName = "Ben"
$lastName = "Miller"

"$firstName $lastname"

# next level of substitution
$obj = "" | Select-Object FirstName, LastName

$obj.FirstName = "Ben"
$obj.LastName = "Miller"

"$obj.FirstName $obj.LastName"

"$($obj.FirstName) $($obj.LastName)"
"$(Get-Date -f `"yyyyMMdd`")"
"$(Get-Date -f ""yyyyMMdd"")"
"$(Get-Date -f 'yyyyMMdd')"

# Notice the syntax for embedding?
# Rules are as follows
# 1. When you need a property of an object
# 	 Use $( ) syntax as the $ means to substitute and the ( ) means to evaluate first then sub
# 2. If you use a $firstName ensure that if you need an _ (underscore)
#	 that you use the syntax above since the _ is a valid character in a variable name
"$firstName_$lastName"

"$($firstName)_$lastName"

# What if you want to use reserved characters
# String Literals are great for that. WYSIWYG
'$fisrtName $lastName'

# Or you can use 
"`$firstName `$lastName"

# Parameters with significant character
function Get-MyObject
{
	param (
		$ComputerName,
		$Component
	)
	
	Write-Output "$ComputerName $Component"
}

Get-MyObject -Comp "My Object"

Get-MyObject -Comp "My ComputerName" -Component "My Component"

Get-MyObject -Compu "My ComputerName" -Compo "My Component"

# You can see that it is pretty smart
# Best Practice: DO NOT use character significant in scripts
# 	one liners are ok because you are typing, but NOT in automations
function Get-MyObject
{
	param (
		[Parameter(Position = 2)]
		$ComputerName,
		[Parameter(Position = 1)]
		$Component
	)
	
	Write-Output "ComputerName: $ComputerName, Component: $Component"
	
}

Get-MyObject "ComputerName" "Component"

Get-MyObject "Component" "ComputerName"

Get-MyObject -ComputerName "ComputerName" -Component "Component"


# Show-Command is pretty cool deal
Show-Command -CommandName Get-Help

Show-Command -CommandName Get-DbaLogin


