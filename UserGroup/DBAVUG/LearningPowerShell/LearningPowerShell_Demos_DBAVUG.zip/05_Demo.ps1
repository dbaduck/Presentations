﻿# Demo 5

$sb = New-Object -TypeName System.Text.StringBuilder -Args 65535

$sb.AppendLine("Ben Miller")
$sb.AppendLine("Is Great")

$sb.ToString()

# Data Types
$str = "String"
$int = 1
$int64 = 192929939939933993
$strary = @("Ben","Miller")

$str.GetType()
$int.GetType()
$int64.GetType()
$strary.GetType()

$strary = "Ben", "Miller"
$strary.GetType()

$nonint = "1"
$nonint.GetType()

1 + "2"
"2" + 1
1 + "A"

# First one wins.
# This is important later


# Objects and Assemblies
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")

Add-Type -AssemblyName Microsoft.SqlServer.Smo

Add-Type -AssemblyName "Microsoft.SqlServer.Smo, 13.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$version = "14"
Add-Type -AssemblyName "Microsoft.SqlServer.Smo, $version.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

# Type Casting with .NET types
$str = [string]$int
$str.GetType()

$int.GetType()

[int]"A"


# Importing Commands
# Version 3.0 + has auto load which has side effects
# First use, it will load the first one it comes to.
Import-Module sqlserver

<#
	Install-Module
	Update-Module
	Find-Module
#>
# Dot Sourcing
. PathTofile

