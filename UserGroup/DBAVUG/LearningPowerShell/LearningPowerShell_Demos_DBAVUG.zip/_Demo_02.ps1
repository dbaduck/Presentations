# both are the same

$arraylist = [System.Collections.ArrayList]@()

# DECLARE @var int = 1
$arraylist = New-Object -TypeName System.Collections.ArrayList

# most .NET objects have output
$arraylist.Add("Hello")
$null = $arraylist.Add("Array 1")
# Other variants you will see
$arraylist.Add("Array 2") | Out-Null
$arraylist.Add("Array 3") > nul

"ben" + " j. " + "miller"
# StringBuilder as an alternative of Plussing (+) strings
$sb = New-Object -TypeName System.Text.StringBuilder -Args (64KB) # 65535
<#
this is a multiline comment
#>
$sb.Append("String")
$sb.AppendLine("String2")
$null = $sb.AppendFormat("String {0} {1}", 1, 2)

$sb.ToString()

# show performance
$ary = @()
measure-command { 1..10000 | foreach { $ary+=$_} }

$arylist = [System.Collections.ArrayList]@()
measure-command { 1..10000 | foreach { $null = $arylist.Add($_)}}

$string = ""
measure-command { 1..10000 | foreach { $string += "lkajsdflkjas;lfjda;lskjdflaksjdflkasjfdlk;jasdflk;jasdflk;jasdlfkjaslfkdjl;kajsfdlk;jasdfl;kjasf"}}

$sb = New-Object -TypeName System.text.StringBuilder -ArgumentList (2MB)
measure-command { 1..10000 | foreach { $null = $sb.AppendLine("lkajsdflkjas;lfjda;lskjdflaksjdflkasjfdlk;jasdflk;jasdflk;jasdlfkjaslfkdjl;kajsfdlk;jasdfl;kjasf")}}

$var = @{}
$var.firstname = "Ben"
$var
$var.Remove("firstname")
