﻿# SQLServer Module and Provider
Import-Module SqlServer
SQLSERVER:

dir
$Servername = "localhost"
$instancename = "DEFAULT"
$databasename = "DEMODB"
$schema = "dbo"
$tablename = "Accounts"

Test-Path "SQLSERVER:\sql\$servername\$instancename\databases\$databasename\tables\$schema.$tablename"
$table = Get-Item "SQLSERVER:\sql\$servername\$instancename\databases\$databasename\tables\$schema.$tablename"

$table.GetType()
$table | Get-Member | Out-GridView
$table.drop()

Test-Path c:\demos\bob.txt

Add-SqlLogin -LoginName "Ben" -LoginType SqlLogin -DefaultDatabase master -ServerInstance localhost -LoginPSCredential (get-credential)
$login = Get-SqlLogin -ServerInstance localhost -LoginName 'Ben'
$login.Enabled = $true
$login | Get-Member
$login.IsDisabled = $false

$login.Enable()

Convert-UrnToPath "Server[@Name='SQLDEMO1\INSTANCE1']/Database[@Name='DemoTDE']"

dir | Backup-SqlDatabase
Backup-SqlDatabase -BackupAction Database -CompressionOption On

Get-SqlAgent -ServerInstance localhost\instance1


Get-SqlAgentJob 


Get-SqlAgentJobHistory 


Get-SqlDatabase -serverinstance localhost\instance1  


Invoke-Sqlcmd  -Query "select name from sys.tables" -OutputAs DataTables -

$dt = Invoke-Sqlcmd -Query "select * from sys.tables" -OutputAs DataTables

$dt.gettype()

Write-SqlTableData -InputData $dt

Get-SqlLogin

Get-SqlErrorLog

Read-SqlTableData -ServerInstance sql01 -DatabaseName master -TableName databases -SchemaName sys -ColumnName "name","recovery_model_desc" `
    -ColumnOrder "recovery_model_desc" -ColumnOrderType ASC -TopN 100

$dt = Read-SqlTableData -ServerInstance sql01 -DatabaseName statsdb -TableName stats_Database -SchemaName dbo -ColumnName "ID","Name" `
    -ColumnOrder "ID" -ColumnOrderType DESC -TopN 10 -OutputAs DataTable





Import-Module dbatools

get-module

get-command -module dbatools | Measure-object 
get-command -module sqlserver | Measure-object 
get-command -module dbatools | out-gridview

$file = get-dbadbfile -sqlinstance localhost -database demodb
$file.gettype()
$file | Get-Member

$database = Get-DbaDAtabase -SqlInstance localhost -database Demodb
$database.gettype()

$splat = @{ SqlInstance = "localhost"; Database = "DEMODB" }
$splat.gettype()

Get-DbaDatabase @splat

$localhost = @{SqlInstance="localhost"}
$database = @{Database = "DEMODB"}

Get-DbaDatabase @localhost -Database DEMODB

Get-DbaDatabase @localhost @database

get-help save-module -showwindow

get-help add-sqllogin -ShowWindow