Get-Help

Update-Help

Save-Help -DestinationPath C:\PowerShellHelp -ErrorAction SilentlyContinue
Update-Help -SourcePath C:\PowerShellHelp

Invoke-Item C:\windows\system32\WindowsPowerShell\v1.0\en-US

Get-Help about_Comparison_Operators


Get-Help about_Comparison_Operators -ShowWindow

Get-Command *login*
Get-Command -Module dbatools -Name *login* # this will import the module for you

Get-DbaLogin
Get-Module

# Execution of command will load the module associated with it with Autoload
# Recommendation is to Import-Module the module you intend to use
# DBAs need to know that SQLPS is native on SQL Servers and can autoload

# Paths are used from top to bottom
$env:PSModulePath -split ';'

$UserId
# Next is the demo stuff
$UserId = 1 # dynamic so no type is necessary
$UserId.GetType()

'literal $UserId string' # is a literal string
"replacable string $UserId" # is a replacable string

# Parameters with NO commas

# Parameter Names with –Parametername

` # is an escape of the very next character only
  # or a special character like the $

@() # with parenthesis for an array declarative
(1,2,3).GetType() # turns into an array as well
$array = @(1,2,3) # also is an array declarative
$array+=4  # $array = $array + 4

@{firstname="Ben"; lastname="Miller"}  # is a hashtable
$hashtable = @{firstname="Ben"; lastname="Miller"}  # is a hashtable
$hashtable.middlename = "J."

"$hashtable.firstname $hashtable.middlename $hashtable.lastname"
"$($hashtable.firstname) $($hashtable.middlename) $($hashtable.lastname)"

# if statements and constructs
$i = 1
IF($i –GT 2) {
    Write-Host "something"
}
 
"A" -ceq "a"

$variable = @(1,2,3)
$variable | foreach { $_ }
$variable | ForEach-Object { $PSItem }

Foreach($item in $variable) {
    $item
}
# Aliases
get-alias
