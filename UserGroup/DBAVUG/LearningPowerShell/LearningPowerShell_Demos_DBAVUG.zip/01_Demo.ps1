﻿
#Notice which is the only one that is defined
Get-ExecutionPolicy -Scope CurrentUser
Get-ExecutionPolicy -Scope LocalMachine  
Get-ExecutionPolicy -Scope MachinePolicy
Get-ExecutionPolicy -Scope Process
Get-ExecutionPolicy -Scope UserPolicy

# You can get the list of them all in one
Get-ExecutionPolicy -List

# Let's change the Current User one
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned

# Transcripts are one of the best ways to capture learning sessions
Start-Transcript -Path c:\LearningPowerShell\Transcripts\t20211112.txt

# Let's get dynamic with the name of the file
# this date gets to the second level so you could create a transcript every second.
$date = "yyyyMMdd_HHmmss"
$filedate = get-date -f $date
Start-Transcript -Path "c:\Demos\PowerShellEssentials\Transcript_$filedate.txt"

# Profiles are powerful and can get crazy if you let them.
$PROFILE

# There is also a global one in $clspshome
"$PSHOME\$(Split-Path $PROFILE -Leaf)"

# This is an example of a Profile Prompt. See what it does.


# start of my profile
$date = "yyyyMMdd_HHmmss"
$filedate = get-date -f $date
Start-Transcript -Path "c:\Demos\PowerShellEssentials\Transcript_$filedate.txt"
function prompt
{
	Write-Host "[" -NoNewline
	Write-Host (Get-Date -Format "HH:mm:ss") -ForegroundColor Gray -NoNewline
	Write-Host "][" -NoNewline
	$history = (Get-History)[-1]
	if (([System.Management.Automation.PSTypeName]'Sqlcollaborative.Dbatools.Utility.DbaTimeSpanPretty').Type)
	{
		Write-Host ([Sqlcollaborative.Dbatools.Utility.DbaTimeSpanPretty]($history.EndExecutionTime - $history.StartExecutionTime)) -ForegroundColor Gray -NoNewline
	}
	else
	{
		Write-Host ($history.EndExecutionTime - $history.StartExecutionTime) -ForegroundColor Gray -NoNewline
	}
	Write-Host "][" -NoNewline
	Write-Host "NP:$($NestedPromptLevel)" -ForegroundColor Gray -NoNewline
	Write-Host "]"
	Write-Host " $($executionContext.SessionState.Path.CurrentLocation.ProviderPath)" -NoNewline
	"> "
}

function bye {
	Stop-Transcript
	Exit
}
# end profile

# Let's take a look at the folder structure that you need to be familiar with
# There is a Modules folder in a few places and you need to know what it means.
$env:PSModulePath -split ";"

dir "$PSHOME\Modules"

