. "$(split-path $profile)\Microsoft.PowerShell_profile.ps1"
