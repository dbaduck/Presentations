

get-module -Listavailable dbatools
Get-Alias
Install-Module dbatools
install-module SqlServer

Import-Module dbatools
ipmo dbatools
ipmo SqlServer

Get-PSRepository

$cred = get-credential

$server = Connect-DbaInstance -SqlInstance WIN19B -SqlCredential $cred 

$server.GetType()

$db = Get-DbaDatabase -SqlInstance WIN19B -Database "master","DEMODB"
$db = $server | Get-DbaDatabase -Database "master","DEMODB"
$db

$table = get-dbaDbTable -SqlInstance $server -Database "DEMODB" -Table "dbo.Table1" 

$file = Get-DbaDbFile -SqlInstance $server -Database DEMODB

$table.Drop()

$table.Indexes[0].Drop()

$dbs = Get-DbaDatabase -SqlInstance $server -ExcludeSystem -ExcludeDatabase "SMO_DB10","SMO_DB9"
$dbs = Get-DbaDatabase -SqlInstance $server -Database "SMO_DB4"

$dbs.Drop()

$server.KillAllProcesses("SMO_DB4")
$server.KillAllProcesses("SMO_DB4")
$dbs.Drop()

$server.KillDatabase("SMO_DB3")

Backup-DbaDatabase -SqlInstance $server -Database DEMODB -CompressBackup 

Get-DbaBackupHistory -SqlInstance $server -Database "DEMODB" -Since (get-date "6/9/2019").AddHours(-2)

Get-DbaBackupHistory -SqlInstance $server -Database "DEMODB" -LastFull | 
        Restore-DbaDatabase -SqlInstance $server -TrustDbBackupHistory

$bh = @{
    "Database" = "DEMODB"
    "SqlInstance" = $server
    "LastFull" = $true
}

Get-DbaBackupHistory @bh -SqlInstance $server -LastFull | 
        Restore-DbaDatabase -SqlInstance $server -TrustDbBackupHistory

$bh.Database = "SMO_DB2"
Get-DbaBackupHistory @bh



ipmo sqlserver

get-command -module sqlserver | Where CommandType -eq "Cmdlet" | Measure-Object 

$cred = Get-Credential
$history = Get-SqlBackupHistory -ServerInstance WIN19B -Database DEMODB -Credential $cred -BackupType Database | 
        Select -first 1

$server = Get-SqlInstance -ServerInstance WIN19B -Credential $cred
$history | Restore-SqlDatabase -ServerInstance $server -Database DEMODB -RestoreAction Database -ReplaceDatabase

get-psdrive