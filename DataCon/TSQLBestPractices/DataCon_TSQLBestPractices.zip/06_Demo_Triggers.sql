/*
CREATE TABLE dbo.TriggerTest (
	id int not null identity(1,1),
	name varchar(120)
)

CREATE OR ALTER TRIGGER dbo.tr_Update on dbo.TriggerTest
after update
AS
begin
	PRINT 'I am in the trigger'
	SELECT COUNT(*) FROM inserted
END
*/

insert into dbo.triggertest (name) values ('ben')
update dbo.triggertest set name = 'bob'
where name = 'curt'
