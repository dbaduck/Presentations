USE DEMODB
GO

/*
CREATE TABLE dbo.Table9 (
	ID INT NOT NULL IDENTITY(1,1),
	Name varchar(20) NOT NULL
)
CREATE TABLE dbo.Table10 (
	ID INT NOT NULL IDENTITY(1,1),
	Name varchar(20) NOT NULL
)

CREATE TRIGGER dbo.tr_Table9_Insert
ON dbo.Table9 
FOR INSERT
AS
BEGIN 
	INSERT INTO dbo.Table10 (Name)
	VALUES ('Ben')
END

truncate table dbo.Table9
truncate table dbo.Table10

DBCC CHECKIDENT('Table9', RESEED, 100000)
DBCC CHECKIDENT('Table10', RESEED, 200000)
*/
INSERT INTO dbo.Table9 (Name)
VALUES ('Ben')

/* This returns the value of the current IDENTITY 
** without regard to current SCOPE of the statement
** causing the IDENTITY to increment
*/
SELECT @@IDENTITY 

/* This returns the value of the current IDENTITY
** keeping in mind the SCOPE of the statement
** that is causing the increment of IDENTITY
*/
SELECT SCOPE_IDENTITY()

/* Turn on setting to enable inserting
** Custom IDENTITY value
*/
SET IDENTITY_INSERT dbo.Table10 ON

INSERT INTO dbo.Table10 (ID,Name)
VALUES (200010, 'Jerry2')

SELECT SCOPE_IDENTITY()

INSERT INTO dbo.Table10 (ID,Name)
VALUES (5, 'Clint')

select * from dbo.TAble10

/*
** Be sure to turn it off
*/
SET IDENTITY_INSERT dbo.Table10 OFF

/*
** Picks back up where it left off
*/
DELETE dbo.Table10
WHERE ID >= 200010

INSERT INTO dbo.Table10 (Name)
VALUES ('Seinfeld2')

SELECT SCOPE_IDENTITY()

SELECT *
FROM dbo.Table10

SET IDENTITY_INSERT dbo.Table10 ON
INSERT INTO dbo.Table10 (ID, Name)
VALUES (6, 'Foobar')
SET IDENTITY_INSERT dbo.Table10 OFF

INSERT INTO dbo.Table10 (Name)
VALUES ('Foobar')

SELECT *
FROM dbo.Table10

DELETE dbo.Table10
WHERE ID >= 6

DBCC CHECKIDENT('Table10')

/* 
** This will clear the seed and start 
** from where the definition started
*/
/*
TRUNCATE TABLE dbo.Table10

INSERT INTO dbo.Table10 (Name)
VALUES ('Foobar')

SELECT SCOPE_IDENTITY()
*/