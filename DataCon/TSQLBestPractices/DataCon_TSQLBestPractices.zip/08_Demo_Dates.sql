-- Retrieved from Aaron Bertrand's example
-- https://www.mssqltips.com/sqlservertip/5206/sql-server-datetime-best-practices/?utm_source=AaronBertrand
-- Avoid Regional Date Formats

SET LANGUAGE us_english;
SELECT CONVERT(datetime, '02/09/2017');
SELECT CONVERT(datetime, '2017-02-09');
SELECT CONVERT(datetime, '2017-02-09 01:23:45.678');


SET LANGUAGE fran�ais;
SELECT CONVERT(datetime, '02/09/2017');
SELECT CONVERT(datetime, '2017-02-09');
SELECT CONVERT(datetime, '2017-02-09 01:23:45.678');   

SET LANGUAGE fran�ais;
SELECT CONVERT(datetime, '20170209');
SELECT CONVERT(datetime, '2017-02-09T01:23:45.678');
SELECT CONVERT(datetime, '20170209 01:23:45.678');   

SET LANGUAGE english;
SELECT CONVERT(datetime, '20170209');
SELECT CONVERT(datetime, '2017-02-09T01:23:45.678');
SELECT CONVERT(datetime, '20170209 01:23:45.678');   


-- Christmas 2017 falls on a Monday 
SELECT [w] = DATEPART(w, '20171225'),   --  (a) 53   (b) 2      (c) 1
       [y] = DATEPART(y, '20171225');   --  (a) 17   (b) 2017   (c) 359   

SELECT GETDATE()-1, GETDATE()+1, GETDATE()-7;


DECLARE @date datetime = GETDATE()
SELECT @date + 4
GO

DECLARE @date date = GETDATE()
SELECT @date + 4
GO

DECLARE @date datetime2(3) = GETDATE()
SELECT @date + 4
GO


DECLARE @date datetime = GETDATE()
SELECT DATEADD(day, 4, @date)
GO

DECLARE @date date = GETDATE()
SELECT DATEADD(day, 4, @date)
GO

DECLARE @date datetime2(3) = GETDATE()
SELECT DATEADD(day, 4, @date)
GO

SELECT DATEADD(MILLISECOND, -3, '20170301');   -- 20170228 23:59:59.997   

-- Using BETWEEN makes it difficult to use Dates

CREATE TABLE dbo.SalesOrders
(
  OrderDate datetime2
);
INSERT dbo.SalesOrders(OrderDate)    -- 6 rows in February, 1 row in March
  VALUES ('20170201 00:00:00.000'), 
         ('20170211 01:00:00.000'),('20170219 00:00:00.000'),
         ('20170228 04:00:00.000'),('20170228 13:00:27.000'),
         ('20170228 23:59:59.999'),('20170301 00:00:00.000');
GO
CREATE PROCEDURE dbo.GetMonthlyOrders
  @start             date,
  @end_datetime      datetime,
  @end_smalldatetime smalldatetime,
  @end_date          date
AS
BEGIN
  SET NOCOUNT ON;
  SELECT 
    [datetime] = (SELECT COUNT(*) FROM dbo.SalesOrders
      WHERE OrderDate BETWEEN @start AND @end_datetime),
    [smalldatetime] = (SELECT COUNT(*) FROM dbo.SalesOrders
      WHERE OrderDate BETWEEN @start AND @end_smalldatetime),
    [date] = (SELECT COUNT(*) FROM dbo.SalesOrders
      WHERE OrderDate BETWEEN @start AND @end_date);
END
GO
DECLARE 
  @start datetime = '20170201',
  @end   datetime = DATEADD(MILLISECOND, -3, '20170301');

EXEC dbo.GetMonthlyOrders
  @start             = @start,
  @end_datetime      = @end,
  @end_smalldatetime = @end,
  @end_date          = @end;   


GO
CREATE PROCEDURE dbo.GetMonthlyOrders2
  @month date
AS
BEGIN
  SET NOCOUNT ON;
  -- ensure always at start of month
  SET @month = DATEFROMPARTS(YEAR(@month), MONTH(@month), 1);

  SELECT [one param] = COUNT(*) 
      FROM dbo.SalesOrders
      WHERE OrderDate >= @month
        AND OrderDate <  DATEADD(MONTH, 1, @month);
END
GO

-- can pass any date/time within the desired month
DECLARE @month datetime = '20170227 02:34:12.762';
EXEC dbo.GetMonthlyOrders2 @month = @month;  

