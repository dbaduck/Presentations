/*
Contact Information:
Ben Miller
ben@benmiller.net
@DBAduck
*/
R

/*
USE [master]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [testlogin]    Script Date: 3/6/2014 6:37:15 AM ******/
CREATE LOGIN [testlogin] WITH PASSWORD=N'Password1', DEFAULT_DATABASE=[master], 
		CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

USE [DemoDB]
GO
/****** Object:  User [testlogin]    Script Date: 3/6/2014 6:38:17 AM ******/
CREATE USER [testlogin] FOR LOGIN [testlogin] WITH DEFAULT_SCHEMA=[dba]
GO

CREATE TABLE dbo.TestSchema (
	field1 VARCHAR(10)
)
GO
CREATE SCHEMA dba AUTHORIZATION [dbo]
GO
CREATE TABLE dba.TestSchema (
	field2 varchar(10)
)
insert into dbo.TestSchema values ('dbo')
insert into dba.TestSchema values ('dba')
grant select on dba.TestSchema to testlogin

GO
*/

-- Which table do I get?

SELECT *
FROM TestSchema

-- Lets try as testlogin
EXECUTE AS USER = 'testlogin'

select SUSER_NAME()

GO
SELECT *
FROM TestSchema
GO
REVERT
GO
SELECT *
FROM dba.TestSchema


SELECT *
FROM TestSchema
