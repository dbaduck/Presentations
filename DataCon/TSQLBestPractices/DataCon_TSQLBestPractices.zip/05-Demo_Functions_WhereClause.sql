
set statistics io on
/*
DROP INDEX IX_CreationYear ON dbo.Users
CREATE INDEX IX_OwnerUserId ON dbo.Posts (OwnerUserId)
*/
/* functions in where clause */
SELECT	
	COUNT(*)
FROM dbo.Users
WHERE YEAR(CreationDate) = 2018

/* now let's remove the function */
DECLARE @yearbegin datetime = '20180101', @yearend datetime = '20190101'

SELECT 
	COUNT(*)
FROM dbo.Users
WHERE CreationDate >= @yearbegin AND CreationDate < @yearend

/* What could we do if this is a common query? */
ALTER TABLE dbo.Users ADD CreationYear AS YEAR(CreationDate) PERSISTED

/* Add an index because it is persisted */
CREATE INDEX IX_CreationYear ON dbo.Users ([CreationYear])

/* functions in where clause */
/* Now let's try again */
SELECT	
	COUNT(*)
FROM dbo.Users
WHERE YEAR(CreationDate) = 2018


/* IN, EXISTS, NOT EXISTS, NOT IN */
CREATE INDEX IX_Location ON dbo.Users (Location) WITH (SORT_IN_TEMPDB=ON)

SELECT 
	COUNT(*)
FROM dbo.Users U
WHERE U.Location IN ('Philadelphia, PA', 'Austin, TX')

SELECT 
	COUNT(*)
FROM dbo.Users U
WHERE U.Location IN (SELECT [Location] FROM dbo.Users)

SELECT 
	COUNT(*)
FROM dbo.Users U
WHERE [U].[Location] IN (SELECT Location FROM dbo.Users) -- T WHERE T.Location = U.Location)

SELECT COUNT(*)
FROM dbo.Users U
WHERE U.Location NOT IN (SELECT Location FROM dbo.Users)

SELECT COUNT(*)
FROM dbo.Users U
WHERE NOT EXISTS (SELECT 1 FROM dbo.Users T WHERE T.[Location] = U.[Location])

SELECT 
	COUNT(*)
FROM dbo.Users U
WHERE EXISTS (SELECT 1 FROM dbo.Users T WHERE T.[Location] = [U].[Location])
