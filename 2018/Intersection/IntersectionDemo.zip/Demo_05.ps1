﻿# Getting Data out of SQL

# Dbatools
$data = Invoke-DbaQuery -SqlInstance $ServerInstance -Query "select database_id, name from sys.databases" -Database master `
        -QueryTimeout 0 -As DataTable

# SqlServer
$data = Invoke-SqlCmd -ServerInstance $ServerInstance -Database master -Query "select database_id,name from sys.databases" `
    -QueryTimeout 0 -OutputAs DataTables

# Putting data in SQL

<#
    CREATE TABLE dbo.TestDba (id int, name varchar(256))
    CREATE TABLE dbo.TestSql (id int, name varchar(256))
#>
# Dbatools
Write-DbaDataTable -SqlInstance $ServerInstance -Database DEMO `
        -Table TestDba -Schema dbo -InputObject $data -AutoCreateTable

# SqlServer
Write-SqlTableData -ServerInstance $ServerInstance -DatabaseName DEMO `
        -TableName TestSql -SchemaName dbo -InputData $data -Force

# Let's cleanup
$table = Get-DbaDbTable -SqlInstance $ServerInstance -Database DEMO -Table "dbo.TestDba" 
$table.Drop()

$table = Get-DbaDbTable -SqlInstance $ServerInstance -Database DEMO -Table "dbo.TestSql"
$table.Drop()


