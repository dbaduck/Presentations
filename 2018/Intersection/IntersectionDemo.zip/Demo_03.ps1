﻿# Execution

Import-Module dbatools

# Somewhat equivalent to 
# $instance = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -Args WIN16SQL1
$instance = Connect-DbaInstance -SqlInstance "WIN16SQL1" 

# Properties
$instance.Name

# Default View
$instance

# Many things inside the Server just like the other before
$instance | Get-Member

# Let's add a login
Add-SqlLogin -LoginType SqlLogin `
    -DefaultDatabase master -Enable -GrantConnectSql `
    -ServerInstance WIN16SQL1 -LoginPSCredential (get-credential)

# Let's add a SQLLogin
Add-SqlLogin -LoginName "DBADUCK\TestUser" -LoginType WindowsUser `
    -DefaultDatabase master -Enable -GrantConnectSql `
    -ServerInstance WIN16SQL1

# Let's see it a different way using Splatting.
$cred = Get-Credential

# Let's use splatting
$parm = @{
    LoginName="ben2"
    LoginType="SqlLogin"
    DefaultDatabase="master"
    Enable=$true
    GrantConnectSql=$true
    ServerInstance="WIN16SQL1"
    LoginPSCredential=$cred
}

Add-SqlLogin @parm

# Let's get some diskspace
Get-DbaDiskSpace -ComputerName WIN16SQL2
Get-DbaDiskSpace -ComputerName WIN16SQL1,WIN16SQL2
Get-DbaDiskSpace WIN16SQL1,WIN16SQL2



