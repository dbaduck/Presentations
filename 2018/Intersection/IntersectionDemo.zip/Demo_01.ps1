# First and foremost

#Profile stuff
# Open $Profile

$profile

$host

$pshome
