﻿$ServerInstance = "WIN16SQL1"
$Database = "WideWorldImporters"

Connect-DbaInstance -SqlInstance $ServerInstance

Get-DbaDatabase -SqlInstance $ServerInstance -Database $Database
Get-DbaDatabase -SqlInstance $ServerInstance -ExcludeSystem
Get-DbaDatabase -SqlInstance $ServerInstance -ExcludeUser
Get-DbaDatabase -SqlInstance $ServerInstance

# as exampled in previous demo
Get-DbaDiskSpace -ComputerName WIN16SQL2
Get-DbaDiskSpace -ComputerName WIN16SQL1,WIN16SQL2
Get-DbaDiskSpace WIN16SQL1,WIN16SQL2

Get-DbaErrorLog -SqlInstance $ServerInstance -LogNumber 1
Get-DbaErrorLog -SqlInstance $ServerInstance -Text "shutdown" -LogNumber 0
Get-DbaErrorLog -SqlInstance $ServerInstance -Text "shutdown" -LogNumber 1
Get-DbaErrorLog -SqlInstance $ServerInstance -Source Logon -LogNumber 0
Get-DbaErrorLog -SqlInstance $ServerInstance -Text "shutdown" -LogNumber 1 -After "2018-11-30 00:00:00"

# Last good checkdb
Get-DbaLastGoodCheckDb -SqlInstance $ServerInstance -Database $Database 
Get-DbaLastGoodCheckDb -SqlInstance $ServerInstance -Database "master" 

# Get some Server Logins
Get-DbaLogin -SqlInstance $ServerInstance
$login = Get-DbaLogin -SqlInstance $ServerInstance -Login "ben"

# Get a configuration Item
Get-DbaMaxMemory -SqlInstance $ServerInstance
Set-DbaMaxMemory -SqlInstance $ServerInstance -Max 4096
Get-DbaMaxMemory -SqlInstance $ServerInstance

Test-DbaMaxMemory -SqlInstance $ServerInstance

# Look at another item
Get-DbaServerProtocol -ComputerName WIN16SQL1

# before enabling tcp
Get-DbaTcpPort -SqlInstance WIN16SQL1
# after enabling tcp
Get-DbaTcpPort -SqlInstance WIN16SQL1

# Let's see some sp_configure values
Get-DbaSpConfigure -SqlInstance $ServerInstance 
Get-DbaSpConfigure -SqlInstance $ServerInstance -Name MaxServerMemory

Set-DbaSpConfigure -SqlInstance $ServerInstance -Name MaxServerMemory -Value 5120

# Something to be aware of
# Some return data and others objects. Know which is which.
Get-DbaLogin -SqlInstance $ServerInstance -Login ben
Get-DbaLogin -SqlInstance $ServerInstance -Login ben | gm

Get-DbaDatabaseFile -SqlInstance $ServerInstance -Database WideWorldImporters
Get-DbaDbFile -SqlInstance $ServerInstance -Database WideWorldImporters

Get-DbaDbFile -SqlInstance $ServerInstance -Database WideWorldImporters | gm

