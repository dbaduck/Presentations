﻿# Execution

Import-Module dbatools
Get-Module -ListAvailable sql*

Import-module "C:\Program Files\WindowsPowerShell\Modules\SqlServer"

# Somewhat equivalent to 
# $instance = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Server -Args WIN16SQL1
$instance = Connect-DbaInstance -SqlInstance "WIN16SQL1" 

# Properties
$instance.Name

# Default View
$instance

# Many things inside the Server just like the other before
$instance | Get-Member

New-DbaLogin -SqlInstance "WIN16SQL1","WIN16SQL2" -Login "Jed" -SecurePassword (Get-Credential).Password


# Let's see it a different way using Splatting.
$cred = Get-Credential

# Let's use splatting
$parm = @{
    Login="George"
    SqlInstance=@("WIN16SQL1","WIN16SQL2")
    SecurePassword=$cred.Password
}

New-DbaLogin @parm

$parm = @{
    Login="Junior"
    SqlInstance=@("WIN16SQL1","WIN16SQL2")
    SecurePassword=$cred.Password
}

New-DbaLogin @parm


$serverlist = @("WIN16SQL1","WIN16SQL2")
$userlist = "Bob","Bill","Curt"

foreach($server in $serverlist) {
    $parm.SqlInstance = $server
    foreach($user in $userlist) {
        $parm.Login = $user
        New-DbaLogin @parm
    }
}

$parm = @{
    Login="Junior"
}
$parm2 = @{
    SqlInstance=@("WIN16SQL1","WIN16SQL2")
    SecurePassword=$cred.Password
}

New-DbaLogin @parm @parm2


New-DbaLogin -SqlInstance $parm.SqlInstance

# Let's get some diskspace
Get-DbaDiskSpace -ComputerName WIN16SQL2
Get-DbaDiskSpace -ComputerName WIN16SQL1,WIN16SQL2
Get-DbaDiskSpace WIN16SQL1,WIN16SQL2 | format-list *
Get-DbaDiskSpace -Unit TB -ComputerName WIN16SQL1,WIN16SQL2

get-command -Name get-dbadiskspace


