﻿function Get-DatabaseId {
    param (
        $ServerInstance,
        $Database
    )

    $smo = "Microsoft.SqlServer.Management.Smo"

    $server = New-Object -TypeName "$smo.Server" -Args $ServerInstance

    $db = $server.Databases["$Database"]

    return $db.ID
}

function Get-TableId {
    param (
        $ServerInstance,
        $Database,
        $Table,
        $Schema = "dbo",
        [Microsoft.SqlServer.Management.Smo.Database]$InputObject 
    )

    $smo = "Microsoft.SqlServer.Management.Smo"

    if($InputObject) {
        $tb = $InputObject.Tables["$Table","$Schema"]
        return $tb.ID
    }
    else {

        $server = New-Object -TypeName "$smo.Server" -Args $ServerInstance

        $db = $server.Databases["$Database"]
        $tb = $db.Tables["$Table", "$Schema"]
        return $tb.Id
    }
   
}

