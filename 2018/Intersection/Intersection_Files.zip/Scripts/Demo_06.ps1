﻿# Let's add a login
Add-SqlLogin -LoginType SqlLogin `
    -DefaultDatabase master -Enable -GrantConnectSql `
    -ServerInstance WIN16SQL1 -LoginPSCredential (get-credential)

# Let's add a SQLLogin
Add-SqlLogin -LoginName "DBADUCK\TestUser" -LoginType WindowsUser `
    -DefaultDatabase master -Enable -GrantConnectSql `
    -ServerInstance WIN16SQL1


$parm = @{
    LoginName="ben2"
    LoginType="SqlLogin"
    DefaultDatabase="master"
    Enable=$true
    GrantConnectSql=$true
    ServerInstance="WIN16SQL1"
    LoginPSCredential=$cred
}
