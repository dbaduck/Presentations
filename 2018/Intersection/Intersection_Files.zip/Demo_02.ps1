﻿# Demo 2
# SMO Coding
# Import-Module sqlserver

Add-Type -AssemblyName "Microsoft.SqlServer.Smo, Version=14.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91"

$smo = "Microsoft.SqlServer.Management.Smo"
$ServerInstance = "WIN16SQL1"

$server = New-Object -TypeName "$smo.Server" -Args $ServerInstance

$server.Name
$server.Roles

$Database = "WideWorldImporters"

$db = $server.Databases["$Database"]
$table = $db.Tables["PurchaseOrders","Purchasing"]

# Break 1

$server | Get-Member

$db | Get-Member
$db.name = "Ben"
$db.Rename("WideWorldImporters")
$db.Alter()

$table | Get-Member

$server.Configuration.MaxServerMemory
$server.Configuration.MaxServerMemory.ConfigValue = 2048
$server.Configuration.Refresh()
$server.alter()

$db.Name
$db.Id

$table.Id
$table.Name
$table.Schema

# Methods
$db.RecoveryModel = [Microsoft.SqlServer.Management.Smo.RecoveryModel]::Simple
$db.RecoveryModel = "Simple"
$db.TargetRecoveryTime = 60
$db.Alter()


# Dot-Sourcing
. C:\Demos\PreCon_Intersections\Functions.ps1

Get-DatabaseId -ServerInstance WIN16SQL1 -Database "WideWorldImporters"

Get-TableId -InputObject $db -Table "PurchaseOrders" -Schema "Purchasing"

Get-TableId -ServerInstance WIN16SQL1 -Database WideWorldImporters -Table "PurchaseOrders" -Schema "Purchasing"

# Let's do a module instead

# Look at TestModule.psd1
# Look at TestModule.psm1

# They go in a folder called TestModule in the WindowsPowerShell\Modules directory

Import-Module TestModule




