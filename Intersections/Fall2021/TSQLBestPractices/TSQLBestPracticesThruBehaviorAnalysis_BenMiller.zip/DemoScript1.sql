/*

CREATE DATABASE DEMO1
GO
CREATE TABLE dbo.Table1 (
	id int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	name varchar(20) not null
)

GO
CREATE TABLE dbo.Table1_a (
	id int NOT NULL IDENTITY(2001,1) PRIMARY KEY,
	name varchar(20) not null
)
GO
CREATE TRIGGER dbo.tr_I_Table1 ON dbo.Table1
AFTER INSERT 
AS
	INSERT INTO dbo.Table1_a (Name)
	SELECT Name FROM inserted
GO

*/

/***********************************************
	IDENTITY values and how to retrieve them
************************************************/
INSERT INTO dbo.Table1 (Name) VALUES ('Ben Miller')
SELECT @@IDENTITY as Identity_Value1
SELECT SCOPE_IDENTITY() as Scope_Identity_Value1

/*********************************
	SET IDENTITY_INSERT 
**********************************/
SET IDENTITY_INSERT dbo.Table1 ON

INSERT INTO dbo.Table1 (id, Name)
VALUES (500, 'George')

SET IDENTITY_INSERT dbo.Table1 OFF

INSERT INTO dbo.Table1 (Name) VALUES ('Curt Miller')
SELECT SCOPE_IDENTITY() as Scope_Identity_Value1

dbcc checkident('dbo.Table1')

/*********************************
	Variables and setting values 
**********************************/
SET STATISTICS TIME ON
GO
DECLARE @val1 varchar(20)
DECLARE @val2 varchar(20)
DECLARE @val3 varchar(20)
DECLARE @val4 varchar(20)
DECLARE @val5 varchar(20)
DECLARE @val6 varchar(20)
DECLARE @val7 varchar(20)
DECLARE @val8 varchar(20)
DECLARE @val9 varchar(20)
DECLARE @val10 varchar(20)
DECLARE @val11 varchar(20)
DECLARE @val12 varchar(20)
DECLARE @val13 varchar(20)
DECLARE @val14 varchar(20)
DECLARE @val15 varchar(20)
DECLARE @val16 varchar(20)
DECLARE @val17 varchar(20)
DECLARE @val18 varchar(20)
DECLARE @val19 varchar(20)
DECLARE @val20 varchar(20)
DECLARE @val21 varchar(20)
DECLARE @val22 varchar(20)
DECLARE @val23 varchar(20)
DECLARE @val24 varchar(20)
DECLARE @val25 varchar(20)
DECLARE @val26 varchar(20)
DECLARE @val27 varchar(20)
DECLARE @val28 varchar(20)
DECLARE @val29 varchar(20)
DECLARE @val30 varchar(20)
DECLARE @val31 varchar(20)
DECLARE @val32 varchar(20)
DECLARE @val33 varchar(20)
DECLARE @val34 varchar(20)
DECLARE @val35 varchar(20)
DECLARE @val36 varchar(20)
DECLARE @val37 varchar(20)
DECLARE @val38 varchar(20)
DECLARE @val39 varchar(20)
DECLARE @val40 varchar(20)
DECLARE @val41 varchar(20)
DECLARE @val42 varchar(20)
DECLARE @val43 varchar(20)
DECLARE @val44 varchar(20)
DECLARE @val45 varchar(20)
DECLARE @val46 varchar(20)
DECLARE @val47 varchar(20)
DECLARE @val48 varchar(20)
DECLARE @val49 varchar(20)
DECLARE @val50 varchar(20)
DECLARE @val51 varchar(20)
DECLARE @val52 varchar(20)
DECLARE @val53 varchar(20)
DECLARE @val54 varchar(20)
DECLARE @val55 varchar(20)
DECLARE @val56 varchar(20)
DECLARE @val57 varchar(20)
DECLARE @val58 varchar(20)
DECLARE @val59 varchar(20)
DECLARE @val60 varchar(20)
DECLARE @val61 varchar(20)
DECLARE @val62 varchar(20)
DECLARE @val63 varchar(20)
DECLARE @val64 varchar(20)
DECLARE @val65 varchar(20)
DECLARE @val66 varchar(20)
DECLARE @val67 varchar(20)
DECLARE @val68 varchar(20)
DECLARE @val69 varchar(20)
DECLARE @val70 varchar(20)
DECLARE @val71 varchar(20)
DECLARE @val72 varchar(20)
DECLARE @val73 varchar(20)
DECLARE @val74 varchar(20)
DECLARE @val75 varchar(20)
DECLARE @val76 varchar(20)
DECLARE @val77 varchar(20)
DECLARE @val78 varchar(20)
DECLARE @val79 varchar(20)
DECLARE @val80 varchar(20)
DECLARE @val81 varchar(20)
DECLARE @val82 varchar(20)
DECLARE @val83 varchar(20)
DECLARE @val84 varchar(20)
DECLARE @val85 varchar(20)
DECLARE @val86 varchar(20)
DECLARE @val87 varchar(20)
DECLARE @val88 varchar(20)
DECLARE @val89 varchar(20)
DECLARE @val90 varchar(20)
DECLARE @val91 varchar(20)
DECLARE @val92 varchar(20)
DECLARE @val93 varchar(20)
DECLARE @val94 varchar(20)
DECLARE @val95 varchar(20)
DECLARE @val96 varchar(20)
DECLARE @val97 varchar(20)
DECLARE @val98 varchar(20)
DECLARE @val99 varchar(20)
DECLARE @val100 varchar(20)
DECLARE @val101 varchar(20)
DECLARE @val102 varchar(20)
DECLARE @val103 varchar(20)
DECLARE @val104 varchar(20)
DECLARE @val105 varchar(20)
DECLARE @val106 varchar(20)
DECLARE @val107 varchar(20)
DECLARE @val108 varchar(20)
DECLARE @val109 varchar(20)
DECLARE @val110 varchar(20)
DECLARE @val111 varchar(20)
DECLARE @val112 varchar(20)
DECLARE @val113 varchar(20)
DECLARE @val114 varchar(20)
DECLARE @val115 varchar(20)
DECLARE @val116 varchar(20)
DECLARE @val117 varchar(20)
DECLARE @val118 varchar(20)
DECLARE @val119 varchar(20)
DECLARE @val120 varchar(20)
DECLARE @val121 varchar(20)
DECLARE @val122 varchar(20)
DECLARE @val123 varchar(20)
DECLARE @val124 varchar(20)
DECLARE @val125 varchar(20)
DECLARE @val126 varchar(20)
DECLARE @val127 varchar(20)
DECLARE @val128 varchar(20)
DECLARE @val129 varchar(20)
DECLARE @val130 varchar(20)
DECLARE @val131 varchar(20)
DECLARE @val132 varchar(20)
DECLARE @val133 varchar(20)
DECLARE @val134 varchar(20)
DECLARE @val135 varchar(20)
DECLARE @val136 varchar(20)
DECLARE @val137 varchar(20)
DECLARE @val138 varchar(20)
DECLARE @val139 varchar(20)
DECLARE @val140 varchar(20)
DECLARE @val141 varchar(20)
DECLARE @val142 varchar(20)
DECLARE @val143 varchar(20)
DECLARE @val144 varchar(20)
DECLARE @val145 varchar(20)
DECLARE @val146 varchar(20)
DECLARE @val147 varchar(20)
DECLARE @val148 varchar(20)
DECLARE @val149 varchar(20)
DECLARE @val150 varchar(20)
DECLARE @val151 varchar(20)
DECLARE @val152 varchar(20)
DECLARE @val153 varchar(20)
DECLARE @val154 varchar(20)
DECLARE @val155 varchar(20)
DECLARE @val156 varchar(20)
DECLARE @val157 varchar(20)
DECLARE @val158 varchar(20)
DECLARE @val159 varchar(20)
DECLARE @val160 varchar(20)
DECLARE @val161 varchar(20)
DECLARE @val162 varchar(20)
DECLARE @val163 varchar(20)
DECLARE @val164 varchar(20)
DECLARE @val165 varchar(20)
DECLARE @val166 varchar(20)
DECLARE @val167 varchar(20)
DECLARE @val168 varchar(20)
DECLARE @val169 varchar(20)
DECLARE @val170 varchar(20)
DECLARE @val171 varchar(20)
DECLARE @val172 varchar(20)
DECLARE @val173 varchar(20)
DECLARE @val174 varchar(20)
DECLARE @val175 varchar(20)
DECLARE @val176 varchar(20)
DECLARE @val177 varchar(20)
DECLARE @val178 varchar(20)
DECLARE @val179 varchar(20)
DECLARE @val180 varchar(20)
DECLARE @val181 varchar(20)
DECLARE @val182 varchar(20)
DECLARE @val183 varchar(20)
DECLARE @val184 varchar(20)
DECLARE @val185 varchar(20)
DECLARE @val186 varchar(20)
DECLARE @val187 varchar(20)
DECLARE @val188 varchar(20)
DECLARE @val189 varchar(20)
DECLARE @val190 varchar(20)
DECLARE @val191 varchar(20)
DECLARE @val192 varchar(20)
DECLARE @val193 varchar(20)
DECLARE @val194 varchar(20)
DECLARE @val195 varchar(20)
DECLARE @val196 varchar(20)
DECLARE @val197 varchar(20)
DECLARE @val198 varchar(20)
DECLARE @val199 varchar(20)
DECLARE @val200 varchar(20)
DECLARE @val201 varchar(20)
DECLARE @val202 varchar(20)
DECLARE @val203 varchar(20)
DECLARE @val204 varchar(20)
DECLARE @val205 varchar(20)
DECLARE @val206 varchar(20)
DECLARE @val207 varchar(20)
DECLARE @val208 varchar(20)
DECLARE @val209 varchar(20)
DECLARE @val210 varchar(20)
DECLARE @val211 varchar(20)
DECLARE @val212 varchar(20)
DECLARE @val213 varchar(20)
DECLARE @val214 varchar(20)
DECLARE @val215 varchar(20)
DECLARE @val216 varchar(20)
DECLARE @val217 varchar(20)
DECLARE @val218 varchar(20)
DECLARE @val219 varchar(20)
DECLARE @val220 varchar(20)
DECLARE @val221 varchar(20)
DECLARE @val222 varchar(20)
DECLARE @val223 varchar(20)
DECLARE @val224 varchar(20)
DECLARE @val225 varchar(20)
DECLARE @val226 varchar(20)
DECLARE @val227 varchar(20)
DECLARE @val228 varchar(20)
DECLARE @val229 varchar(20)
DECLARE @val230 varchar(20)
DECLARE @val231 varchar(20)
DECLARE @val232 varchar(20)
DECLARE @val233 varchar(20)
DECLARE @val234 varchar(20)
DECLARE @val235 varchar(20)
DECLARE @val236 varchar(20)
DECLARE @val237 varchar(20)
DECLARE @val238 varchar(20)
DECLARE @val239 varchar(20)
DECLARE @val240 varchar(20)
DECLARE @val241 varchar(20)
DECLARE @val242 varchar(20)
DECLARE @val243 varchar(20)
DECLARE @val244 varchar(20)
DECLARE @val245 varchar(20)
DECLARE @val246 varchar(20)
DECLARE @val247 varchar(20)
DECLARE @val248 varchar(20)
DECLARE @val249 varchar(20)
DECLARE @val250 varchar(20)
DECLARE @val251 varchar(20)
DECLARE @val252 varchar(20)
DECLARE @val253 varchar(20)
DECLARE @val254 varchar(20)
DECLARE @val255 varchar(20)
DECLARE @val256 varchar(20)
DECLARE @val257 varchar(20)
DECLARE @val258 varchar(20)
DECLARE @val259 varchar(20)
DECLARE @val260 varchar(20)
DECLARE @val261 varchar(20)
DECLARE @val262 varchar(20)
DECLARE @val263 varchar(20)
DECLARE @val264 varchar(20)
DECLARE @val265 varchar(20)
DECLARE @val266 varchar(20)
DECLARE @val267 varchar(20)
DECLARE @val268 varchar(20)
DECLARE @val269 varchar(20)
DECLARE @val270 varchar(20)
DECLARE @val271 varchar(20)
DECLARE @val272 varchar(20)
DECLARE @val273 varchar(20)
DECLARE @val274 varchar(20)
DECLARE @val275 varchar(20)
DECLARE @val276 varchar(20)
DECLARE @val277 varchar(20)
DECLARE @val278 varchar(20)
DECLARE @val279 varchar(20)
DECLARE @val280 varchar(20)
DECLARE @val281 varchar(20)
DECLARE @val282 varchar(20)
DECLARE @val283 varchar(20)
DECLARE @val284 varchar(20)
DECLARE @val285 varchar(20)
DECLARE @val286 varchar(20)
DECLARE @val287 varchar(20)
DECLARE @val288 varchar(20)
DECLARE @val289 varchar(20)
DECLARE @val290 varchar(20)
DECLARE @val291 varchar(20)
DECLARE @val292 varchar(20)
DECLARE @val293 varchar(20)
DECLARE @val294 varchar(20)
DECLARE @val295 varchar(20)
DECLARE @val296 varchar(20)
DECLARE @val297 varchar(20)
DECLARE @val298 varchar(20)
DECLARE @val299 varchar(20)
DECLARE @val300 varchar(20)
DECLARE @val301 varchar(20)
DECLARE @val302 varchar(20)
DECLARE @val303 varchar(20)
DECLARE @val304 varchar(20)
DECLARE @val305 varchar(20)
DECLARE @val306 varchar(20)
DECLARE @val307 varchar(20)
DECLARE @val308 varchar(20)
DECLARE @val309 varchar(20)
DECLARE @val310 varchar(20)
DECLARE @val311 varchar(20)
DECLARE @val312 varchar(20)
DECLARE @val313 varchar(20)
DECLARE @val314 varchar(20)
DECLARE @val315 varchar(20)
DECLARE @val316 varchar(20)
DECLARE @val317 varchar(20)
DECLARE @val318 varchar(20)
DECLARE @val319 varchar(20)
DECLARE @val320 varchar(20)
DECLARE @val321 varchar(20)
DECLARE @val322 varchar(20)
DECLARE @val323 varchar(20)
DECLARE @val324 varchar(20)
DECLARE @val325 varchar(20)
DECLARE @val326 varchar(20)
DECLARE @val327 varchar(20)
DECLARE @val328 varchar(20)
DECLARE @val329 varchar(20)
DECLARE @val330 varchar(20)
DECLARE @val331 varchar(20)
DECLARE @val332 varchar(20)
DECLARE @val333 varchar(20)
DECLARE @val334 varchar(20)
DECLARE @val335 varchar(20)
DECLARE @val336 varchar(20)
DECLARE @val337 varchar(20)
DECLARE @val338 varchar(20)
DECLARE @val339 varchar(20)
DECLARE @val340 varchar(20)
DECLARE @val341 varchar(20)
DECLARE @val342 varchar(20)
DECLARE @val343 varchar(20)
DECLARE @val344 varchar(20)
DECLARE @val345 varchar(20)
DECLARE @val346 varchar(20)
DECLARE @val347 varchar(20)
DECLARE @val348 varchar(20)
DECLARE @val349 varchar(20)
DECLARE @val350 varchar(20)
DECLARE @val351 varchar(20)
DECLARE @val352 varchar(20)
DECLARE @val353 varchar(20)
DECLARE @val354 varchar(20)
DECLARE @val355 varchar(20)
DECLARE @val356 varchar(20)
DECLARE @val357 varchar(20)
DECLARE @val358 varchar(20)
DECLARE @val359 varchar(20)
DECLARE @val360 varchar(20)
DECLARE @val361 varchar(20)
DECLARE @val362 varchar(20)
DECLARE @val363 varchar(20)
DECLARE @val364 varchar(20)
DECLARE @val365 varchar(20)
DECLARE @val366 varchar(20)
DECLARE @val367 varchar(20)
DECLARE @val368 varchar(20)
DECLARE @val369 varchar(20)
DECLARE @val370 varchar(20)
DECLARE @val371 varchar(20)
DECLARE @val372 varchar(20)
DECLARE @val373 varchar(20)
DECLARE @val374 varchar(20)
DECLARE @val375 varchar(20)
DECLARE @val376 varchar(20)
DECLARE @val377 varchar(20)
DECLARE @val378 varchar(20)
DECLARE @val379 varchar(20)
DECLARE @val380 varchar(20)
DECLARE @val381 varchar(20)
DECLARE @val382 varchar(20)
DECLARE @val383 varchar(20)
DECLARE @val384 varchar(20)
DECLARE @val385 varchar(20)
DECLARE @val386 varchar(20)
DECLARE @val387 varchar(20)
DECLARE @val388 varchar(20)
DECLARE @val389 varchar(20)
DECLARE @val390 varchar(20)
DECLARE @val391 varchar(20)
DECLARE @val392 varchar(20)
DECLARE @val393 varchar(20)
DECLARE @val394 varchar(20)
DECLARE @val395 varchar(20)
DECLARE @val396 varchar(20)
DECLARE @val397 varchar(20)
DECLARE @val398 varchar(20)
DECLARE @val399 varchar(20)
DECLARE @val400 varchar(20)
DECLARE @val401 varchar(20)
DECLARE @val402 varchar(20)
DECLARE @val403 varchar(20)
DECLARE @val404 varchar(20)
DECLARE @val405 varchar(20)
DECLARE @val406 varchar(20)
DECLARE @val407 varchar(20)
DECLARE @val408 varchar(20)
DECLARE @val409 varchar(20)
DECLARE @val410 varchar(20)
DECLARE @val411 varchar(20)
DECLARE @val412 varchar(20)
DECLARE @val413 varchar(20)
DECLARE @val414 varchar(20)
DECLARE @val415 varchar(20)
DECLARE @val416 varchar(20)
DECLARE @val417 varchar(20)
DECLARE @val418 varchar(20)
DECLARE @val419 varchar(20)
DECLARE @val420 varchar(20)
DECLARE @val421 varchar(20)
DECLARE @val422 varchar(20)
DECLARE @val423 varchar(20)
DECLARE @val424 varchar(20)
DECLARE @val425 varchar(20)
DECLARE @val426 varchar(20)
DECLARE @val427 varchar(20)
DECLARE @val428 varchar(20)
DECLARE @val429 varchar(20)
DECLARE @val430 varchar(20)
DECLARE @val431 varchar(20)
DECLARE @val432 varchar(20)
DECLARE @val433 varchar(20)
DECLARE @val434 varchar(20)
DECLARE @val435 varchar(20)
DECLARE @val436 varchar(20)
DECLARE @val437 varchar(20)
DECLARE @val438 varchar(20)
DECLARE @val439 varchar(20)
DECLARE @val440 varchar(20)
DECLARE @val441 varchar(20)
DECLARE @val442 varchar(20)
DECLARE @val443 varchar(20)
DECLARE @val444 varchar(20)
DECLARE @val445 varchar(20)
DECLARE @val446 varchar(20)
DECLARE @val447 varchar(20)
DECLARE @val448 varchar(20)
DECLARE @val449 varchar(20)
DECLARE @val450 varchar(20)
DECLARE @val451 varchar(20)
DECLARE @val452 varchar(20)
DECLARE @val453 varchar(20)
DECLARE @val454 varchar(20)
DECLARE @val455 varchar(20)
DECLARE @val456 varchar(20)
DECLARE @val457 varchar(20)
DECLARE @val458 varchar(20)
DECLARE @val459 varchar(20)
DECLARE @val460 varchar(20)
DECLARE @val461 varchar(20)
DECLARE @val462 varchar(20)
DECLARE @val463 varchar(20)
DECLARE @val464 varchar(20)
DECLARE @val465 varchar(20)
DECLARE @val466 varchar(20)
DECLARE @val467 varchar(20)
DECLARE @val468 varchar(20)
DECLARE @val469 varchar(20)
DECLARE @val470 varchar(20)
DECLARE @val471 varchar(20)
DECLARE @val472 varchar(20)
DECLARE @val473 varchar(20)
DECLARE @val474 varchar(20)
DECLARE @val475 varchar(20)
DECLARE @val476 varchar(20)
DECLARE @val477 varchar(20)
DECLARE @val478 varchar(20)
DECLARE @val479 varchar(20)
DECLARE @val480 varchar(20)
DECLARE @val481 varchar(20)
DECLARE @val482 varchar(20)
DECLARE @val483 varchar(20)
DECLARE @val484 varchar(20)
DECLARE @val485 varchar(20)
DECLARE @val486 varchar(20)
DECLARE @val487 varchar(20)
DECLARE @val488 varchar(20)
DECLARE @val489 varchar(20)
DECLARE @val490 varchar(20)
DECLARE @val491 varchar(20)
DECLARE @val492 varchar(20)
DECLARE @val493 varchar(20)
DECLARE @val494 varchar(20)
DECLARE @val495 varchar(20)
DECLARE @val496 varchar(20)
DECLARE @val497 varchar(20)
DECLARE @val498 varchar(20)
DECLARE @val499 varchar(20)
DECLARE @val500 varchar(20)
DECLARE @val501 varchar(20)
DECLARE @val502 varchar(20)
DECLARE @val503 varchar(20)
DECLARE @val504 varchar(20)
DECLARE @val505 varchar(20)
DECLARE @val506 varchar(20)
DECLARE @val507 varchar(20)
DECLARE @val508 varchar(20)
DECLARE @val509 varchar(20)
DECLARE @val510 varchar(20)
DECLARE @val511 varchar(20)
DECLARE @val512 varchar(20)
DECLARE @val513 varchar(20)
DECLARE @val514 varchar(20)
DECLARE @val515 varchar(20)
DECLARE @val516 varchar(20)
DECLARE @val517 varchar(20)
DECLARE @val518 varchar(20)
DECLARE @val519 varchar(20)
DECLARE @val520 varchar(20)
DECLARE @val521 varchar(20)
DECLARE @val522 varchar(20)
DECLARE @val523 varchar(20)
DECLARE @val524 varchar(20)
DECLARE @val525 varchar(20)
DECLARE @val526 varchar(20)
DECLARE @val527 varchar(20)
DECLARE @val528 varchar(20)
DECLARE @val529 varchar(20)
DECLARE @val530 varchar(20)
DECLARE @val531 varchar(20)
DECLARE @val532 varchar(20)
DECLARE @val533 varchar(20)
DECLARE @val534 varchar(20)
DECLARE @val535 varchar(20)
DECLARE @val536 varchar(20)
DECLARE @val537 varchar(20)
DECLARE @val538 varchar(20)
DECLARE @val539 varchar(20)
DECLARE @val540 varchar(20)
DECLARE @val541 varchar(20)
DECLARE @val542 varchar(20)
DECLARE @val543 varchar(20)
DECLARE @val544 varchar(20)
DECLARE @val545 varchar(20)
DECLARE @val546 varchar(20)
DECLARE @val547 varchar(20)
DECLARE @val548 varchar(20)
DECLARE @val549 varchar(20)
DECLARE @val550 varchar(20)
DECLARE @val551 varchar(20)
DECLARE @val552 varchar(20)
DECLARE @val553 varchar(20)
DECLARE @val554 varchar(20)
DECLARE @val555 varchar(20)
DECLARE @val556 varchar(20)
DECLARE @val557 varchar(20)
DECLARE @val558 varchar(20)
DECLARE @val559 varchar(20)
DECLARE @val560 varchar(20)
DECLARE @val561 varchar(20)
DECLARE @val562 varchar(20)
DECLARE @val563 varchar(20)
DECLARE @val564 varchar(20)
DECLARE @val565 varchar(20)
DECLARE @val566 varchar(20)
DECLARE @val567 varchar(20)
DECLARE @val568 varchar(20)
DECLARE @val569 varchar(20)
DECLARE @val570 varchar(20)
DECLARE @val571 varchar(20)
DECLARE @val572 varchar(20)
DECLARE @val573 varchar(20)
DECLARE @val574 varchar(20)
DECLARE @val575 varchar(20)
DECLARE @val576 varchar(20)
DECLARE @val577 varchar(20)
DECLARE @val578 varchar(20)
DECLARE @val579 varchar(20)
DECLARE @val580 varchar(20)
DECLARE @val581 varchar(20)
DECLARE @val582 varchar(20)
DECLARE @val583 varchar(20)
DECLARE @val584 varchar(20)
DECLARE @val585 varchar(20)
DECLARE @val586 varchar(20)
DECLARE @val587 varchar(20)
DECLARE @val588 varchar(20)
DECLARE @val589 varchar(20)
DECLARE @val590 varchar(20)
DECLARE @val591 varchar(20)
DECLARE @val592 varchar(20)
DECLARE @val593 varchar(20)
DECLARE @val594 varchar(20)
DECLARE @val595 varchar(20)
DECLARE @val596 varchar(20)
DECLARE @val597 varchar(20)
DECLARE @val598 varchar(20)
DECLARE @val599 varchar(20)
DECLARE @val600 varchar(20)
DECLARE @val601 varchar(20)
DECLARE @val602 varchar(20)
DECLARE @val603 varchar(20)
DECLARE @val604 varchar(20)
DECLARE @val605 varchar(20)
DECLARE @val606 varchar(20)
DECLARE @val607 varchar(20)
DECLARE @val608 varchar(20)
DECLARE @val609 varchar(20)
DECLARE @val610 varchar(20)
DECLARE @val611 varchar(20)
DECLARE @val612 varchar(20)
DECLARE @val613 varchar(20)
DECLARE @val614 varchar(20)
DECLARE @val615 varchar(20)
DECLARE @val616 varchar(20)
DECLARE @val617 varchar(20)
DECLARE @val618 varchar(20)
DECLARE @val619 varchar(20)
DECLARE @val620 varchar(20)
DECLARE @val621 varchar(20)
DECLARE @val622 varchar(20)
DECLARE @val623 varchar(20)
DECLARE @val624 varchar(20)
DECLARE @val625 varchar(20)
DECLARE @val626 varchar(20)
DECLARE @val627 varchar(20)
DECLARE @val628 varchar(20)
DECLARE @val629 varchar(20)
DECLARE @val630 varchar(20)
DECLARE @val631 varchar(20)
DECLARE @val632 varchar(20)
DECLARE @val633 varchar(20)
DECLARE @val634 varchar(20)
DECLARE @val635 varchar(20)
DECLARE @val636 varchar(20)
DECLARE @val637 varchar(20)
DECLARE @val638 varchar(20)
DECLARE @val639 varchar(20)
DECLARE @val640 varchar(20)
DECLARE @val641 varchar(20)
DECLARE @val642 varchar(20)
DECLARE @val643 varchar(20)
DECLARE @val644 varchar(20)
DECLARE @val645 varchar(20)
DECLARE @val646 varchar(20)
DECLARE @val647 varchar(20)
DECLARE @val648 varchar(20)
DECLARE @val649 varchar(20)
DECLARE @val650 varchar(20)
DECLARE @val651 varchar(20)
DECLARE @val652 varchar(20)
DECLARE @val653 varchar(20)
DECLARE @val654 varchar(20)
DECLARE @val655 varchar(20)
DECLARE @val656 varchar(20)
DECLARE @val657 varchar(20)
DECLARE @val658 varchar(20)
DECLARE @val659 varchar(20)
DECLARE @val660 varchar(20)
DECLARE @val661 varchar(20)
DECLARE @val662 varchar(20)
DECLARE @val663 varchar(20)
DECLARE @val664 varchar(20)
DECLARE @val665 varchar(20)
DECLARE @val666 varchar(20)
DECLARE @val667 varchar(20)
DECLARE @val668 varchar(20)
DECLARE @val669 varchar(20)
DECLARE @val670 varchar(20)
DECLARE @val671 varchar(20)
DECLARE @val672 varchar(20)
DECLARE @val673 varchar(20)
DECLARE @val674 varchar(20)
DECLARE @val675 varchar(20)
DECLARE @val676 varchar(20)
DECLARE @val677 varchar(20)
DECLARE @val678 varchar(20)
DECLARE @val679 varchar(20)
DECLARE @val680 varchar(20)
DECLARE @val681 varchar(20)
DECLARE @val682 varchar(20)
DECLARE @val683 varchar(20)
DECLARE @val684 varchar(20)
DECLARE @val685 varchar(20)
DECLARE @val686 varchar(20)
DECLARE @val687 varchar(20)
DECLARE @val688 varchar(20)
DECLARE @val689 varchar(20)
DECLARE @val690 varchar(20)
DECLARE @val691 varchar(20)
DECLARE @val692 varchar(20)
DECLARE @val693 varchar(20)
DECLARE @val694 varchar(20)
DECLARE @val695 varchar(20)
DECLARE @val696 varchar(20)
DECLARE @val697 varchar(20)
DECLARE @val698 varchar(20)
DECLARE @val699 varchar(20)
DECLARE @val700 varchar(20)
DECLARE @val701 varchar(20)
DECLARE @val702 varchar(20)
DECLARE @val703 varchar(20)
DECLARE @val704 varchar(20)
DECLARE @val705 varchar(20)
DECLARE @val706 varchar(20)
DECLARE @val707 varchar(20)
DECLARE @val708 varchar(20)
DECLARE @val709 varchar(20)
DECLARE @val710 varchar(20)
DECLARE @val711 varchar(20)
DECLARE @val712 varchar(20)
DECLARE @val713 varchar(20)
DECLARE @val714 varchar(20)
DECLARE @val715 varchar(20)
DECLARE @val716 varchar(20)
DECLARE @val717 varchar(20)
DECLARE @val718 varchar(20)
DECLARE @val719 varchar(20)
DECLARE @val720 varchar(20)
DECLARE @val721 varchar(20)
DECLARE @val722 varchar(20)
DECLARE @val723 varchar(20)
DECLARE @val724 varchar(20)
DECLARE @val725 varchar(20)
DECLARE @val726 varchar(20)
DECLARE @val727 varchar(20)
DECLARE @val728 varchar(20)
DECLARE @val729 varchar(20)
DECLARE @val730 varchar(20)
DECLARE @val731 varchar(20)
DECLARE @val732 varchar(20)
DECLARE @val733 varchar(20)
DECLARE @val734 varchar(20)
DECLARE @val735 varchar(20)
DECLARE @val736 varchar(20)
DECLARE @val737 varchar(20)
DECLARE @val738 varchar(20)
DECLARE @val739 varchar(20)
DECLARE @val740 varchar(20)
DECLARE @val741 varchar(20)
DECLARE @val742 varchar(20)
DECLARE @val743 varchar(20)
DECLARE @val744 varchar(20)
DECLARE @val745 varchar(20)
DECLARE @val746 varchar(20)
DECLARE @val747 varchar(20)
DECLARE @val748 varchar(20)
DECLARE @val749 varchar(20)
DECLARE @val750 varchar(20)
DECLARE @val751 varchar(20)
DECLARE @val752 varchar(20)
DECLARE @val753 varchar(20)
DECLARE @val754 varchar(20)
DECLARE @val755 varchar(20)
DECLARE @val756 varchar(20)
DECLARE @val757 varchar(20)
DECLARE @val758 varchar(20)
DECLARE @val759 varchar(20)
DECLARE @val760 varchar(20)
DECLARE @val761 varchar(20)
DECLARE @val762 varchar(20)
DECLARE @val763 varchar(20)
DECLARE @val764 varchar(20)
DECLARE @val765 varchar(20)
DECLARE @val766 varchar(20)
DECLARE @val767 varchar(20)
DECLARE @val768 varchar(20)
DECLARE @val769 varchar(20)
DECLARE @val770 varchar(20)
DECLARE @val771 varchar(20)
DECLARE @val772 varchar(20)
DECLARE @val773 varchar(20)
DECLARE @val774 varchar(20)
DECLARE @val775 varchar(20)
DECLARE @val776 varchar(20)
DECLARE @val777 varchar(20)
DECLARE @val778 varchar(20)
DECLARE @val779 varchar(20)
DECLARE @val780 varchar(20)
DECLARE @val781 varchar(20)
DECLARE @val782 varchar(20)
DECLARE @val783 varchar(20)
DECLARE @val784 varchar(20)
DECLARE @val785 varchar(20)
DECLARE @val786 varchar(20)
DECLARE @val787 varchar(20)
DECLARE @val788 varchar(20)
DECLARE @val789 varchar(20)
DECLARE @val790 varchar(20)
DECLARE @val791 varchar(20)
DECLARE @val792 varchar(20)
DECLARE @val793 varchar(20)
DECLARE @val794 varchar(20)
DECLARE @val795 varchar(20)
DECLARE @val796 varchar(20)
DECLARE @val797 varchar(20)
DECLARE @val798 varchar(20)
DECLARE @val799 varchar(20)
DECLARE @val800 varchar(20)
DECLARE @val801 varchar(20)
DECLARE @val802 varchar(20)
DECLARE @val803 varchar(20)
DECLARE @val804 varchar(20)
DECLARE @val805 varchar(20)
DECLARE @val806 varchar(20)
DECLARE @val807 varchar(20)
DECLARE @val808 varchar(20)
DECLARE @val809 varchar(20)
DECLARE @val810 varchar(20)
DECLARE @val811 varchar(20)
DECLARE @val812 varchar(20)
DECLARE @val813 varchar(20)
DECLARE @val814 varchar(20)
DECLARE @val815 varchar(20)
DECLARE @val816 varchar(20)
DECLARE @val817 varchar(20)
DECLARE @val818 varchar(20)
DECLARE @val819 varchar(20)
DECLARE @val820 varchar(20)
DECLARE @val821 varchar(20)
DECLARE @val822 varchar(20)
DECLARE @val823 varchar(20)
DECLARE @val824 varchar(20)
DECLARE @val825 varchar(20)
DECLARE @val826 varchar(20)
DECLARE @val827 varchar(20)
DECLARE @val828 varchar(20)
DECLARE @val829 varchar(20)
DECLARE @val830 varchar(20)
DECLARE @val831 varchar(20)
DECLARE @val832 varchar(20)
DECLARE @val833 varchar(20)
DECLARE @val834 varchar(20)
DECLARE @val835 varchar(20)
DECLARE @val836 varchar(20)
DECLARE @val837 varchar(20)
DECLARE @val838 varchar(20)
DECLARE @val839 varchar(20)
DECLARE @val840 varchar(20)
DECLARE @val841 varchar(20)
DECLARE @val842 varchar(20)
DECLARE @val843 varchar(20)
DECLARE @val844 varchar(20)
DECLARE @val845 varchar(20)
DECLARE @val846 varchar(20)
DECLARE @val847 varchar(20)
DECLARE @val848 varchar(20)
DECLARE @val849 varchar(20)
DECLARE @val850 varchar(20)
DECLARE @val851 varchar(20)
DECLARE @val852 varchar(20)
DECLARE @val853 varchar(20)
DECLARE @val854 varchar(20)
DECLARE @val855 varchar(20)
DECLARE @val856 varchar(20)
DECLARE @val857 varchar(20)
DECLARE @val858 varchar(20)
DECLARE @val859 varchar(20)
DECLARE @val860 varchar(20)
DECLARE @val861 varchar(20)
DECLARE @val862 varchar(20)
DECLARE @val863 varchar(20)
DECLARE @val864 varchar(20)
DECLARE @val865 varchar(20)
DECLARE @val866 varchar(20)
DECLARE @val867 varchar(20)
DECLARE @val868 varchar(20)
DECLARE @val869 varchar(20)
DECLARE @val870 varchar(20)
DECLARE @val871 varchar(20)
DECLARE @val872 varchar(20)
DECLARE @val873 varchar(20)
DECLARE @val874 varchar(20)
DECLARE @val875 varchar(20)
DECLARE @val876 varchar(20)
DECLARE @val877 varchar(20)
DECLARE @val878 varchar(20)
DECLARE @val879 varchar(20)
DECLARE @val880 varchar(20)
DECLARE @val881 varchar(20)
DECLARE @val882 varchar(20)
DECLARE @val883 varchar(20)
DECLARE @val884 varchar(20)
DECLARE @val885 varchar(20)
DECLARE @val886 varchar(20)
DECLARE @val887 varchar(20)
DECLARE @val888 varchar(20)
DECLARE @val889 varchar(20)
DECLARE @val890 varchar(20)
DECLARE @val891 varchar(20)
DECLARE @val892 varchar(20)
DECLARE @val893 varchar(20)
DECLARE @val894 varchar(20)
DECLARE @val895 varchar(20)
DECLARE @val896 varchar(20)
DECLARE @val897 varchar(20)
DECLARE @val898 varchar(20)
DECLARE @val899 varchar(20)
DECLARE @val900 varchar(20)
DECLARE @val901 varchar(20)
DECLARE @val902 varchar(20)
DECLARE @val903 varchar(20)
DECLARE @val904 varchar(20)
DECLARE @val905 varchar(20)
DECLARE @val906 varchar(20)
DECLARE @val907 varchar(20)
DECLARE @val908 varchar(20)
DECLARE @val909 varchar(20)
DECLARE @val910 varchar(20)
DECLARE @val911 varchar(20)
DECLARE @val912 varchar(20)
DECLARE @val913 varchar(20)
DECLARE @val914 varchar(20)
DECLARE @val915 varchar(20)
DECLARE @val916 varchar(20)
DECLARE @val917 varchar(20)
DECLARE @val918 varchar(20)
DECLARE @val919 varchar(20)
DECLARE @val920 varchar(20)
DECLARE @val921 varchar(20)
DECLARE @val922 varchar(20)
DECLARE @val923 varchar(20)
DECLARE @val924 varchar(20)
DECLARE @val925 varchar(20)
DECLARE @val926 varchar(20)
DECLARE @val927 varchar(20)
DECLARE @val928 varchar(20)
DECLARE @val929 varchar(20)
DECLARE @val930 varchar(20)
DECLARE @val931 varchar(20)
DECLARE @val932 varchar(20)
DECLARE @val933 varchar(20)
DECLARE @val934 varchar(20)
DECLARE @val935 varchar(20)
DECLARE @val936 varchar(20)
DECLARE @val937 varchar(20)
DECLARE @val938 varchar(20)
DECLARE @val939 varchar(20)
DECLARE @val940 varchar(20)
DECLARE @val941 varchar(20)
DECLARE @val942 varchar(20)
DECLARE @val943 varchar(20)
DECLARE @val944 varchar(20)
DECLARE @val945 varchar(20)
DECLARE @val946 varchar(20)
DECLARE @val947 varchar(20)
DECLARE @val948 varchar(20)
DECLARE @val949 varchar(20)
DECLARE @val950 varchar(20)
DECLARE @val951 varchar(20)
DECLARE @val952 varchar(20)
DECLARE @val953 varchar(20)
DECLARE @val954 varchar(20)
DECLARE @val955 varchar(20)
DECLARE @val956 varchar(20)
DECLARE @val957 varchar(20)
DECLARE @val958 varchar(20)
DECLARE @val959 varchar(20)
DECLARE @val960 varchar(20)
DECLARE @val961 varchar(20)
DECLARE @val962 varchar(20)
DECLARE @val963 varchar(20)
DECLARE @val964 varchar(20)
DECLARE @val965 varchar(20)
DECLARE @val966 varchar(20)
DECLARE @val967 varchar(20)
DECLARE @val968 varchar(20)
DECLARE @val969 varchar(20)
DECLARE @val970 varchar(20)
DECLARE @val971 varchar(20)
DECLARE @val972 varchar(20)
DECLARE @val973 varchar(20)
DECLARE @val974 varchar(20)
DECLARE @val975 varchar(20)
DECLARE @val976 varchar(20)
DECLARE @val977 varchar(20)
DECLARE @val978 varchar(20)
DECLARE @val979 varchar(20)
DECLARE @val980 varchar(20)
DECLARE @val981 varchar(20)
DECLARE @val982 varchar(20)
DECLARE @val983 varchar(20)
DECLARE @val984 varchar(20)
DECLARE @val985 varchar(20)
DECLARE @val986 varchar(20)
DECLARE @val987 varchar(20)
DECLARE @val988 varchar(20)
DECLARE @val989 varchar(20)
DECLARE @val990 varchar(20)
DECLARE @val991 varchar(20)
DECLARE @val992 varchar(20)
DECLARE @val993 varchar(20)
DECLARE @val994 varchar(20)
DECLARE @val995 varchar(20)
DECLARE @val996 varchar(20)
DECLARE @val997 varchar(20)
DECLARE @val998 varchar(20)
DECLARE @val999 varchar(20)
DECLARE @val1000 varchar(20)

SET @val1 = 'Ben Miller'
SET @val2 = 'Ben Miller'
SET @val3 = 'Ben Miller'
SET @val4 = 'Ben Miller'
SET @val5 = 'Ben Miller'
SET @val6 = 'Ben Miller'
SET @val7 = 'Ben Miller'
SET @val8 = 'Ben Miller'
SET @val9 = 'Ben Miller'
SET @val10 = 'Ben Miller'
SET @val11 = 'Ben Miller'
SET @val12 = 'Ben Miller'
SET @val13 = 'Ben Miller'
SET @val14 = 'Ben Miller'
SET @val15 = 'Ben Miller'
SET @val16 = 'Ben Miller'
SET @val17 = 'Ben Miller'
SET @val18 = 'Ben Miller'
SET @val19 = 'Ben Miller'
SET @val20 = 'Ben Miller'
SET @val21 = 'Ben Miller'
SET @val22 = 'Ben Miller'
SET @val23 = 'Ben Miller'
SET @val24 = 'Ben Miller'
SET @val25 = 'Ben Miller'
SET @val26 = 'Ben Miller'
SET @val27 = 'Ben Miller'
SET @val28 = 'Ben Miller'
SET @val29 = 'Ben Miller'
SET @val30 = 'Ben Miller'
SET @val31 = 'Ben Miller'
SET @val32 = 'Ben Miller'
SET @val33 = 'Ben Miller'
SET @val34 = 'Ben Miller'
SET @val35 = 'Ben Miller'
SET @val36 = 'Ben Miller'
SET @val37 = 'Ben Miller'
SET @val38 = 'Ben Miller'
SET @val39 = 'Ben Miller'
SET @val40 = 'Ben Miller'
SET @val41 = 'Ben Miller'
SET @val42 = 'Ben Miller'
SET @val43 = 'Ben Miller'
SET @val44 = 'Ben Miller'
SET @val45 = 'Ben Miller'
SET @val46 = 'Ben Miller'
SET @val47 = 'Ben Miller'
SET @val48 = 'Ben Miller'
SET @val49 = 'Ben Miller'
SET @val50 = 'Ben Miller'
SET @val51 = 'Ben Miller'
SET @val52 = 'Ben Miller'
SET @val53 = 'Ben Miller'
SET @val54 = 'Ben Miller'
SET @val55 = 'Ben Miller'
SET @val56 = 'Ben Miller'
SET @val57 = 'Ben Miller'
SET @val58 = 'Ben Miller'
SET @val59 = 'Ben Miller'
SET @val60 = 'Ben Miller'
SET @val61 = 'Ben Miller'
SET @val62 = 'Ben Miller'
SET @val63 = 'Ben Miller'
SET @val64 = 'Ben Miller'
SET @val65 = 'Ben Miller'
SET @val66 = 'Ben Miller'
SET @val67 = 'Ben Miller'
SET @val68 = 'Ben Miller'
SET @val69 = 'Ben Miller'
SET @val70 = 'Ben Miller'
SET @val71 = 'Ben Miller'
SET @val72 = 'Ben Miller'
SET @val73 = 'Ben Miller'
SET @val74 = 'Ben Miller'
SET @val75 = 'Ben Miller'
SET @val76 = 'Ben Miller'
SET @val77 = 'Ben Miller'
SET @val78 = 'Ben Miller'
SET @val79 = 'Ben Miller'
SET @val80 = 'Ben Miller'
SET @val81 = 'Ben Miller'
SET @val82 = 'Ben Miller'
SET @val83 = 'Ben Miller'
SET @val84 = 'Ben Miller'
SET @val85 = 'Ben Miller'
SET @val86 = 'Ben Miller'
SET @val87 = 'Ben Miller'
SET @val88 = 'Ben Miller'
SET @val89 = 'Ben Miller'
SET @val90 = 'Ben Miller'
SET @val91 = 'Ben Miller'
SET @val92 = 'Ben Miller'
SET @val93 = 'Ben Miller'
SET @val94 = 'Ben Miller'
SET @val95 = 'Ben Miller'
SET @val96 = 'Ben Miller'
SET @val97 = 'Ben Miller'
SET @val98 = 'Ben Miller'
SET @val99 = 'Ben Miller'
SET @val100 = 'Ben Miller'
SET @val101 = 'Ben Miller'
SET @val102 = 'Ben Miller'
SET @val103 = 'Ben Miller'
SET @val104 = 'Ben Miller'
SET @val105 = 'Ben Miller'
SET @val106 = 'Ben Miller'
SET @val107 = 'Ben Miller'
SET @val108 = 'Ben Miller'
SET @val109 = 'Ben Miller'
SET @val110 = 'Ben Miller'
SET @val111 = 'Ben Miller'
SET @val112 = 'Ben Miller'
SET @val113 = 'Ben Miller'
SET @val114 = 'Ben Miller'
SET @val115 = 'Ben Miller'
SET @val116 = 'Ben Miller'
SET @val117 = 'Ben Miller'
SET @val118 = 'Ben Miller'
SET @val119 = 'Ben Miller'
SET @val120 = 'Ben Miller'
SET @val121 = 'Ben Miller'
SET @val122 = 'Ben Miller'
SET @val123 = 'Ben Miller'
SET @val124 = 'Ben Miller'
SET @val125 = 'Ben Miller'
SET @val126 = 'Ben Miller'
SET @val127 = 'Ben Miller'
SET @val128 = 'Ben Miller'
SET @val129 = 'Ben Miller'
SET @val130 = 'Ben Miller'
SET @val131 = 'Ben Miller'
SET @val132 = 'Ben Miller'
SET @val133 = 'Ben Miller'
SET @val134 = 'Ben Miller'
SET @val135 = 'Ben Miller'
SET @val136 = 'Ben Miller'
SET @val137 = 'Ben Miller'
SET @val138 = 'Ben Miller'
SET @val139 = 'Ben Miller'
SET @val140 = 'Ben Miller'
SET @val141 = 'Ben Miller'
SET @val142 = 'Ben Miller'
SET @val143 = 'Ben Miller'
SET @val144 = 'Ben Miller'
SET @val145 = 'Ben Miller'
SET @val146 = 'Ben Miller'
SET @val147 = 'Ben Miller'
SET @val148 = 'Ben Miller'
SET @val149 = 'Ben Miller'
SET @val150 = 'Ben Miller'
SET @val151 = 'Ben Miller'
SET @val152 = 'Ben Miller'
SET @val153 = 'Ben Miller'
SET @val154 = 'Ben Miller'
SET @val155 = 'Ben Miller'
SET @val156 = 'Ben Miller'
SET @val157 = 'Ben Miller'
SET @val158 = 'Ben Miller'
SET @val159 = 'Ben Miller'
SET @val160 = 'Ben Miller'
SET @val161 = 'Ben Miller'
SET @val162 = 'Ben Miller'
SET @val163 = 'Ben Miller'
SET @val164 = 'Ben Miller'
SET @val165 = 'Ben Miller'
SET @val166 = 'Ben Miller'
SET @val167 = 'Ben Miller'
SET @val168 = 'Ben Miller'
SET @val169 = 'Ben Miller'
SET @val170 = 'Ben Miller'
SET @val171 = 'Ben Miller'
SET @val172 = 'Ben Miller'
SET @val173 = 'Ben Miller'
SET @val174 = 'Ben Miller'
SET @val175 = 'Ben Miller'
SET @val176 = 'Ben Miller'
SET @val177 = 'Ben Miller'
SET @val178 = 'Ben Miller'
SET @val179 = 'Ben Miller'
SET @val180 = 'Ben Miller'
SET @val181 = 'Ben Miller'
SET @val182 = 'Ben Miller'
SET @val183 = 'Ben Miller'
SET @val184 = 'Ben Miller'
SET @val185 = 'Ben Miller'
SET @val186 = 'Ben Miller'
SET @val187 = 'Ben Miller'
SET @val188 = 'Ben Miller'
SET @val189 = 'Ben Miller'
SET @val190 = 'Ben Miller'
SET @val191 = 'Ben Miller'
SET @val192 = 'Ben Miller'
SET @val193 = 'Ben Miller'
SET @val194 = 'Ben Miller'
SET @val195 = 'Ben Miller'
SET @val196 = 'Ben Miller'
SET @val197 = 'Ben Miller'
SET @val198 = 'Ben Miller'
SET @val199 = 'Ben Miller'
SET @val200 = 'Ben Miller'
SET @val201 = 'Ben Miller'
SET @val202 = 'Ben Miller'
SET @val203 = 'Ben Miller'
SET @val204 = 'Ben Miller'
SET @val205 = 'Ben Miller'
SET @val206 = 'Ben Miller'
SET @val207 = 'Ben Miller'
SET @val208 = 'Ben Miller'
SET @val209 = 'Ben Miller'
SET @val210 = 'Ben Miller'
SET @val211 = 'Ben Miller'
SET @val212 = 'Ben Miller'
SET @val213 = 'Ben Miller'
SET @val214 = 'Ben Miller'
SET @val215 = 'Ben Miller'
SET @val216 = 'Ben Miller'
SET @val217 = 'Ben Miller'
SET @val218 = 'Ben Miller'
SET @val219 = 'Ben Miller'
SET @val220 = 'Ben Miller'
SET @val221 = 'Ben Miller'
SET @val222 = 'Ben Miller'
SET @val223 = 'Ben Miller'
SET @val224 = 'Ben Miller'
SET @val225 = 'Ben Miller'
SET @val226 = 'Ben Miller'
SET @val227 = 'Ben Miller'
SET @val228 = 'Ben Miller'
SET @val229 = 'Ben Miller'
SET @val230 = 'Ben Miller'
SET @val231 = 'Ben Miller'
SET @val232 = 'Ben Miller'
SET @val233 = 'Ben Miller'
SET @val234 = 'Ben Miller'
SET @val235 = 'Ben Miller'
SET @val236 = 'Ben Miller'
SET @val237 = 'Ben Miller'
SET @val238 = 'Ben Miller'
SET @val239 = 'Ben Miller'
SET @val240 = 'Ben Miller'
SET @val241 = 'Ben Miller'
SET @val242 = 'Ben Miller'
SET @val243 = 'Ben Miller'
SET @val244 = 'Ben Miller'
SET @val245 = 'Ben Miller'
SET @val246 = 'Ben Miller'
SET @val247 = 'Ben Miller'
SET @val248 = 'Ben Miller'
SET @val249 = 'Ben Miller'
SET @val250 = 'Ben Miller'
SET @val251 = 'Ben Miller'
SET @val252 = 'Ben Miller'
SET @val253 = 'Ben Miller'
SET @val254 = 'Ben Miller'
SET @val255 = 'Ben Miller'
SET @val256 = 'Ben Miller'
SET @val257 = 'Ben Miller'
SET @val258 = 'Ben Miller'
SET @val259 = 'Ben Miller'
SET @val260 = 'Ben Miller'
SET @val261 = 'Ben Miller'
SET @val262 = 'Ben Miller'
SET @val263 = 'Ben Miller'
SET @val264 = 'Ben Miller'
SET @val265 = 'Ben Miller'
SET @val266 = 'Ben Miller'
SET @val267 = 'Ben Miller'
SET @val268 = 'Ben Miller'
SET @val269 = 'Ben Miller'
SET @val270 = 'Ben Miller'
SET @val271 = 'Ben Miller'
SET @val272 = 'Ben Miller'
SET @val273 = 'Ben Miller'
SET @val274 = 'Ben Miller'
SET @val275 = 'Ben Miller'
SET @val276 = 'Ben Miller'
SET @val277 = 'Ben Miller'
SET @val278 = 'Ben Miller'
SET @val279 = 'Ben Miller'
SET @val280 = 'Ben Miller'
SET @val281 = 'Ben Miller'
SET @val282 = 'Ben Miller'
SET @val283 = 'Ben Miller'
SET @val284 = 'Ben Miller'
SET @val285 = 'Ben Miller'
SET @val286 = 'Ben Miller'
SET @val287 = 'Ben Miller'
SET @val288 = 'Ben Miller'
SET @val289 = 'Ben Miller'
SET @val290 = 'Ben Miller'
SET @val291 = 'Ben Miller'
SET @val292 = 'Ben Miller'
SET @val293 = 'Ben Miller'
SET @val294 = 'Ben Miller'
SET @val295 = 'Ben Miller'
SET @val296 = 'Ben Miller'
SET @val297 = 'Ben Miller'
SET @val298 = 'Ben Miller'
SET @val299 = 'Ben Miller'
SET @val300 = 'Ben Miller'
SET @val301 = 'Ben Miller'
SET @val302 = 'Ben Miller'
SET @val303 = 'Ben Miller'
SET @val304 = 'Ben Miller'
SET @val305 = 'Ben Miller'
SET @val306 = 'Ben Miller'
SET @val307 = 'Ben Miller'
SET @val308 = 'Ben Miller'
SET @val309 = 'Ben Miller'
SET @val310 = 'Ben Miller'
SET @val311 = 'Ben Miller'
SET @val312 = 'Ben Miller'
SET @val313 = 'Ben Miller'
SET @val314 = 'Ben Miller'
SET @val315 = 'Ben Miller'
SET @val316 = 'Ben Miller'
SET @val317 = 'Ben Miller'
SET @val318 = 'Ben Miller'
SET @val319 = 'Ben Miller'
SET @val320 = 'Ben Miller'
SET @val321 = 'Ben Miller'
SET @val322 = 'Ben Miller'
SET @val323 = 'Ben Miller'
SET @val324 = 'Ben Miller'
SET @val325 = 'Ben Miller'
SET @val326 = 'Ben Miller'
SET @val327 = 'Ben Miller'
SET @val328 = 'Ben Miller'
SET @val329 = 'Ben Miller'
SET @val330 = 'Ben Miller'
SET @val331 = 'Ben Miller'
SET @val332 = 'Ben Miller'
SET @val333 = 'Ben Miller'
SET @val334 = 'Ben Miller'
SET @val335 = 'Ben Miller'
SET @val336 = 'Ben Miller'
SET @val337 = 'Ben Miller'
SET @val338 = 'Ben Miller'
SET @val339 = 'Ben Miller'
SET @val340 = 'Ben Miller'
SET @val341 = 'Ben Miller'
SET @val342 = 'Ben Miller'
SET @val343 = 'Ben Miller'
SET @val344 = 'Ben Miller'
SET @val345 = 'Ben Miller'
SET @val346 = 'Ben Miller'
SET @val347 = 'Ben Miller'
SET @val348 = 'Ben Miller'
SET @val349 = 'Ben Miller'
SET @val350 = 'Ben Miller'
SET @val351 = 'Ben Miller'
SET @val352 = 'Ben Miller'
SET @val353 = 'Ben Miller'
SET @val354 = 'Ben Miller'
SET @val355 = 'Ben Miller'
SET @val356 = 'Ben Miller'
SET @val357 = 'Ben Miller'
SET @val358 = 'Ben Miller'
SET @val359 = 'Ben Miller'
SET @val360 = 'Ben Miller'
SET @val361 = 'Ben Miller'
SET @val362 = 'Ben Miller'
SET @val363 = 'Ben Miller'
SET @val364 = 'Ben Miller'
SET @val365 = 'Ben Miller'
SET @val366 = 'Ben Miller'
SET @val367 = 'Ben Miller'
SET @val368 = 'Ben Miller'
SET @val369 = 'Ben Miller'
SET @val370 = 'Ben Miller'
SET @val371 = 'Ben Miller'
SET @val372 = 'Ben Miller'
SET @val373 = 'Ben Miller'
SET @val374 = 'Ben Miller'
SET @val375 = 'Ben Miller'
SET @val376 = 'Ben Miller'
SET @val377 = 'Ben Miller'
SET @val378 = 'Ben Miller'
SET @val379 = 'Ben Miller'
SET @val380 = 'Ben Miller'
SET @val381 = 'Ben Miller'
SET @val382 = 'Ben Miller'
SET @val383 = 'Ben Miller'
SET @val384 = 'Ben Miller'
SET @val385 = 'Ben Miller'
SET @val386 = 'Ben Miller'
SET @val387 = 'Ben Miller'
SET @val388 = 'Ben Miller'
SET @val389 = 'Ben Miller'
SET @val390 = 'Ben Miller'
SET @val391 = 'Ben Miller'
SET @val392 = 'Ben Miller'
SET @val393 = 'Ben Miller'
SET @val394 = 'Ben Miller'
SET @val395 = 'Ben Miller'
SET @val396 = 'Ben Miller'
SET @val397 = 'Ben Miller'
SET @val398 = 'Ben Miller'
SET @val399 = 'Ben Miller'
SET @val400 = 'Ben Miller'
SET @val401 = 'Ben Miller'
SET @val402 = 'Ben Miller'
SET @val403 = 'Ben Miller'
SET @val404 = 'Ben Miller'
SET @val405 = 'Ben Miller'
SET @val406 = 'Ben Miller'
SET @val407 = 'Ben Miller'
SET @val408 = 'Ben Miller'
SET @val409 = 'Ben Miller'
SET @val410 = 'Ben Miller'
SET @val411 = 'Ben Miller'
SET @val412 = 'Ben Miller'
SET @val413 = 'Ben Miller'
SET @val414 = 'Ben Miller'
SET @val415 = 'Ben Miller'
SET @val416 = 'Ben Miller'
SET @val417 = 'Ben Miller'
SET @val418 = 'Ben Miller'
SET @val419 = 'Ben Miller'
SET @val420 = 'Ben Miller'
SET @val421 = 'Ben Miller'
SET @val422 = 'Ben Miller'
SET @val423 = 'Ben Miller'
SET @val424 = 'Ben Miller'
SET @val425 = 'Ben Miller'
SET @val426 = 'Ben Miller'
SET @val427 = 'Ben Miller'
SET @val428 = 'Ben Miller'
SET @val429 = 'Ben Miller'
SET @val430 = 'Ben Miller'
SET @val431 = 'Ben Miller'
SET @val432 = 'Ben Miller'
SET @val433 = 'Ben Miller'
SET @val434 = 'Ben Miller'
SET @val435 = 'Ben Miller'
SET @val436 = 'Ben Miller'
SET @val437 = 'Ben Miller'
SET @val438 = 'Ben Miller'
SET @val439 = 'Ben Miller'
SET @val440 = 'Ben Miller'
SET @val441 = 'Ben Miller'
SET @val442 = 'Ben Miller'
SET @val443 = 'Ben Miller'
SET @val444 = 'Ben Miller'
SET @val445 = 'Ben Miller'
SET @val446 = 'Ben Miller'
SET @val447 = 'Ben Miller'
SET @val448 = 'Ben Miller'
SET @val449 = 'Ben Miller'
SET @val450 = 'Ben Miller'
SET @val451 = 'Ben Miller'
SET @val452 = 'Ben Miller'
SET @val453 = 'Ben Miller'
SET @val454 = 'Ben Miller'
SET @val455 = 'Ben Miller'
SET @val456 = 'Ben Miller'
SET @val457 = 'Ben Miller'
SET @val458 = 'Ben Miller'
SET @val459 = 'Ben Miller'
SET @val460 = 'Ben Miller'
SET @val461 = 'Ben Miller'
SET @val462 = 'Ben Miller'
SET @val463 = 'Ben Miller'
SET @val464 = 'Ben Miller'
SET @val465 = 'Ben Miller'
SET @val466 = 'Ben Miller'
SET @val467 = 'Ben Miller'
SET @val468 = 'Ben Miller'
SET @val469 = 'Ben Miller'
SET @val470 = 'Ben Miller'
SET @val471 = 'Ben Miller'
SET @val472 = 'Ben Miller'
SET @val473 = 'Ben Miller'
SET @val474 = 'Ben Miller'
SET @val475 = 'Ben Miller'
SET @val476 = 'Ben Miller'
SET @val477 = 'Ben Miller'
SET @val478 = 'Ben Miller'
SET @val479 = 'Ben Miller'
SET @val480 = 'Ben Miller'
SET @val481 = 'Ben Miller'
SET @val482 = 'Ben Miller'
SET @val483 = 'Ben Miller'
SET @val484 = 'Ben Miller'
SET @val485 = 'Ben Miller'
SET @val486 = 'Ben Miller'
SET @val487 = 'Ben Miller'
SET @val488 = 'Ben Miller'
SET @val489 = 'Ben Miller'
SET @val490 = 'Ben Miller'
SET @val491 = 'Ben Miller'
SET @val492 = 'Ben Miller'
SET @val493 = 'Ben Miller'
SET @val494 = 'Ben Miller'
SET @val495 = 'Ben Miller'
SET @val496 = 'Ben Miller'
SET @val497 = 'Ben Miller'
SET @val498 = 'Ben Miller'
SET @val499 = 'Ben Miller'
SET @val500 = 'Ben Miller'
SET @val501 = 'Ben Miller'
SET @val502 = 'Ben Miller'
SET @val503 = 'Ben Miller'
SET @val504 = 'Ben Miller'
SET @val505 = 'Ben Miller'
SET @val506 = 'Ben Miller'
SET @val507 = 'Ben Miller'
SET @val508 = 'Ben Miller'
SET @val509 = 'Ben Miller'
SET @val510 = 'Ben Miller'
SET @val511 = 'Ben Miller'
SET @val512 = 'Ben Miller'
SET @val513 = 'Ben Miller'
SET @val514 = 'Ben Miller'
SET @val515 = 'Ben Miller'
SET @val516 = 'Ben Miller'
SET @val517 = 'Ben Miller'
SET @val518 = 'Ben Miller'
SET @val519 = 'Ben Miller'
SET @val520 = 'Ben Miller'
SET @val521 = 'Ben Miller'
SET @val522 = 'Ben Miller'
SET @val523 = 'Ben Miller'
SET @val524 = 'Ben Miller'
SET @val525 = 'Ben Miller'
SET @val526 = 'Ben Miller'
SET @val527 = 'Ben Miller'
SET @val528 = 'Ben Miller'
SET @val529 = 'Ben Miller'
SET @val530 = 'Ben Miller'
SET @val531 = 'Ben Miller'
SET @val532 = 'Ben Miller'
SET @val533 = 'Ben Miller'
SET @val534 = 'Ben Miller'
SET @val535 = 'Ben Miller'
SET @val536 = 'Ben Miller'
SET @val537 = 'Ben Miller'
SET @val538 = 'Ben Miller'
SET @val539 = 'Ben Miller'
SET @val540 = 'Ben Miller'
SET @val541 = 'Ben Miller'
SET @val542 = 'Ben Miller'
SET @val543 = 'Ben Miller'
SET @val544 = 'Ben Miller'
SET @val545 = 'Ben Miller'
SET @val546 = 'Ben Miller'
SET @val547 = 'Ben Miller'
SET @val548 = 'Ben Miller'
SET @val549 = 'Ben Miller'
SET @val550 = 'Ben Miller'
SET @val551 = 'Ben Miller'
SET @val552 = 'Ben Miller'
SET @val553 = 'Ben Miller'
SET @val554 = 'Ben Miller'
SET @val555 = 'Ben Miller'
SET @val556 = 'Ben Miller'
SET @val557 = 'Ben Miller'
SET @val558 = 'Ben Miller'
SET @val559 = 'Ben Miller'
SET @val560 = 'Ben Miller'
SET @val561 = 'Ben Miller'
SET @val562 = 'Ben Miller'
SET @val563 = 'Ben Miller'
SET @val564 = 'Ben Miller'
SET @val565 = 'Ben Miller'
SET @val566 = 'Ben Miller'
SET @val567 = 'Ben Miller'
SET @val568 = 'Ben Miller'
SET @val569 = 'Ben Miller'
SET @val570 = 'Ben Miller'
SET @val571 = 'Ben Miller'
SET @val572 = 'Ben Miller'
SET @val573 = 'Ben Miller'
SET @val574 = 'Ben Miller'
SET @val575 = 'Ben Miller'
SET @val576 = 'Ben Miller'
SET @val577 = 'Ben Miller'
SET @val578 = 'Ben Miller'
SET @val579 = 'Ben Miller'
SET @val580 = 'Ben Miller'
SET @val581 = 'Ben Miller'
SET @val582 = 'Ben Miller'
SET @val583 = 'Ben Miller'
SET @val584 = 'Ben Miller'
SET @val585 = 'Ben Miller'
SET @val586 = 'Ben Miller'
SET @val587 = 'Ben Miller'
SET @val588 = 'Ben Miller'
SET @val589 = 'Ben Miller'
SET @val590 = 'Ben Miller'
SET @val591 = 'Ben Miller'
SET @val592 = 'Ben Miller'
SET @val593 = 'Ben Miller'
SET @val594 = 'Ben Miller'
SET @val595 = 'Ben Miller'
SET @val596 = 'Ben Miller'
SET @val597 = 'Ben Miller'
SET @val598 = 'Ben Miller'
SET @val599 = 'Ben Miller'
SET @val600 = 'Ben Miller'
SET @val601 = 'Ben Miller'
SET @val602 = 'Ben Miller'
SET @val603 = 'Ben Miller'
SET @val604 = 'Ben Miller'
SET @val605 = 'Ben Miller'
SET @val606 = 'Ben Miller'
SET @val607 = 'Ben Miller'
SET @val608 = 'Ben Miller'
SET @val609 = 'Ben Miller'
SET @val610 = 'Ben Miller'
SET @val611 = 'Ben Miller'
SET @val612 = 'Ben Miller'
SET @val613 = 'Ben Miller'
SET @val614 = 'Ben Miller'
SET @val615 = 'Ben Miller'
SET @val616 = 'Ben Miller'
SET @val617 = 'Ben Miller'
SET @val618 = 'Ben Miller'
SET @val619 = 'Ben Miller'
SET @val620 = 'Ben Miller'
SET @val621 = 'Ben Miller'
SET @val622 = 'Ben Miller'
SET @val623 = 'Ben Miller'
SET @val624 = 'Ben Miller'
SET @val625 = 'Ben Miller'
SET @val626 = 'Ben Miller'
SET @val627 = 'Ben Miller'
SET @val628 = 'Ben Miller'
SET @val629 = 'Ben Miller'
SET @val630 = 'Ben Miller'
SET @val631 = 'Ben Miller'
SET @val632 = 'Ben Miller'
SET @val633 = 'Ben Miller'
SET @val634 = 'Ben Miller'
SET @val635 = 'Ben Miller'
SET @val636 = 'Ben Miller'
SET @val637 = 'Ben Miller'
SET @val638 = 'Ben Miller'
SET @val639 = 'Ben Miller'
SET @val640 = 'Ben Miller'
SET @val641 = 'Ben Miller'
SET @val642 = 'Ben Miller'
SET @val643 = 'Ben Miller'
SET @val644 = 'Ben Miller'
SET @val645 = 'Ben Miller'
SET @val646 = 'Ben Miller'
SET @val647 = 'Ben Miller'
SET @val648 = 'Ben Miller'
SET @val649 = 'Ben Miller'
SET @val650 = 'Ben Miller'
SET @val651 = 'Ben Miller'
SET @val652 = 'Ben Miller'
SET @val653 = 'Ben Miller'
SET @val654 = 'Ben Miller'
SET @val655 = 'Ben Miller'
SET @val656 = 'Ben Miller'
SET @val657 = 'Ben Miller'
SET @val658 = 'Ben Miller'
SET @val659 = 'Ben Miller'
SET @val660 = 'Ben Miller'
SET @val661 = 'Ben Miller'
SET @val662 = 'Ben Miller'
SET @val663 = 'Ben Miller'
SET @val664 = 'Ben Miller'
SET @val665 = 'Ben Miller'
SET @val666 = 'Ben Miller'
SET @val667 = 'Ben Miller'
SET @val668 = 'Ben Miller'
SET @val669 = 'Ben Miller'
SET @val670 = 'Ben Miller'
SET @val671 = 'Ben Miller'
SET @val672 = 'Ben Miller'
SET @val673 = 'Ben Miller'
SET @val674 = 'Ben Miller'
SET @val675 = 'Ben Miller'
SET @val676 = 'Ben Miller'
SET @val677 = 'Ben Miller'
SET @val678 = 'Ben Miller'
SET @val679 = 'Ben Miller'
SET @val680 = 'Ben Miller'
SET @val681 = 'Ben Miller'
SET @val682 = 'Ben Miller'
SET @val683 = 'Ben Miller'
SET @val684 = 'Ben Miller'
SET @val685 = 'Ben Miller'
SET @val686 = 'Ben Miller'
SET @val687 = 'Ben Miller'
SET @val688 = 'Ben Miller'
SET @val689 = 'Ben Miller'
SET @val690 = 'Ben Miller'
SET @val691 = 'Ben Miller'
SET @val692 = 'Ben Miller'
SET @val693 = 'Ben Miller'
SET @val694 = 'Ben Miller'
SET @val695 = 'Ben Miller'
SET @val696 = 'Ben Miller'
SET @val697 = 'Ben Miller'
SET @val698 = 'Ben Miller'
SET @val699 = 'Ben Miller'
SET @val700 = 'Ben Miller'
SET @val701 = 'Ben Miller'
SET @val702 = 'Ben Miller'
SET @val703 = 'Ben Miller'
SET @val704 = 'Ben Miller'
SET @val705 = 'Ben Miller'
SET @val706 = 'Ben Miller'
SET @val707 = 'Ben Miller'
SET @val708 = 'Ben Miller'
SET @val709 = 'Ben Miller'
SET @val710 = 'Ben Miller'
SET @val711 = 'Ben Miller'
SET @val712 = 'Ben Miller'
SET @val713 = 'Ben Miller'
SET @val714 = 'Ben Miller'
SET @val715 = 'Ben Miller'
SET @val716 = 'Ben Miller'
SET @val717 = 'Ben Miller'
SET @val718 = 'Ben Miller'
SET @val719 = 'Ben Miller'
SET @val720 = 'Ben Miller'
SET @val721 = 'Ben Miller'
SET @val722 = 'Ben Miller'
SET @val723 = 'Ben Miller'
SET @val724 = 'Ben Miller'
SET @val725 = 'Ben Miller'
SET @val726 = 'Ben Miller'
SET @val727 = 'Ben Miller'
SET @val728 = 'Ben Miller'
SET @val729 = 'Ben Miller'
SET @val730 = 'Ben Miller'
SET @val731 = 'Ben Miller'
SET @val732 = 'Ben Miller'
SET @val733 = 'Ben Miller'
SET @val734 = 'Ben Miller'
SET @val735 = 'Ben Miller'
SET @val736 = 'Ben Miller'
SET @val737 = 'Ben Miller'
SET @val738 = 'Ben Miller'
SET @val739 = 'Ben Miller'
SET @val740 = 'Ben Miller'
SET @val741 = 'Ben Miller'
SET @val742 = 'Ben Miller'
SET @val743 = 'Ben Miller'
SET @val744 = 'Ben Miller'
SET @val745 = 'Ben Miller'
SET @val746 = 'Ben Miller'
SET @val747 = 'Ben Miller'
SET @val748 = 'Ben Miller'
SET @val749 = 'Ben Miller'
SET @val750 = 'Ben Miller'
SET @val751 = 'Ben Miller'
SET @val752 = 'Ben Miller'
SET @val753 = 'Ben Miller'
SET @val754 = 'Ben Miller'
SET @val755 = 'Ben Miller'
SET @val756 = 'Ben Miller'
SET @val757 = 'Ben Miller'
SET @val758 = 'Ben Miller'
SET @val759 = 'Ben Miller'
SET @val760 = 'Ben Miller'
SET @val761 = 'Ben Miller'
SET @val762 = 'Ben Miller'
SET @val763 = 'Ben Miller'
SET @val764 = 'Ben Miller'
SET @val765 = 'Ben Miller'
SET @val766 = 'Ben Miller'
SET @val767 = 'Ben Miller'
SET @val768 = 'Ben Miller'
SET @val769 = 'Ben Miller'
SET @val770 = 'Ben Miller'
SET @val771 = 'Ben Miller'
SET @val772 = 'Ben Miller'
SET @val773 = 'Ben Miller'
SET @val774 = 'Ben Miller'
SET @val775 = 'Ben Miller'
SET @val776 = 'Ben Miller'
SET @val777 = 'Ben Miller'
SET @val778 = 'Ben Miller'
SET @val779 = 'Ben Miller'
SET @val780 = 'Ben Miller'
SET @val781 = 'Ben Miller'
SET @val782 = 'Ben Miller'
SET @val783 = 'Ben Miller'
SET @val784 = 'Ben Miller'
SET @val785 = 'Ben Miller'
SET @val786 = 'Ben Miller'
SET @val787 = 'Ben Miller'
SET @val788 = 'Ben Miller'
SET @val789 = 'Ben Miller'
SET @val790 = 'Ben Miller'
SET @val791 = 'Ben Miller'
SET @val792 = 'Ben Miller'
SET @val793 = 'Ben Miller'
SET @val794 = 'Ben Miller'
SET @val795 = 'Ben Miller'
SET @val796 = 'Ben Miller'
SET @val797 = 'Ben Miller'
SET @val798 = 'Ben Miller'
SET @val799 = 'Ben Miller'
SET @val800 = 'Ben Miller'
SET @val801 = 'Ben Miller'
SET @val802 = 'Ben Miller'
SET @val803 = 'Ben Miller'
SET @val804 = 'Ben Miller'
SET @val805 = 'Ben Miller'
SET @val806 = 'Ben Miller'
SET @val807 = 'Ben Miller'
SET @val808 = 'Ben Miller'
SET @val809 = 'Ben Miller'
SET @val810 = 'Ben Miller'
SET @val811 = 'Ben Miller'
SET @val812 = 'Ben Miller'
SET @val813 = 'Ben Miller'
SET @val814 = 'Ben Miller'
SET @val815 = 'Ben Miller'
SET @val816 = 'Ben Miller'
SET @val817 = 'Ben Miller'
SET @val818 = 'Ben Miller'
SET @val819 = 'Ben Miller'
SET @val820 = 'Ben Miller'
SET @val821 = 'Ben Miller'
SET @val822 = 'Ben Miller'
SET @val823 = 'Ben Miller'
SET @val824 = 'Ben Miller'
SET @val825 = 'Ben Miller'
SET @val826 = 'Ben Miller'
SET @val827 = 'Ben Miller'
SET @val828 = 'Ben Miller'
SET @val829 = 'Ben Miller'
SET @val830 = 'Ben Miller'
SET @val831 = 'Ben Miller'
SET @val832 = 'Ben Miller'
SET @val833 = 'Ben Miller'
SET @val834 = 'Ben Miller'
SET @val835 = 'Ben Miller'
SET @val836 = 'Ben Miller'
SET @val837 = 'Ben Miller'
SET @val838 = 'Ben Miller'
SET @val839 = 'Ben Miller'
SET @val840 = 'Ben Miller'
SET @val841 = 'Ben Miller'
SET @val842 = 'Ben Miller'
SET @val843 = 'Ben Miller'
SET @val844 = 'Ben Miller'
SET @val845 = 'Ben Miller'
SET @val846 = 'Ben Miller'
SET @val847 = 'Ben Miller'
SET @val848 = 'Ben Miller'
SET @val849 = 'Ben Miller'
SET @val850 = 'Ben Miller'
SET @val851 = 'Ben Miller'
SET @val852 = 'Ben Miller'
SET @val853 = 'Ben Miller'
SET @val854 = 'Ben Miller'
SET @val855 = 'Ben Miller'
SET @val856 = 'Ben Miller'
SET @val857 = 'Ben Miller'
SET @val858 = 'Ben Miller'
SET @val859 = 'Ben Miller'
SET @val860 = 'Ben Miller'
SET @val861 = 'Ben Miller'
SET @val862 = 'Ben Miller'
SET @val863 = 'Ben Miller'
SET @val864 = 'Ben Miller'
SET @val865 = 'Ben Miller'
SET @val866 = 'Ben Miller'
SET @val867 = 'Ben Miller'
SET @val868 = 'Ben Miller'
SET @val869 = 'Ben Miller'
SET @val870 = 'Ben Miller'
SET @val871 = 'Ben Miller'
SET @val872 = 'Ben Miller'
SET @val873 = 'Ben Miller'
SET @val874 = 'Ben Miller'
SET @val875 = 'Ben Miller'
SET @val876 = 'Ben Miller'
SET @val877 = 'Ben Miller'
SET @val878 = 'Ben Miller'
SET @val879 = 'Ben Miller'
SET @val880 = 'Ben Miller'
SET @val881 = 'Ben Miller'
SET @val882 = 'Ben Miller'
SET @val883 = 'Ben Miller'
SET @val884 = 'Ben Miller'
SET @val885 = 'Ben Miller'
SET @val886 = 'Ben Miller'
SET @val887 = 'Ben Miller'
SET @val888 = 'Ben Miller'
SET @val889 = 'Ben Miller'
SET @val890 = 'Ben Miller'
SET @val891 = 'Ben Miller'
SET @val892 = 'Ben Miller'
SET @val893 = 'Ben Miller'
SET @val894 = 'Ben Miller'
SET @val895 = 'Ben Miller'
SET @val896 = 'Ben Miller'
SET @val897 = 'Ben Miller'
SET @val898 = 'Ben Miller'
SET @val899 = 'Ben Miller'
SET @val900 = 'Ben Miller'
SET @val901 = 'Ben Miller'
SET @val902 = 'Ben Miller'
SET @val903 = 'Ben Miller'
SET @val904 = 'Ben Miller'
SET @val905 = 'Ben Miller'
SET @val906 = 'Ben Miller'
SET @val907 = 'Ben Miller'
SET @val908 = 'Ben Miller'
SET @val909 = 'Ben Miller'
SET @val910 = 'Ben Miller'
SET @val911 = 'Ben Miller'
SET @val912 = 'Ben Miller'
SET @val913 = 'Ben Miller'
SET @val914 = 'Ben Miller'
SET @val915 = 'Ben Miller'
SET @val916 = 'Ben Miller'
SET @val917 = 'Ben Miller'
SET @val918 = 'Ben Miller'
SET @val919 = 'Ben Miller'
SET @val920 = 'Ben Miller'
SET @val921 = 'Ben Miller'
SET @val922 = 'Ben Miller'
SET @val923 = 'Ben Miller'
SET @val924 = 'Ben Miller'
SET @val925 = 'Ben Miller'
SET @val926 = 'Ben Miller'
SET @val927 = 'Ben Miller'
SET @val928 = 'Ben Miller'
SET @val929 = 'Ben Miller'
SET @val930 = 'Ben Miller'
SET @val931 = 'Ben Miller'
SET @val932 = 'Ben Miller'
SET @val933 = 'Ben Miller'
SET @val934 = 'Ben Miller'
SET @val935 = 'Ben Miller'
SET @val936 = 'Ben Miller'
SET @val937 = 'Ben Miller'
SET @val938 = 'Ben Miller'
SET @val939 = 'Ben Miller'
SET @val940 = 'Ben Miller'
SET @val941 = 'Ben Miller'
SET @val942 = 'Ben Miller'
SET @val943 = 'Ben Miller'
SET @val944 = 'Ben Miller'
SET @val945 = 'Ben Miller'
SET @val946 = 'Ben Miller'
SET @val947 = 'Ben Miller'
SET @val948 = 'Ben Miller'
SET @val949 = 'Ben Miller'
SET @val950 = 'Ben Miller'
SET @val951 = 'Ben Miller'
SET @val952 = 'Ben Miller'
SET @val953 = 'Ben Miller'
SET @val954 = 'Ben Miller'
SET @val955 = 'Ben Miller'
SET @val956 = 'Ben Miller'
SET @val957 = 'Ben Miller'
SET @val958 = 'Ben Miller'
SET @val959 = 'Ben Miller'
SET @val960 = 'Ben Miller'
SET @val961 = 'Ben Miller'
SET @val962 = 'Ben Miller'
SET @val963 = 'Ben Miller'
SET @val964 = 'Ben Miller'
SET @val965 = 'Ben Miller'
SET @val966 = 'Ben Miller'
SET @val967 = 'Ben Miller'
SET @val968 = 'Ben Miller'
SET @val969 = 'Ben Miller'
SET @val970 = 'Ben Miller'
SET @val971 = 'Ben Miller'
SET @val972 = 'Ben Miller'
SET @val973 = 'Ben Miller'
SET @val974 = 'Ben Miller'
SET @val975 = 'Ben Miller'
SET @val976 = 'Ben Miller'
SET @val977 = 'Ben Miller'
SET @val978 = 'Ben Miller'
SET @val979 = 'Ben Miller'
SET @val980 = 'Ben Miller'
SET @val981 = 'Ben Miller'
SET @val982 = 'Ben Miller'
SET @val983 = 'Ben Miller'
SET @val984 = 'Ben Miller'
SET @val985 = 'Ben Miller'
SET @val986 = 'Ben Miller'
SET @val987 = 'Ben Miller'
SET @val988 = 'Ben Miller'
SET @val989 = 'Ben Miller'
SET @val990 = 'Ben Miller'
SET @val991 = 'Ben Miller'
SET @val992 = 'Ben Miller'
SET @val993 = 'Ben Miller'
SET @val994 = 'Ben Miller'
SET @val995 = 'Ben Miller'
SET @val996 = 'Ben Miller'
SET @val997 = 'Ben Miller'
SET @val998 = 'Ben Miller'
SET @val999 = 'Ben Miller'
SET @val1000 = 'Ben Miller'
GO

DECLARE @val1 varchar(20)
,@val2 varchar(20)
,@val3 varchar(20)
,@val4 varchar(20)
,@val5 varchar(20)
,@val6 varchar(20)
,@val7 varchar(20)
,@val8 varchar(20)
,@val9 varchar(20)
,@val10 varchar(20)
,@val11 varchar(20)
,@val12 varchar(20)
,@val13 varchar(20)
,@val14 varchar(20)
,@val15 varchar(20)
,@val16 varchar(20)
,@val17 varchar(20)
,@val18 varchar(20)
,@val19 varchar(20)
,@val20 varchar(20)
,@val21 varchar(20)
,@val22 varchar(20)
,@val23 varchar(20)
,@val24 varchar(20)
,@val25 varchar(20)
,@val26 varchar(20)
,@val27 varchar(20)
,@val28 varchar(20)
,@val29 varchar(20)
,@val30 varchar(20)
,@val31 varchar(20)
,@val32 varchar(20)
,@val33 varchar(20)
,@val34 varchar(20)
,@val35 varchar(20)
,@val36 varchar(20)
,@val37 varchar(20)
,@val38 varchar(20)
,@val39 varchar(20)
,@val40 varchar(20)
,@val41 varchar(20)
,@val42 varchar(20)
,@val43 varchar(20)
,@val44 varchar(20)
,@val45 varchar(20)
,@val46 varchar(20)
,@val47 varchar(20)
,@val48 varchar(20)
,@val49 varchar(20)
,@val50 varchar(20)
,@val51 varchar(20)
,@val52 varchar(20)
,@val53 varchar(20)
,@val54 varchar(20)
,@val55 varchar(20)
,@val56 varchar(20)
,@val57 varchar(20)
,@val58 varchar(20)
,@val59 varchar(20)
,@val60 varchar(20)
,@val61 varchar(20)
,@val62 varchar(20)
,@val63 varchar(20)
,@val64 varchar(20)
,@val65 varchar(20)
,@val66 varchar(20)
,@val67 varchar(20)
,@val68 varchar(20)
,@val69 varchar(20)
,@val70 varchar(20)
,@val71 varchar(20)
,@val72 varchar(20)
,@val73 varchar(20)
,@val74 varchar(20)
,@val75 varchar(20)
,@val76 varchar(20)
,@val77 varchar(20)
,@val78 varchar(20)
,@val79 varchar(20)
,@val80 varchar(20)
,@val81 varchar(20)
,@val82 varchar(20)
,@val83 varchar(20)
,@val84 varchar(20)
,@val85 varchar(20)
,@val86 varchar(20)
,@val87 varchar(20)
,@val88 varchar(20)
,@val89 varchar(20)
,@val90 varchar(20)
,@val91 varchar(20)
,@val92 varchar(20)
,@val93 varchar(20)
,@val94 varchar(20)
,@val95 varchar(20)
,@val96 varchar(20)
,@val97 varchar(20)
,@val98 varchar(20)
,@val99 varchar(20)
,@val100 varchar(20)
,@val101 varchar(20)
,@val102 varchar(20)
,@val103 varchar(20)
,@val104 varchar(20)
,@val105 varchar(20)
,@val106 varchar(20)
,@val107 varchar(20)
,@val108 varchar(20)
,@val109 varchar(20)
,@val110 varchar(20)
,@val111 varchar(20)
,@val112 varchar(20)
,@val113 varchar(20)
,@val114 varchar(20)
,@val115 varchar(20)
,@val116 varchar(20)
,@val117 varchar(20)
,@val118 varchar(20)
,@val119 varchar(20)
,@val120 varchar(20)
,@val121 varchar(20)
,@val122 varchar(20)
,@val123 varchar(20)
,@val124 varchar(20)
,@val125 varchar(20)
,@val126 varchar(20)
,@val127 varchar(20)
,@val128 varchar(20)
,@val129 varchar(20)
,@val130 varchar(20)
,@val131 varchar(20)
,@val132 varchar(20)
,@val133 varchar(20)
,@val134 varchar(20)
,@val135 varchar(20)
,@val136 varchar(20)
,@val137 varchar(20)
,@val138 varchar(20)
,@val139 varchar(20)
,@val140 varchar(20)
,@val141 varchar(20)
,@val142 varchar(20)
,@val143 varchar(20)
,@val144 varchar(20)
,@val145 varchar(20)
,@val146 varchar(20)
,@val147 varchar(20)
,@val148 varchar(20)
,@val149 varchar(20)
,@val150 varchar(20)
,@val151 varchar(20)
,@val152 varchar(20)
,@val153 varchar(20)
,@val154 varchar(20)
,@val155 varchar(20)
,@val156 varchar(20)
,@val157 varchar(20)
,@val158 varchar(20)
,@val159 varchar(20)
,@val160 varchar(20)
,@val161 varchar(20)
,@val162 varchar(20)
,@val163 varchar(20)
,@val164 varchar(20)
,@val165 varchar(20)
,@val166 varchar(20)
,@val167 varchar(20)
,@val168 varchar(20)
,@val169 varchar(20)
,@val170 varchar(20)
,@val171 varchar(20)
,@val172 varchar(20)
,@val173 varchar(20)
,@val174 varchar(20)
,@val175 varchar(20)
,@val176 varchar(20)
,@val177 varchar(20)
,@val178 varchar(20)
,@val179 varchar(20)
,@val180 varchar(20)
,@val181 varchar(20)
,@val182 varchar(20)
,@val183 varchar(20)
,@val184 varchar(20)
,@val185 varchar(20)
,@val186 varchar(20)
,@val187 varchar(20)
,@val188 varchar(20)
,@val189 varchar(20)
,@val190 varchar(20)
,@val191 varchar(20)
,@val192 varchar(20)
,@val193 varchar(20)
,@val194 varchar(20)
,@val195 varchar(20)
,@val196 varchar(20)
,@val197 varchar(20)
,@val198 varchar(20)
,@val199 varchar(20)
,@val200 varchar(20)
,@val201 varchar(20)
,@val202 varchar(20)
,@val203 varchar(20)
,@val204 varchar(20)
,@val205 varchar(20)
,@val206 varchar(20)
,@val207 varchar(20)
,@val208 varchar(20)
,@val209 varchar(20)
,@val210 varchar(20)
,@val211 varchar(20)
,@val212 varchar(20)
,@val213 varchar(20)
,@val214 varchar(20)
,@val215 varchar(20)
,@val216 varchar(20)
,@val217 varchar(20)
,@val218 varchar(20)
,@val219 varchar(20)
,@val220 varchar(20)
,@val221 varchar(20)
,@val222 varchar(20)
,@val223 varchar(20)
,@val224 varchar(20)
,@val225 varchar(20)
,@val226 varchar(20)
,@val227 varchar(20)
,@val228 varchar(20)
,@val229 varchar(20)
,@val230 varchar(20)
,@val231 varchar(20)
,@val232 varchar(20)
,@val233 varchar(20)
,@val234 varchar(20)
,@val235 varchar(20)
,@val236 varchar(20)
,@val237 varchar(20)
,@val238 varchar(20)
,@val239 varchar(20)
,@val240 varchar(20)
,@val241 varchar(20)
,@val242 varchar(20)
,@val243 varchar(20)
,@val244 varchar(20)
,@val245 varchar(20)
,@val246 varchar(20)
,@val247 varchar(20)
,@val248 varchar(20)
,@val249 varchar(20)
,@val250 varchar(20)
,@val251 varchar(20)
,@val252 varchar(20)
,@val253 varchar(20)
,@val254 varchar(20)
,@val255 varchar(20)
,@val256 varchar(20)
,@val257 varchar(20)
,@val258 varchar(20)
,@val259 varchar(20)
,@val260 varchar(20)
,@val261 varchar(20)
,@val262 varchar(20)
,@val263 varchar(20)
,@val264 varchar(20)
,@val265 varchar(20)
,@val266 varchar(20)
,@val267 varchar(20)
,@val268 varchar(20)
,@val269 varchar(20)
,@val270 varchar(20)
,@val271 varchar(20)
,@val272 varchar(20)
,@val273 varchar(20)
,@val274 varchar(20)
,@val275 varchar(20)
,@val276 varchar(20)
,@val277 varchar(20)
,@val278 varchar(20)
,@val279 varchar(20)
,@val280 varchar(20)
,@val281 varchar(20)
,@val282 varchar(20)
,@val283 varchar(20)
,@val284 varchar(20)
,@val285 varchar(20)
,@val286 varchar(20)
,@val287 varchar(20)
,@val288 varchar(20)
,@val289 varchar(20)
,@val290 varchar(20)
,@val291 varchar(20)
,@val292 varchar(20)
,@val293 varchar(20)
,@val294 varchar(20)
,@val295 varchar(20)
,@val296 varchar(20)
,@val297 varchar(20)
,@val298 varchar(20)
,@val299 varchar(20)
,@val300 varchar(20)
,@val301 varchar(20)
,@val302 varchar(20)
,@val303 varchar(20)
,@val304 varchar(20)
,@val305 varchar(20)
,@val306 varchar(20)
,@val307 varchar(20)
,@val308 varchar(20)
,@val309 varchar(20)
,@val310 varchar(20)
,@val311 varchar(20)
,@val312 varchar(20)
,@val313 varchar(20)
,@val314 varchar(20)
,@val315 varchar(20)
,@val316 varchar(20)
,@val317 varchar(20)
,@val318 varchar(20)
,@val319 varchar(20)
,@val320 varchar(20)
,@val321 varchar(20)
,@val322 varchar(20)
,@val323 varchar(20)
,@val324 varchar(20)
,@val325 varchar(20)
,@val326 varchar(20)
,@val327 varchar(20)
,@val328 varchar(20)
,@val329 varchar(20)
,@val330 varchar(20)
,@val331 varchar(20)
,@val332 varchar(20)
,@val333 varchar(20)
,@val334 varchar(20)
,@val335 varchar(20)
,@val336 varchar(20)
,@val337 varchar(20)
,@val338 varchar(20)
,@val339 varchar(20)
,@val340 varchar(20)
,@val341 varchar(20)
,@val342 varchar(20)
,@val343 varchar(20)
,@val344 varchar(20)
,@val345 varchar(20)
,@val346 varchar(20)
,@val347 varchar(20)
,@val348 varchar(20)
,@val349 varchar(20)
,@val350 varchar(20)
,@val351 varchar(20)
,@val352 varchar(20)
,@val353 varchar(20)
,@val354 varchar(20)
,@val355 varchar(20)
,@val356 varchar(20)
,@val357 varchar(20)
,@val358 varchar(20)
,@val359 varchar(20)
,@val360 varchar(20)
,@val361 varchar(20)
,@val362 varchar(20)
,@val363 varchar(20)
,@val364 varchar(20)
,@val365 varchar(20)
,@val366 varchar(20)
,@val367 varchar(20)
,@val368 varchar(20)
,@val369 varchar(20)
,@val370 varchar(20)
,@val371 varchar(20)
,@val372 varchar(20)
,@val373 varchar(20)
,@val374 varchar(20)
,@val375 varchar(20)
,@val376 varchar(20)
,@val377 varchar(20)
,@val378 varchar(20)
,@val379 varchar(20)
,@val380 varchar(20)
,@val381 varchar(20)
,@val382 varchar(20)
,@val383 varchar(20)
,@val384 varchar(20)
,@val385 varchar(20)
,@val386 varchar(20)
,@val387 varchar(20)
,@val388 varchar(20)
,@val389 varchar(20)
,@val390 varchar(20)
,@val391 varchar(20)
,@val392 varchar(20)
,@val393 varchar(20)
,@val394 varchar(20)
,@val395 varchar(20)
,@val396 varchar(20)
,@val397 varchar(20)
,@val398 varchar(20)
,@val399 varchar(20)
,@val400 varchar(20)
,@val401 varchar(20)
,@val402 varchar(20)
,@val403 varchar(20)
,@val404 varchar(20)
,@val405 varchar(20)
,@val406 varchar(20)
,@val407 varchar(20)
,@val408 varchar(20)
,@val409 varchar(20)
,@val410 varchar(20)
,@val411 varchar(20)
,@val412 varchar(20)
,@val413 varchar(20)
,@val414 varchar(20)
,@val415 varchar(20)
,@val416 varchar(20)
,@val417 varchar(20)
,@val418 varchar(20)
,@val419 varchar(20)
,@val420 varchar(20)
,@val421 varchar(20)
,@val422 varchar(20)
,@val423 varchar(20)
,@val424 varchar(20)
,@val425 varchar(20)
,@val426 varchar(20)
,@val427 varchar(20)
,@val428 varchar(20)
,@val429 varchar(20)
,@val430 varchar(20)
,@val431 varchar(20)
,@val432 varchar(20)
,@val433 varchar(20)
,@val434 varchar(20)
,@val435 varchar(20)
,@val436 varchar(20)
,@val437 varchar(20)
,@val438 varchar(20)
,@val439 varchar(20)
,@val440 varchar(20)
,@val441 varchar(20)
,@val442 varchar(20)
,@val443 varchar(20)
,@val444 varchar(20)
,@val445 varchar(20)
,@val446 varchar(20)
,@val447 varchar(20)
,@val448 varchar(20)
,@val449 varchar(20)
,@val450 varchar(20)
,@val451 varchar(20)
,@val452 varchar(20)
,@val453 varchar(20)
,@val454 varchar(20)
,@val455 varchar(20)
,@val456 varchar(20)
,@val457 varchar(20)
,@val458 varchar(20)
,@val459 varchar(20)
,@val460 varchar(20)
,@val461 varchar(20)
,@val462 varchar(20)
,@val463 varchar(20)
,@val464 varchar(20)
,@val465 varchar(20)
,@val466 varchar(20)
,@val467 varchar(20)
,@val468 varchar(20)
,@val469 varchar(20)
,@val470 varchar(20)
,@val471 varchar(20)
,@val472 varchar(20)
,@val473 varchar(20)
,@val474 varchar(20)
,@val475 varchar(20)
,@val476 varchar(20)
,@val477 varchar(20)
,@val478 varchar(20)
,@val479 varchar(20)
,@val480 varchar(20)
,@val481 varchar(20)
,@val482 varchar(20)
,@val483 varchar(20)
,@val484 varchar(20)
,@val485 varchar(20)
,@val486 varchar(20)
,@val487 varchar(20)
,@val488 varchar(20)
,@val489 varchar(20)
,@val490 varchar(20)
,@val491 varchar(20)
,@val492 varchar(20)
,@val493 varchar(20)
,@val494 varchar(20)
,@val495 varchar(20)
,@val496 varchar(20)
,@val497 varchar(20)
,@val498 varchar(20)
,@val499 varchar(20)
,@val500 varchar(20)
,@val501 varchar(20)
,@val502 varchar(20)
,@val503 varchar(20)
,@val504 varchar(20)
,@val505 varchar(20)
,@val506 varchar(20)
,@val507 varchar(20)
,@val508 varchar(20)
,@val509 varchar(20)
,@val510 varchar(20)
,@val511 varchar(20)
,@val512 varchar(20)
,@val513 varchar(20)
,@val514 varchar(20)
,@val515 varchar(20)
,@val516 varchar(20)
,@val517 varchar(20)
,@val518 varchar(20)
,@val519 varchar(20)
,@val520 varchar(20)
,@val521 varchar(20)
,@val522 varchar(20)
,@val523 varchar(20)
,@val524 varchar(20)
,@val525 varchar(20)
,@val526 varchar(20)
,@val527 varchar(20)
,@val528 varchar(20)
,@val529 varchar(20)
,@val530 varchar(20)
,@val531 varchar(20)
,@val532 varchar(20)
,@val533 varchar(20)
,@val534 varchar(20)
,@val535 varchar(20)
,@val536 varchar(20)
,@val537 varchar(20)
,@val538 varchar(20)
,@val539 varchar(20)
,@val540 varchar(20)
,@val541 varchar(20)
,@val542 varchar(20)
,@val543 varchar(20)
,@val544 varchar(20)
,@val545 varchar(20)
,@val546 varchar(20)
,@val547 varchar(20)
,@val548 varchar(20)
,@val549 varchar(20)
,@val550 varchar(20)
,@val551 varchar(20)
,@val552 varchar(20)
,@val553 varchar(20)
,@val554 varchar(20)
,@val555 varchar(20)
,@val556 varchar(20)
,@val557 varchar(20)
,@val558 varchar(20)
,@val559 varchar(20)
,@val560 varchar(20)
,@val561 varchar(20)
,@val562 varchar(20)
,@val563 varchar(20)
,@val564 varchar(20)
,@val565 varchar(20)
,@val566 varchar(20)
,@val567 varchar(20)
,@val568 varchar(20)
,@val569 varchar(20)
,@val570 varchar(20)
,@val571 varchar(20)
,@val572 varchar(20)
,@val573 varchar(20)
,@val574 varchar(20)
,@val575 varchar(20)
,@val576 varchar(20)
,@val577 varchar(20)
,@val578 varchar(20)
,@val579 varchar(20)
,@val580 varchar(20)
,@val581 varchar(20)
,@val582 varchar(20)
,@val583 varchar(20)
,@val584 varchar(20)
,@val585 varchar(20)
,@val586 varchar(20)
,@val587 varchar(20)
,@val588 varchar(20)
,@val589 varchar(20)
,@val590 varchar(20)
,@val591 varchar(20)
,@val592 varchar(20)
,@val593 varchar(20)
,@val594 varchar(20)
,@val595 varchar(20)
,@val596 varchar(20)
,@val597 varchar(20)
,@val598 varchar(20)
,@val599 varchar(20)
,@val600 varchar(20)
,@val601 varchar(20)
,@val602 varchar(20)
,@val603 varchar(20)
,@val604 varchar(20)
,@val605 varchar(20)
,@val606 varchar(20)
,@val607 varchar(20)
,@val608 varchar(20)
,@val609 varchar(20)
,@val610 varchar(20)
,@val611 varchar(20)
,@val612 varchar(20)
,@val613 varchar(20)
,@val614 varchar(20)
,@val615 varchar(20)
,@val616 varchar(20)
,@val617 varchar(20)
,@val618 varchar(20)
,@val619 varchar(20)
,@val620 varchar(20)
,@val621 varchar(20)
,@val622 varchar(20)
,@val623 varchar(20)
,@val624 varchar(20)
,@val625 varchar(20)
,@val626 varchar(20)
,@val627 varchar(20)
,@val628 varchar(20)
,@val629 varchar(20)
,@val630 varchar(20)
,@val631 varchar(20)
,@val632 varchar(20)
,@val633 varchar(20)
,@val634 varchar(20)
,@val635 varchar(20)
,@val636 varchar(20)
,@val637 varchar(20)
,@val638 varchar(20)
,@val639 varchar(20)
,@val640 varchar(20)
,@val641 varchar(20)
,@val642 varchar(20)
,@val643 varchar(20)
,@val644 varchar(20)
,@val645 varchar(20)
,@val646 varchar(20)
,@val647 varchar(20)
,@val648 varchar(20)
,@val649 varchar(20)
,@val650 varchar(20)
,@val651 varchar(20)
,@val652 varchar(20)
,@val653 varchar(20)
,@val654 varchar(20)
,@val655 varchar(20)
,@val656 varchar(20)
,@val657 varchar(20)
,@val658 varchar(20)
,@val659 varchar(20)
,@val660 varchar(20)
,@val661 varchar(20)
,@val662 varchar(20)
,@val663 varchar(20)
,@val664 varchar(20)
,@val665 varchar(20)
,@val666 varchar(20)
,@val667 varchar(20)
,@val668 varchar(20)
,@val669 varchar(20)
,@val670 varchar(20)
,@val671 varchar(20)
,@val672 varchar(20)
,@val673 varchar(20)
,@val674 varchar(20)
,@val675 varchar(20)
,@val676 varchar(20)
,@val677 varchar(20)
,@val678 varchar(20)
,@val679 varchar(20)
,@val680 varchar(20)
,@val681 varchar(20)
,@val682 varchar(20)
,@val683 varchar(20)
,@val684 varchar(20)
,@val685 varchar(20)
,@val686 varchar(20)
,@val687 varchar(20)
,@val688 varchar(20)
,@val689 varchar(20)
,@val690 varchar(20)
,@val691 varchar(20)
,@val692 varchar(20)
,@val693 varchar(20)
,@val694 varchar(20)
,@val695 varchar(20)
,@val696 varchar(20)
,@val697 varchar(20)
,@val698 varchar(20)
,@val699 varchar(20)
,@val700 varchar(20)
,@val701 varchar(20)
,@val702 varchar(20)
,@val703 varchar(20)
,@val704 varchar(20)
,@val705 varchar(20)
,@val706 varchar(20)
,@val707 varchar(20)
,@val708 varchar(20)
,@val709 varchar(20)
,@val710 varchar(20)
,@val711 varchar(20)
,@val712 varchar(20)
,@val713 varchar(20)
,@val714 varchar(20)
,@val715 varchar(20)
,@val716 varchar(20)
,@val717 varchar(20)
,@val718 varchar(20)
,@val719 varchar(20)
,@val720 varchar(20)
,@val721 varchar(20)
,@val722 varchar(20)
,@val723 varchar(20)
,@val724 varchar(20)
,@val725 varchar(20)
,@val726 varchar(20)
,@val727 varchar(20)
,@val728 varchar(20)
,@val729 varchar(20)
,@val730 varchar(20)
,@val731 varchar(20)
,@val732 varchar(20)
,@val733 varchar(20)
,@val734 varchar(20)
,@val735 varchar(20)
,@val736 varchar(20)
,@val737 varchar(20)
,@val738 varchar(20)
,@val739 varchar(20)
,@val740 varchar(20)
,@val741 varchar(20)
,@val742 varchar(20)
,@val743 varchar(20)
,@val744 varchar(20)
,@val745 varchar(20)
,@val746 varchar(20)
,@val747 varchar(20)
,@val748 varchar(20)
,@val749 varchar(20)
,@val750 varchar(20)
,@val751 varchar(20)
,@val752 varchar(20)
,@val753 varchar(20)
,@val754 varchar(20)
,@val755 varchar(20)
,@val756 varchar(20)
,@val757 varchar(20)
,@val758 varchar(20)
,@val759 varchar(20)
,@val760 varchar(20)
,@val761 varchar(20)
,@val762 varchar(20)
,@val763 varchar(20)
,@val764 varchar(20)
,@val765 varchar(20)
,@val766 varchar(20)
,@val767 varchar(20)
,@val768 varchar(20)
,@val769 varchar(20)
,@val770 varchar(20)
,@val771 varchar(20)
,@val772 varchar(20)
,@val773 varchar(20)
,@val774 varchar(20)
,@val775 varchar(20)
,@val776 varchar(20)
,@val777 varchar(20)
,@val778 varchar(20)
,@val779 varchar(20)
,@val780 varchar(20)
,@val781 varchar(20)
,@val782 varchar(20)
,@val783 varchar(20)
,@val784 varchar(20)
,@val785 varchar(20)
,@val786 varchar(20)
,@val787 varchar(20)
,@val788 varchar(20)
,@val789 varchar(20)
,@val790 varchar(20)
,@val791 varchar(20)
,@val792 varchar(20)
,@val793 varchar(20)
,@val794 varchar(20)
,@val795 varchar(20)
,@val796 varchar(20)
,@val797 varchar(20)
,@val798 varchar(20)
,@val799 varchar(20)
,@val800 varchar(20)
,@val801 varchar(20)
,@val802 varchar(20)
,@val803 varchar(20)
,@val804 varchar(20)
,@val805 varchar(20)
,@val806 varchar(20)
,@val807 varchar(20)
,@val808 varchar(20)
,@val809 varchar(20)
,@val810 varchar(20)
,@val811 varchar(20)
,@val812 varchar(20)
,@val813 varchar(20)
,@val814 varchar(20)
,@val815 varchar(20)
,@val816 varchar(20)
,@val817 varchar(20)
,@val818 varchar(20)
,@val819 varchar(20)
,@val820 varchar(20)
,@val821 varchar(20)
,@val822 varchar(20)
,@val823 varchar(20)
,@val824 varchar(20)
,@val825 varchar(20)
,@val826 varchar(20)
,@val827 varchar(20)
,@val828 varchar(20)
,@val829 varchar(20)
,@val830 varchar(20)
,@val831 varchar(20)
,@val832 varchar(20)
,@val833 varchar(20)
,@val834 varchar(20)
,@val835 varchar(20)
,@val836 varchar(20)
,@val837 varchar(20)
,@val838 varchar(20)
,@val839 varchar(20)
,@val840 varchar(20)
,@val841 varchar(20)
,@val842 varchar(20)
,@val843 varchar(20)
,@val844 varchar(20)
,@val845 varchar(20)
,@val846 varchar(20)
,@val847 varchar(20)
,@val848 varchar(20)
,@val849 varchar(20)
,@val850 varchar(20)
,@val851 varchar(20)
,@val852 varchar(20)
,@val853 varchar(20)
,@val854 varchar(20)
,@val855 varchar(20)
,@val856 varchar(20)
,@val857 varchar(20)
,@val858 varchar(20)
,@val859 varchar(20)
,@val860 varchar(20)
,@val861 varchar(20)
,@val862 varchar(20)
,@val863 varchar(20)
,@val864 varchar(20)
,@val865 varchar(20)
,@val866 varchar(20)
,@val867 varchar(20)
,@val868 varchar(20)
,@val869 varchar(20)
,@val870 varchar(20)
,@val871 varchar(20)
,@val872 varchar(20)
,@val873 varchar(20)
,@val874 varchar(20)
,@val875 varchar(20)
,@val876 varchar(20)
,@val877 varchar(20)
,@val878 varchar(20)
,@val879 varchar(20)
,@val880 varchar(20)
,@val881 varchar(20)
,@val882 varchar(20)
,@val883 varchar(20)
,@val884 varchar(20)
,@val885 varchar(20)
,@val886 varchar(20)
,@val887 varchar(20)
,@val888 varchar(20)
,@val889 varchar(20)
,@val890 varchar(20)
,@val891 varchar(20)
,@val892 varchar(20)
,@val893 varchar(20)
,@val894 varchar(20)
,@val895 varchar(20)
,@val896 varchar(20)
,@val897 varchar(20)
,@val898 varchar(20)
,@val899 varchar(20)
,@val900 varchar(20)
,@val901 varchar(20)
,@val902 varchar(20)
,@val903 varchar(20)
,@val904 varchar(20)
,@val905 varchar(20)
,@val906 varchar(20)
,@val907 varchar(20)
,@val908 varchar(20)
,@val909 varchar(20)
,@val910 varchar(20)
,@val911 varchar(20)
,@val912 varchar(20)
,@val913 varchar(20)
,@val914 varchar(20)
,@val915 varchar(20)
,@val916 varchar(20)
,@val917 varchar(20)
,@val918 varchar(20)
,@val919 varchar(20)
,@val920 varchar(20)
,@val921 varchar(20)
,@val922 varchar(20)
,@val923 varchar(20)
,@val924 varchar(20)
,@val925 varchar(20)
,@val926 varchar(20)
,@val927 varchar(20)
,@val928 varchar(20)
,@val929 varchar(20)
,@val930 varchar(20)
,@val931 varchar(20)
,@val932 varchar(20)
,@val933 varchar(20)
,@val934 varchar(20)
,@val935 varchar(20)
,@val936 varchar(20)
,@val937 varchar(20)
,@val938 varchar(20)
,@val939 varchar(20)
,@val940 varchar(20)
,@val941 varchar(20)
,@val942 varchar(20)
,@val943 varchar(20)
,@val944 varchar(20)
,@val945 varchar(20)
,@val946 varchar(20)
,@val947 varchar(20)
,@val948 varchar(20)
,@val949 varchar(20)
,@val950 varchar(20)
,@val951 varchar(20)
,@val952 varchar(20)
,@val953 varchar(20)
,@val954 varchar(20)
,@val955 varchar(20)
,@val956 varchar(20)
,@val957 varchar(20)
,@val958 varchar(20)
,@val959 varchar(20)
,@val960 varchar(20)
,@val961 varchar(20)
,@val962 varchar(20)
,@val963 varchar(20)
,@val964 varchar(20)
,@val965 varchar(20)
,@val966 varchar(20)
,@val967 varchar(20)
,@val968 varchar(20)
,@val969 varchar(20)
,@val970 varchar(20)
,@val971 varchar(20)
,@val972 varchar(20)
,@val973 varchar(20)
,@val974 varchar(20)
,@val975 varchar(20)
,@val976 varchar(20)
,@val977 varchar(20)
,@val978 varchar(20)
,@val979 varchar(20)
,@val980 varchar(20)
,@val981 varchar(20)
,@val982 varchar(20)
,@val983 varchar(20)
,@val984 varchar(20)
,@val985 varchar(20)
,@val986 varchar(20)
,@val987 varchar(20)
,@val988 varchar(20)
,@val989 varchar(20)
,@val990 varchar(20)
,@val991 varchar(20)
,@val992 varchar(20)
,@val993 varchar(20)
,@val994 varchar(20)
,@val995 varchar(20)
,@val996 varchar(20)
,@val997 varchar(20)
,@val998 varchar(20)
,@val999 varchar(20)
,@val1000 varchar(20)

SELECT @val1 = 'Ben Miller'
,@val2 = 'Ben Miller'
,@val3 = 'Ben Miller'
,@val4 = 'Ben Miller'
,@val5 = 'Ben Miller'
,@val6 = 'Ben Miller'
,@val7 = 'Ben Miller'
,@val8 = 'Ben Miller'
,@val9 = 'Ben Miller'
,@val10 = 'Ben Miller'
,@val11 = 'Ben Miller'
,@val12 = 'Ben Miller'
,@val13 = 'Ben Miller'
,@val14 = 'Ben Miller'
,@val15 = 'Ben Miller'
,@val16 = 'Ben Miller'
,@val17 = 'Ben Miller'
,@val18 = 'Ben Miller'
,@val19 = 'Ben Miller'
,@val20 = 'Ben Miller'
,@val21 = 'Ben Miller'
,@val22 = 'Ben Miller'
,@val23 = 'Ben Miller'
,@val24 = 'Ben Miller'
,@val25 = 'Ben Miller'
,@val26 = 'Ben Miller'
,@val27 = 'Ben Miller'
,@val28 = 'Ben Miller'
,@val29 = 'Ben Miller'
,@val30 = 'Ben Miller'
,@val31 = 'Ben Miller'
,@val32 = 'Ben Miller'
,@val33 = 'Ben Miller'
,@val34 = 'Ben Miller'
,@val35 = 'Ben Miller'
,@val36 = 'Ben Miller'
,@val37 = 'Ben Miller'
,@val38 = 'Ben Miller'
,@val39 = 'Ben Miller'
,@val40 = 'Ben Miller'
,@val41 = 'Ben Miller'
,@val42 = 'Ben Miller'
,@val43 = 'Ben Miller'
,@val44 = 'Ben Miller'
,@val45 = 'Ben Miller'
,@val46 = 'Ben Miller'
,@val47 = 'Ben Miller'
,@val48 = 'Ben Miller'
,@val49 = 'Ben Miller'
,@val50 = 'Ben Miller'
,@val51 = 'Ben Miller'
,@val52 = 'Ben Miller'
,@val53 = 'Ben Miller'
,@val54 = 'Ben Miller'
,@val55 = 'Ben Miller'
,@val56 = 'Ben Miller'
,@val57 = 'Ben Miller'
,@val58 = 'Ben Miller'
,@val59 = 'Ben Miller'
,@val60 = 'Ben Miller'
,@val61 = 'Ben Miller'
,@val62 = 'Ben Miller'
,@val63 = 'Ben Miller'
,@val64 = 'Ben Miller'
,@val65 = 'Ben Miller'
,@val66 = 'Ben Miller'
,@val67 = 'Ben Miller'
,@val68 = 'Ben Miller'
,@val69 = 'Ben Miller'
,@val70 = 'Ben Miller'
,@val71 = 'Ben Miller'
,@val72 = 'Ben Miller'
,@val73 = 'Ben Miller'
,@val74 = 'Ben Miller'
,@val75 = 'Ben Miller'
,@val76 = 'Ben Miller'
,@val77 = 'Ben Miller'
,@val78 = 'Ben Miller'
,@val79 = 'Ben Miller'
,@val80 = 'Ben Miller'
,@val81 = 'Ben Miller'
,@val82 = 'Ben Miller'
,@val83 = 'Ben Miller'
,@val84 = 'Ben Miller'
,@val85 = 'Ben Miller'
,@val86 = 'Ben Miller'
,@val87 = 'Ben Miller'
,@val88 = 'Ben Miller'
,@val89 = 'Ben Miller'
,@val90 = 'Ben Miller'
,@val91 = 'Ben Miller'
,@val92 = 'Ben Miller'
,@val93 = 'Ben Miller'
,@val94 = 'Ben Miller'
,@val95 = 'Ben Miller'
,@val96 = 'Ben Miller'
,@val97 = 'Ben Miller'
,@val98 = 'Ben Miller'
,@val99 = 'Ben Miller'
,@val100 = 'Ben Miller'
,@val101 = 'Ben Miller'
,@val102 = 'Ben Miller'
,@val103 = 'Ben Miller'
,@val104 = 'Ben Miller'
,@val105 = 'Ben Miller'
,@val106 = 'Ben Miller'
,@val107 = 'Ben Miller'
,@val108 = 'Ben Miller'
,@val109 = 'Ben Miller'
,@val110 = 'Ben Miller'
,@val111 = 'Ben Miller'
,@val112 = 'Ben Miller'
,@val113 = 'Ben Miller'
,@val114 = 'Ben Miller'
,@val115 = 'Ben Miller'
,@val116 = 'Ben Miller'
,@val117 = 'Ben Miller'
,@val118 = 'Ben Miller'
,@val119 = 'Ben Miller'
,@val120 = 'Ben Miller'
,@val121 = 'Ben Miller'
,@val122 = 'Ben Miller'
,@val123 = 'Ben Miller'
,@val124 = 'Ben Miller'
,@val125 = 'Ben Miller'
,@val126 = 'Ben Miller'
,@val127 = 'Ben Miller'
,@val128 = 'Ben Miller'
,@val129 = 'Ben Miller'
,@val130 = 'Ben Miller'
,@val131 = 'Ben Miller'
,@val132 = 'Ben Miller'
,@val133 = 'Ben Miller'
,@val134 = 'Ben Miller'
,@val135 = 'Ben Miller'
,@val136 = 'Ben Miller'
,@val137 = 'Ben Miller'
,@val138 = 'Ben Miller'
,@val139 = 'Ben Miller'
,@val140 = 'Ben Miller'
,@val141 = 'Ben Miller'
,@val142 = 'Ben Miller'
,@val143 = 'Ben Miller'
,@val144 = 'Ben Miller'
,@val145 = 'Ben Miller'
,@val146 = 'Ben Miller'
,@val147 = 'Ben Miller'
,@val148 = 'Ben Miller'
,@val149 = 'Ben Miller'
,@val150 = 'Ben Miller'
,@val151 = 'Ben Miller'
,@val152 = 'Ben Miller'
,@val153 = 'Ben Miller'
,@val154 = 'Ben Miller'
,@val155 = 'Ben Miller'
,@val156 = 'Ben Miller'
,@val157 = 'Ben Miller'
,@val158 = 'Ben Miller'
,@val159 = 'Ben Miller'
,@val160 = 'Ben Miller'
,@val161 = 'Ben Miller'
,@val162 = 'Ben Miller'
,@val163 = 'Ben Miller'
,@val164 = 'Ben Miller'
,@val165 = 'Ben Miller'
,@val166 = 'Ben Miller'
,@val167 = 'Ben Miller'
,@val168 = 'Ben Miller'
,@val169 = 'Ben Miller'
,@val170 = 'Ben Miller'
,@val171 = 'Ben Miller'
,@val172 = 'Ben Miller'
,@val173 = 'Ben Miller'
,@val174 = 'Ben Miller'
,@val175 = 'Ben Miller'
,@val176 = 'Ben Miller'
,@val177 = 'Ben Miller'
,@val178 = 'Ben Miller'
,@val179 = 'Ben Miller'
,@val180 = 'Ben Miller'
,@val181 = 'Ben Miller'
,@val182 = 'Ben Miller'
,@val183 = 'Ben Miller'
,@val184 = 'Ben Miller'
,@val185 = 'Ben Miller'
,@val186 = 'Ben Miller'
,@val187 = 'Ben Miller'
,@val188 = 'Ben Miller'
,@val189 = 'Ben Miller'
,@val190 = 'Ben Miller'
,@val191 = 'Ben Miller'
,@val192 = 'Ben Miller'
,@val193 = 'Ben Miller'
,@val194 = 'Ben Miller'
,@val195 = 'Ben Miller'
,@val196 = 'Ben Miller'
,@val197 = 'Ben Miller'
,@val198 = 'Ben Miller'
,@val199 = 'Ben Miller'
,@val200 = 'Ben Miller'
,@val201 = 'Ben Miller'
,@val202 = 'Ben Miller'
,@val203 = 'Ben Miller'
,@val204 = 'Ben Miller'
,@val205 = 'Ben Miller'
,@val206 = 'Ben Miller'
,@val207 = 'Ben Miller'
,@val208 = 'Ben Miller'
,@val209 = 'Ben Miller'
,@val210 = 'Ben Miller'
,@val211 = 'Ben Miller'
,@val212 = 'Ben Miller'
,@val213 = 'Ben Miller'
,@val214 = 'Ben Miller'
,@val215 = 'Ben Miller'
,@val216 = 'Ben Miller'
,@val217 = 'Ben Miller'
,@val218 = 'Ben Miller'
,@val219 = 'Ben Miller'
,@val220 = 'Ben Miller'
,@val221 = 'Ben Miller'
,@val222 = 'Ben Miller'
,@val223 = 'Ben Miller'
,@val224 = 'Ben Miller'
,@val225 = 'Ben Miller'
,@val226 = 'Ben Miller'
,@val227 = 'Ben Miller'
,@val228 = 'Ben Miller'
,@val229 = 'Ben Miller'
,@val230 = 'Ben Miller'
,@val231 = 'Ben Miller'
,@val232 = 'Ben Miller'
,@val233 = 'Ben Miller'
,@val234 = 'Ben Miller'
,@val235 = 'Ben Miller'
,@val236 = 'Ben Miller'
,@val237 = 'Ben Miller'
,@val238 = 'Ben Miller'
,@val239 = 'Ben Miller'
,@val240 = 'Ben Miller'
,@val241 = 'Ben Miller'
,@val242 = 'Ben Miller'
,@val243 = 'Ben Miller'
,@val244 = 'Ben Miller'
,@val245 = 'Ben Miller'
,@val246 = 'Ben Miller'
,@val247 = 'Ben Miller'
,@val248 = 'Ben Miller'
,@val249 = 'Ben Miller'
,@val250 = 'Ben Miller'
,@val251 = 'Ben Miller'
,@val252 = 'Ben Miller'
,@val253 = 'Ben Miller'
,@val254 = 'Ben Miller'
,@val255 = 'Ben Miller'
,@val256 = 'Ben Miller'
,@val257 = 'Ben Miller'
,@val258 = 'Ben Miller'
,@val259 = 'Ben Miller'
,@val260 = 'Ben Miller'
,@val261 = 'Ben Miller'
,@val262 = 'Ben Miller'
,@val263 = 'Ben Miller'
,@val264 = 'Ben Miller'
,@val265 = 'Ben Miller'
,@val266 = 'Ben Miller'
,@val267 = 'Ben Miller'
,@val268 = 'Ben Miller'
,@val269 = 'Ben Miller'
,@val270 = 'Ben Miller'
,@val271 = 'Ben Miller'
,@val272 = 'Ben Miller'
,@val273 = 'Ben Miller'
,@val274 = 'Ben Miller'
,@val275 = 'Ben Miller'
,@val276 = 'Ben Miller'
,@val277 = 'Ben Miller'
,@val278 = 'Ben Miller'
,@val279 = 'Ben Miller'
,@val280 = 'Ben Miller'
,@val281 = 'Ben Miller'
,@val282 = 'Ben Miller'
,@val283 = 'Ben Miller'
,@val284 = 'Ben Miller'
,@val285 = 'Ben Miller'
,@val286 = 'Ben Miller'
,@val287 = 'Ben Miller'
,@val288 = 'Ben Miller'
,@val289 = 'Ben Miller'
,@val290 = 'Ben Miller'
,@val291 = 'Ben Miller'
,@val292 = 'Ben Miller'
,@val293 = 'Ben Miller'
,@val294 = 'Ben Miller'
,@val295 = 'Ben Miller'
,@val296 = 'Ben Miller'
,@val297 = 'Ben Miller'
,@val298 = 'Ben Miller'
,@val299 = 'Ben Miller'
,@val300 = 'Ben Miller'
,@val301 = 'Ben Miller'
,@val302 = 'Ben Miller'
,@val303 = 'Ben Miller'
,@val304 = 'Ben Miller'
,@val305 = 'Ben Miller'
,@val306 = 'Ben Miller'
,@val307 = 'Ben Miller'
,@val308 = 'Ben Miller'
,@val309 = 'Ben Miller'
,@val310 = 'Ben Miller'
,@val311 = 'Ben Miller'
,@val312 = 'Ben Miller'
,@val313 = 'Ben Miller'
,@val314 = 'Ben Miller'
,@val315 = 'Ben Miller'
,@val316 = 'Ben Miller'
,@val317 = 'Ben Miller'
,@val318 = 'Ben Miller'
,@val319 = 'Ben Miller'
,@val320 = 'Ben Miller'
,@val321 = 'Ben Miller'
,@val322 = 'Ben Miller'
,@val323 = 'Ben Miller'
,@val324 = 'Ben Miller'
,@val325 = 'Ben Miller'
,@val326 = 'Ben Miller'
,@val327 = 'Ben Miller'
,@val328 = 'Ben Miller'
,@val329 = 'Ben Miller'
,@val330 = 'Ben Miller'
,@val331 = 'Ben Miller'
,@val332 = 'Ben Miller'
,@val333 = 'Ben Miller'
,@val334 = 'Ben Miller'
,@val335 = 'Ben Miller'
,@val336 = 'Ben Miller'
,@val337 = 'Ben Miller'
,@val338 = 'Ben Miller'
,@val339 = 'Ben Miller'
,@val340 = 'Ben Miller'
,@val341 = 'Ben Miller'
,@val342 = 'Ben Miller'
,@val343 = 'Ben Miller'
,@val344 = 'Ben Miller'
,@val345 = 'Ben Miller'
,@val346 = 'Ben Miller'
,@val347 = 'Ben Miller'
,@val348 = 'Ben Miller'
,@val349 = 'Ben Miller'
,@val350 = 'Ben Miller'
,@val351 = 'Ben Miller'
,@val352 = 'Ben Miller'
,@val353 = 'Ben Miller'
,@val354 = 'Ben Miller'
,@val355 = 'Ben Miller'
,@val356 = 'Ben Miller'
,@val357 = 'Ben Miller'
,@val358 = 'Ben Miller'
,@val359 = 'Ben Miller'
,@val360 = 'Ben Miller'
,@val361 = 'Ben Miller'
,@val362 = 'Ben Miller'
,@val363 = 'Ben Miller'
,@val364 = 'Ben Miller'
,@val365 = 'Ben Miller'
,@val366 = 'Ben Miller'
,@val367 = 'Ben Miller'
,@val368 = 'Ben Miller'
,@val369 = 'Ben Miller'
,@val370 = 'Ben Miller'
,@val371 = 'Ben Miller'
,@val372 = 'Ben Miller'
,@val373 = 'Ben Miller'
,@val374 = 'Ben Miller'
,@val375 = 'Ben Miller'
,@val376 = 'Ben Miller'
,@val377 = 'Ben Miller'
,@val378 = 'Ben Miller'
,@val379 = 'Ben Miller'
,@val380 = 'Ben Miller'
,@val381 = 'Ben Miller'
,@val382 = 'Ben Miller'
,@val383 = 'Ben Miller'
,@val384 = 'Ben Miller'
,@val385 = 'Ben Miller'
,@val386 = 'Ben Miller'
,@val387 = 'Ben Miller'
,@val388 = 'Ben Miller'
,@val389 = 'Ben Miller'
,@val390 = 'Ben Miller'
,@val391 = 'Ben Miller'
,@val392 = 'Ben Miller'
,@val393 = 'Ben Miller'
,@val394 = 'Ben Miller'
,@val395 = 'Ben Miller'
,@val396 = 'Ben Miller'
,@val397 = 'Ben Miller'
,@val398 = 'Ben Miller'
,@val399 = 'Ben Miller'
,@val400 = 'Ben Miller'
,@val401 = 'Ben Miller'
,@val402 = 'Ben Miller'
,@val403 = 'Ben Miller'
,@val404 = 'Ben Miller'
,@val405 = 'Ben Miller'
,@val406 = 'Ben Miller'
,@val407 = 'Ben Miller'
,@val408 = 'Ben Miller'
,@val409 = 'Ben Miller'
,@val410 = 'Ben Miller'
,@val411 = 'Ben Miller'
,@val412 = 'Ben Miller'
,@val413 = 'Ben Miller'
,@val414 = 'Ben Miller'
,@val415 = 'Ben Miller'
,@val416 = 'Ben Miller'
,@val417 = 'Ben Miller'
,@val418 = 'Ben Miller'
,@val419 = 'Ben Miller'
,@val420 = 'Ben Miller'
,@val421 = 'Ben Miller'
,@val422 = 'Ben Miller'
,@val423 = 'Ben Miller'
,@val424 = 'Ben Miller'
,@val425 = 'Ben Miller'
,@val426 = 'Ben Miller'
,@val427 = 'Ben Miller'
,@val428 = 'Ben Miller'
,@val429 = 'Ben Miller'
,@val430 = 'Ben Miller'
,@val431 = 'Ben Miller'
,@val432 = 'Ben Miller'
,@val433 = 'Ben Miller'
,@val434 = 'Ben Miller'
,@val435 = 'Ben Miller'
,@val436 = 'Ben Miller'
,@val437 = 'Ben Miller'
,@val438 = 'Ben Miller'
,@val439 = 'Ben Miller'
,@val440 = 'Ben Miller'
,@val441 = 'Ben Miller'
,@val442 = 'Ben Miller'
,@val443 = 'Ben Miller'
,@val444 = 'Ben Miller'
,@val445 = 'Ben Miller'
,@val446 = 'Ben Miller'
,@val447 = 'Ben Miller'
,@val448 = 'Ben Miller'
,@val449 = 'Ben Miller'
,@val450 = 'Ben Miller'
,@val451 = 'Ben Miller'
,@val452 = 'Ben Miller'
,@val453 = 'Ben Miller'
,@val454 = 'Ben Miller'
,@val455 = 'Ben Miller'
,@val456 = 'Ben Miller'
,@val457 = 'Ben Miller'
,@val458 = 'Ben Miller'
,@val459 = 'Ben Miller'
,@val460 = 'Ben Miller'
,@val461 = 'Ben Miller'
,@val462 = 'Ben Miller'
,@val463 = 'Ben Miller'
,@val464 = 'Ben Miller'
,@val465 = 'Ben Miller'
,@val466 = 'Ben Miller'
,@val467 = 'Ben Miller'
,@val468 = 'Ben Miller'
,@val469 = 'Ben Miller'
,@val470 = 'Ben Miller'
,@val471 = 'Ben Miller'
,@val472 = 'Ben Miller'
,@val473 = 'Ben Miller'
,@val474 = 'Ben Miller'
,@val475 = 'Ben Miller'
,@val476 = 'Ben Miller'
,@val477 = 'Ben Miller'
,@val478 = 'Ben Miller'
,@val479 = 'Ben Miller'
,@val480 = 'Ben Miller'
,@val481 = 'Ben Miller'
,@val482 = 'Ben Miller'
,@val483 = 'Ben Miller'
,@val484 = 'Ben Miller'
,@val485 = 'Ben Miller'
,@val486 = 'Ben Miller'
,@val487 = 'Ben Miller'
,@val488 = 'Ben Miller'
,@val489 = 'Ben Miller'
,@val490 = 'Ben Miller'
,@val491 = 'Ben Miller'
,@val492 = 'Ben Miller'
,@val493 = 'Ben Miller'
,@val494 = 'Ben Miller'
,@val495 = 'Ben Miller'
,@val496 = 'Ben Miller'
,@val497 = 'Ben Miller'
,@val498 = 'Ben Miller'
,@val499 = 'Ben Miller'
,@val500 = 'Ben Miller'
,@val501 = 'Ben Miller'
,@val502 = 'Ben Miller'
,@val503 = 'Ben Miller'
,@val504 = 'Ben Miller'
,@val505 = 'Ben Miller'
,@val506 = 'Ben Miller'
,@val507 = 'Ben Miller'
,@val508 = 'Ben Miller'
,@val509 = 'Ben Miller'
,@val510 = 'Ben Miller'
,@val511 = 'Ben Miller'
,@val512 = 'Ben Miller'
,@val513 = 'Ben Miller'
,@val514 = 'Ben Miller'
,@val515 = 'Ben Miller'
,@val516 = 'Ben Miller'
,@val517 = 'Ben Miller'
,@val518 = 'Ben Miller'
,@val519 = 'Ben Miller'
,@val520 = 'Ben Miller'
,@val521 = 'Ben Miller'
,@val522 = 'Ben Miller'
,@val523 = 'Ben Miller'
,@val524 = 'Ben Miller'
,@val525 = 'Ben Miller'
,@val526 = 'Ben Miller'
,@val527 = 'Ben Miller'
,@val528 = 'Ben Miller'
,@val529 = 'Ben Miller'
,@val530 = 'Ben Miller'
,@val531 = 'Ben Miller'
,@val532 = 'Ben Miller'
,@val533 = 'Ben Miller'
,@val534 = 'Ben Miller'
,@val535 = 'Ben Miller'
,@val536 = 'Ben Miller'
,@val537 = 'Ben Miller'
,@val538 = 'Ben Miller'
,@val539 = 'Ben Miller'
,@val540 = 'Ben Miller'
,@val541 = 'Ben Miller'
,@val542 = 'Ben Miller'
,@val543 = 'Ben Miller'
,@val544 = 'Ben Miller'
,@val545 = 'Ben Miller'
,@val546 = 'Ben Miller'
,@val547 = 'Ben Miller'
,@val548 = 'Ben Miller'
,@val549 = 'Ben Miller'
,@val550 = 'Ben Miller'
,@val551 = 'Ben Miller'
,@val552 = 'Ben Miller'
,@val553 = 'Ben Miller'
,@val554 = 'Ben Miller'
,@val555 = 'Ben Miller'
,@val556 = 'Ben Miller'
,@val557 = 'Ben Miller'
,@val558 = 'Ben Miller'
,@val559 = 'Ben Miller'
,@val560 = 'Ben Miller'
,@val561 = 'Ben Miller'
,@val562 = 'Ben Miller'
,@val563 = 'Ben Miller'
,@val564 = 'Ben Miller'
,@val565 = 'Ben Miller'
,@val566 = 'Ben Miller'
,@val567 = 'Ben Miller'
,@val568 = 'Ben Miller'
,@val569 = 'Ben Miller'
,@val570 = 'Ben Miller'
,@val571 = 'Ben Miller'
,@val572 = 'Ben Miller'
,@val573 = 'Ben Miller'
,@val574 = 'Ben Miller'
,@val575 = 'Ben Miller'
,@val576 = 'Ben Miller'
,@val577 = 'Ben Miller'
,@val578 = 'Ben Miller'
,@val579 = 'Ben Miller'
,@val580 = 'Ben Miller'
,@val581 = 'Ben Miller'
,@val582 = 'Ben Miller'
,@val583 = 'Ben Miller'
,@val584 = 'Ben Miller'
,@val585 = 'Ben Miller'
,@val586 = 'Ben Miller'
,@val587 = 'Ben Miller'
,@val588 = 'Ben Miller'
,@val589 = 'Ben Miller'
,@val590 = 'Ben Miller'
,@val591 = 'Ben Miller'
,@val592 = 'Ben Miller'
,@val593 = 'Ben Miller'
,@val594 = 'Ben Miller'
,@val595 = 'Ben Miller'
,@val596 = 'Ben Miller'
,@val597 = 'Ben Miller'
,@val598 = 'Ben Miller'
,@val599 = 'Ben Miller'
,@val600 = 'Ben Miller'
,@val601 = 'Ben Miller'
,@val602 = 'Ben Miller'
,@val603 = 'Ben Miller'
,@val604 = 'Ben Miller'
,@val605 = 'Ben Miller'
,@val606 = 'Ben Miller'
,@val607 = 'Ben Miller'
,@val608 = 'Ben Miller'
,@val609 = 'Ben Miller'
,@val610 = 'Ben Miller'
,@val611 = 'Ben Miller'
,@val612 = 'Ben Miller'
,@val613 = 'Ben Miller'
,@val614 = 'Ben Miller'
,@val615 = 'Ben Miller'
,@val616 = 'Ben Miller'
,@val617 = 'Ben Miller'
,@val618 = 'Ben Miller'
,@val619 = 'Ben Miller'
,@val620 = 'Ben Miller'
,@val621 = 'Ben Miller'
,@val622 = 'Ben Miller'
,@val623 = 'Ben Miller'
,@val624 = 'Ben Miller'
,@val625 = 'Ben Miller'
,@val626 = 'Ben Miller'
,@val627 = 'Ben Miller'
,@val628 = 'Ben Miller'
,@val629 = 'Ben Miller'
,@val630 = 'Ben Miller'
,@val631 = 'Ben Miller'
,@val632 = 'Ben Miller'
,@val633 = 'Ben Miller'
,@val634 = 'Ben Miller'
,@val635 = 'Ben Miller'
,@val636 = 'Ben Miller'
,@val637 = 'Ben Miller'
,@val638 = 'Ben Miller'
,@val639 = 'Ben Miller'
,@val640 = 'Ben Miller'
,@val641 = 'Ben Miller'
,@val642 = 'Ben Miller'
,@val643 = 'Ben Miller'
,@val644 = 'Ben Miller'
,@val645 = 'Ben Miller'
,@val646 = 'Ben Miller'
,@val647 = 'Ben Miller'
,@val648 = 'Ben Miller'
,@val649 = 'Ben Miller'
,@val650 = 'Ben Miller'
,@val651 = 'Ben Miller'
,@val652 = 'Ben Miller'
,@val653 = 'Ben Miller'
,@val654 = 'Ben Miller'
,@val655 = 'Ben Miller'
,@val656 = 'Ben Miller'
,@val657 = 'Ben Miller'
,@val658 = 'Ben Miller'
,@val659 = 'Ben Miller'
,@val660 = 'Ben Miller'
,@val661 = 'Ben Miller'
,@val662 = 'Ben Miller'
,@val663 = 'Ben Miller'
,@val664 = 'Ben Miller'
,@val665 = 'Ben Miller'
,@val666 = 'Ben Miller'
,@val667 = 'Ben Miller'
,@val668 = 'Ben Miller'
,@val669 = 'Ben Miller'
,@val670 = 'Ben Miller'
,@val671 = 'Ben Miller'
,@val672 = 'Ben Miller'
,@val673 = 'Ben Miller'
,@val674 = 'Ben Miller'
,@val675 = 'Ben Miller'
,@val676 = 'Ben Miller'
,@val677 = 'Ben Miller'
,@val678 = 'Ben Miller'
,@val679 = 'Ben Miller'
,@val680 = 'Ben Miller'
,@val681 = 'Ben Miller'
,@val682 = 'Ben Miller'
,@val683 = 'Ben Miller'
,@val684 = 'Ben Miller'
,@val685 = 'Ben Miller'
,@val686 = 'Ben Miller'
,@val687 = 'Ben Miller'
,@val688 = 'Ben Miller'
,@val689 = 'Ben Miller'
,@val690 = 'Ben Miller'
,@val691 = 'Ben Miller'
,@val692 = 'Ben Miller'
,@val693 = 'Ben Miller'
,@val694 = 'Ben Miller'
,@val695 = 'Ben Miller'
,@val696 = 'Ben Miller'
,@val697 = 'Ben Miller'
,@val698 = 'Ben Miller'
,@val699 = 'Ben Miller'
,@val700 = 'Ben Miller'
,@val701 = 'Ben Miller'
,@val702 = 'Ben Miller'
,@val703 = 'Ben Miller'
,@val704 = 'Ben Miller'
,@val705 = 'Ben Miller'
,@val706 = 'Ben Miller'
,@val707 = 'Ben Miller'
,@val708 = 'Ben Miller'
,@val709 = 'Ben Miller'
,@val710 = 'Ben Miller'
,@val711 = 'Ben Miller'
,@val712 = 'Ben Miller'
,@val713 = 'Ben Miller'
,@val714 = 'Ben Miller'
,@val715 = 'Ben Miller'
,@val716 = 'Ben Miller'
,@val717 = 'Ben Miller'
,@val718 = 'Ben Miller'
,@val719 = 'Ben Miller'
,@val720 = 'Ben Miller'
,@val721 = 'Ben Miller'
,@val722 = 'Ben Miller'
,@val723 = 'Ben Miller'
,@val724 = 'Ben Miller'
,@val725 = 'Ben Miller'
,@val726 = 'Ben Miller'
,@val727 = 'Ben Miller'
,@val728 = 'Ben Miller'
,@val729 = 'Ben Miller'
,@val730 = 'Ben Miller'
,@val731 = 'Ben Miller'
,@val732 = 'Ben Miller'
,@val733 = 'Ben Miller'
,@val734 = 'Ben Miller'
,@val735 = 'Ben Miller'
,@val736 = 'Ben Miller'
,@val737 = 'Ben Miller'
,@val738 = 'Ben Miller'
,@val739 = 'Ben Miller'
,@val740 = 'Ben Miller'
,@val741 = 'Ben Miller'
,@val742 = 'Ben Miller'
,@val743 = 'Ben Miller'
,@val744 = 'Ben Miller'
,@val745 = 'Ben Miller'
,@val746 = 'Ben Miller'
,@val747 = 'Ben Miller'
,@val748 = 'Ben Miller'
,@val749 = 'Ben Miller'
,@val750 = 'Ben Miller'
,@val751 = 'Ben Miller'
,@val752 = 'Ben Miller'
,@val753 = 'Ben Miller'
,@val754 = 'Ben Miller'
,@val755 = 'Ben Miller'
,@val756 = 'Ben Miller'
,@val757 = 'Ben Miller'
,@val758 = 'Ben Miller'
,@val759 = 'Ben Miller'
,@val760 = 'Ben Miller'
,@val761 = 'Ben Miller'
,@val762 = 'Ben Miller'
,@val763 = 'Ben Miller'
,@val764 = 'Ben Miller'
,@val765 = 'Ben Miller'
,@val766 = 'Ben Miller'
,@val767 = 'Ben Miller'
,@val768 = 'Ben Miller'
,@val769 = 'Ben Miller'
,@val770 = 'Ben Miller'
,@val771 = 'Ben Miller'
,@val772 = 'Ben Miller'
,@val773 = 'Ben Miller'
,@val774 = 'Ben Miller'
,@val775 = 'Ben Miller'
,@val776 = 'Ben Miller'
,@val777 = 'Ben Miller'
,@val778 = 'Ben Miller'
,@val779 = 'Ben Miller'
,@val780 = 'Ben Miller'
,@val781 = 'Ben Miller'
,@val782 = 'Ben Miller'
,@val783 = 'Ben Miller'
,@val784 = 'Ben Miller'
,@val785 = 'Ben Miller'
,@val786 = 'Ben Miller'
,@val787 = 'Ben Miller'
,@val788 = 'Ben Miller'
,@val789 = 'Ben Miller'
,@val790 = 'Ben Miller'
,@val791 = 'Ben Miller'
,@val792 = 'Ben Miller'
,@val793 = 'Ben Miller'
,@val794 = 'Ben Miller'
,@val795 = 'Ben Miller'
,@val796 = 'Ben Miller'
,@val797 = 'Ben Miller'
,@val798 = 'Ben Miller'
,@val799 = 'Ben Miller'
,@val800 = 'Ben Miller'
,@val801 = 'Ben Miller'
,@val802 = 'Ben Miller'
,@val803 = 'Ben Miller'
,@val804 = 'Ben Miller'
,@val805 = 'Ben Miller'
,@val806 = 'Ben Miller'
,@val807 = 'Ben Miller'
,@val808 = 'Ben Miller'
,@val809 = 'Ben Miller'
,@val810 = 'Ben Miller'
,@val811 = 'Ben Miller'
,@val812 = 'Ben Miller'
,@val813 = 'Ben Miller'
,@val814 = 'Ben Miller'
,@val815 = 'Ben Miller'
,@val816 = 'Ben Miller'
,@val817 = 'Ben Miller'
,@val818 = 'Ben Miller'
,@val819 = 'Ben Miller'
,@val820 = 'Ben Miller'
,@val821 = 'Ben Miller'
,@val822 = 'Ben Miller'
,@val823 = 'Ben Miller'
,@val824 = 'Ben Miller'
,@val825 = 'Ben Miller'
,@val826 = 'Ben Miller'
,@val827 = 'Ben Miller'
,@val828 = 'Ben Miller'
,@val829 = 'Ben Miller'
,@val830 = 'Ben Miller'
,@val831 = 'Ben Miller'
,@val832 = 'Ben Miller'
,@val833 = 'Ben Miller'
,@val834 = 'Ben Miller'
,@val835 = 'Ben Miller'
,@val836 = 'Ben Miller'
,@val837 = 'Ben Miller'
,@val838 = 'Ben Miller'
,@val839 = 'Ben Miller'
,@val840 = 'Ben Miller'
,@val841 = 'Ben Miller'
,@val842 = 'Ben Miller'
,@val843 = 'Ben Miller'
,@val844 = 'Ben Miller'
,@val845 = 'Ben Miller'
,@val846 = 'Ben Miller'
,@val847 = 'Ben Miller'
,@val848 = 'Ben Miller'
,@val849 = 'Ben Miller'
,@val850 = 'Ben Miller'
,@val851 = 'Ben Miller'
,@val852 = 'Ben Miller'
,@val853 = 'Ben Miller'
,@val854 = 'Ben Miller'
,@val855 = 'Ben Miller'
,@val856 = 'Ben Miller'
,@val857 = 'Ben Miller'
,@val858 = 'Ben Miller'
,@val859 = 'Ben Miller'
,@val860 = 'Ben Miller'
,@val861 = 'Ben Miller'
,@val862 = 'Ben Miller'
,@val863 = 'Ben Miller'
,@val864 = 'Ben Miller'
,@val865 = 'Ben Miller'
,@val866 = 'Ben Miller'
,@val867 = 'Ben Miller'
,@val868 = 'Ben Miller'
,@val869 = 'Ben Miller'
,@val870 = 'Ben Miller'
,@val871 = 'Ben Miller'
,@val872 = 'Ben Miller'
,@val873 = 'Ben Miller'
,@val874 = 'Ben Miller'
,@val875 = 'Ben Miller'
,@val876 = 'Ben Miller'
,@val877 = 'Ben Miller'
,@val878 = 'Ben Miller'
,@val879 = 'Ben Miller'
,@val880 = 'Ben Miller'
,@val881 = 'Ben Miller'
,@val882 = 'Ben Miller'
,@val883 = 'Ben Miller'
,@val884 = 'Ben Miller'
,@val885 = 'Ben Miller'
,@val886 = 'Ben Miller'
,@val887 = 'Ben Miller'
,@val888 = 'Ben Miller'
,@val889 = 'Ben Miller'
,@val890 = 'Ben Miller'
,@val891 = 'Ben Miller'
,@val892 = 'Ben Miller'
,@val893 = 'Ben Miller'
,@val894 = 'Ben Miller'
,@val895 = 'Ben Miller'
,@val896 = 'Ben Miller'
,@val897 = 'Ben Miller'
,@val898 = 'Ben Miller'
,@val899 = 'Ben Miller'
,@val900 = 'Ben Miller'
,@val901 = 'Ben Miller'
,@val902 = 'Ben Miller'
,@val903 = 'Ben Miller'
,@val904 = 'Ben Miller'
,@val905 = 'Ben Miller'
,@val906 = 'Ben Miller'
,@val907 = 'Ben Miller'
,@val908 = 'Ben Miller'
,@val909 = 'Ben Miller'
,@val910 = 'Ben Miller'
,@val911 = 'Ben Miller'
,@val912 = 'Ben Miller'
,@val913 = 'Ben Miller'
,@val914 = 'Ben Miller'
,@val915 = 'Ben Miller'
,@val916 = 'Ben Miller'
,@val917 = 'Ben Miller'
,@val918 = 'Ben Miller'
,@val919 = 'Ben Miller'
,@val920 = 'Ben Miller'
,@val921 = 'Ben Miller'
,@val922 = 'Ben Miller'
,@val923 = 'Ben Miller'
,@val924 = 'Ben Miller'
,@val925 = 'Ben Miller'
,@val926 = 'Ben Miller'
,@val927 = 'Ben Miller'
,@val928 = 'Ben Miller'
,@val929 = 'Ben Miller'
,@val930 = 'Ben Miller'
,@val931 = 'Ben Miller'
,@val932 = 'Ben Miller'
,@val933 = 'Ben Miller'
,@val934 = 'Ben Miller'
,@val935 = 'Ben Miller'
,@val936 = 'Ben Miller'
,@val937 = 'Ben Miller'
,@val938 = 'Ben Miller'
,@val939 = 'Ben Miller'
,@val940 = 'Ben Miller'
,@val941 = 'Ben Miller'
,@val942 = 'Ben Miller'
,@val943 = 'Ben Miller'
,@val944 = 'Ben Miller'
,@val945 = 'Ben Miller'
,@val946 = 'Ben Miller'
,@val947 = 'Ben Miller'
,@val948 = 'Ben Miller'
,@val949 = 'Ben Miller'
,@val950 = 'Ben Miller'
,@val951 = 'Ben Miller'
,@val952 = 'Ben Miller'
,@val953 = 'Ben Miller'
,@val954 = 'Ben Miller'
,@val955 = 'Ben Miller'
,@val956 = 'Ben Miller'
,@val957 = 'Ben Miller'
,@val958 = 'Ben Miller'
,@val959 = 'Ben Miller'
,@val960 = 'Ben Miller'
,@val961 = 'Ben Miller'
,@val962 = 'Ben Miller'
,@val963 = 'Ben Miller'
,@val964 = 'Ben Miller'
,@val965 = 'Ben Miller'
,@val966 = 'Ben Miller'
,@val967 = 'Ben Miller'
,@val968 = 'Ben Miller'
,@val969 = 'Ben Miller'
,@val970 = 'Ben Miller'
,@val971 = 'Ben Miller'
,@val972 = 'Ben Miller'
,@val973 = 'Ben Miller'
,@val974 = 'Ben Miller'
,@val975 = 'Ben Miller'
,@val976 = 'Ben Miller'
,@val977 = 'Ben Miller'
,@val978 = 'Ben Miller'
,@val979 = 'Ben Miller'
,@val980 = 'Ben Miller'
,@val981 = 'Ben Miller'
,@val982 = 'Ben Miller'
,@val983 = 'Ben Miller'
,@val984 = 'Ben Miller'
,@val985 = 'Ben Miller'
,@val986 = 'Ben Miller'
,@val987 = 'Ben Miller'
,@val988 = 'Ben Miller'
,@val989 = 'Ben Miller'
,@val990 = 'Ben Miller'
,@val991 = 'Ben Miller'
,@val992 = 'Ben Miller'
,@val993 = 'Ben Miller'
,@val994 = 'Ben Miller'
,@val995 = 'Ben Miller'
,@val996 = 'Ben Miller'
,@val997 = 'Ben Miller'
,@val998 = 'Ben Miller'
,@val999 = 'Ben Miller'
,@val1000 = 'Ben Miller'

SET STATISTICS TIME OFF

GO

DECLARE @Name varchar(20)
SET @Name = (SELECT TOP 1 Name FROM dbo.Table1)
GO

DECLARE @Name varchar(20)
SELECT @Name = Name
FROM dbo.Table1

SELECT @Name
GO
SELECT * FROM dbo.Table1
GO

DECLARE @Name varchar(20)
SELECT TOP 1 @Name = Name
FROM dbo.Table1
ORDER BY id ASC

SELECT @Name
GO
SELECT * FROM dbo.Table1
GO

DECLARE @Name varchar(20)
UPDATE dbo.Table1
SET Name = 'Carolina',
	@Name = Name
WHERE id = 500

SELECT @Name AS [FromUpdate], Name
FROM dbo.Table1
WHERE id = 500

GO

/**********************************************
	Temp Table Caching

	https://www.sql.kiwi/2012/08/temporary-object-caching-explained.html
************************************************/

CREATE OR ALTER PROCEDURE dbo.Demo
AS 
CREATE TABLE #table1 (id int NOT NULL PRIMARY KEY, id2 int null)
CREATE TABLE #table2 (id int NOT NULL, CONSTRAINT PK_#table2 PRIMARY KEY (id))
WAITFOR DELAY '00:00:01'

GO
DBCC FREEPROCCACHE
WAITFOR DELAY '00:00:05';
GO
exec dbo.Demo
GO
SELECT
    T.*
FROM tempdb.sys.tables AS T
WHERE
    T.[name] LIKE 
        N'#[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]';
GO

CREATE OR ALTER PROCEDURE dbo.Demo
AS 
CREATE TABLE #table1 (id int NOT NULL PRIMARY KEY, id2 int null)
CREATE TABLE #table2 (id int NOT NULL PRIMARY KEY)
WAITFOR DELAY '00:00:01'

GO
DBCC FREEPROCCACHE
WAITFOR DELAY '00:00:05';
GO
exec dbo.Demo
GO
SELECT
    T.*
FROM tempdb.sys.tables AS T
WHERE
    T.[name] LIKE 
        N'#[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]';


CREATE OR ALTER PROCEDURE dbo.Demo
AS 
CREATE TABLE #table1 (id int NOT NULL PRIMARY KEY, id2 int NULL)
CREATE INDEX IX_#temp1 ON #table1 (id2)
CREATE TABLE #table2 (id int NOT NULL PRIMARY KEY)
WAITFOR DELAY '00:00:01'

GO
DBCC FREEPROCCACHE
WAITFOR DELAY '00:00:05';
GO
exec dbo.Demo

SELECT
    T.*
FROM tempdb.sys.tables AS T
WHERE
    T.[name] LIKE 
        N'#[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]';

CREATE OR ALTER PROCEDURE dbo.Demo
AS 
CREATE TABLE #table1 (id int NOT NULL PRIMARY KEY, id2 int NULL INDEX IX_#cl)
CREATE TABLE #table2 (id int NOT NULL PRIMARY KEY)
WAITFOR DELAY '00:00:01'

GO
DBCC FREEPROCCACHE
WAITFOR DELAY '00:00:05';
GO
exec dbo.Demo

SELECT
    T.*
FROM tempdb.sys.tables AS T
WHERE
    T.[name] LIKE 
        N'#[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]';


/******************************************
	DROP TABLE #temp1

Drop table is not DDL that will cause the invalidation
of a cached temp table and neither is TRUNCATE TABLE
But DROP TABLE #temp1 could block tempdb
because of the SCH_M lock taken to drop the object

*******************************************/

/******************************
	Data Types

Used to create my accounts table

CREATE TABLE dbo.Accounts (
	AccountNumber NVARCHAR(100) NOT NULL,
	AcctName VARCHAR(50) NOT NULL,
	Address1 VARCHAR(25) NOT NULL,
	Address2 VARCHAR(25) NULL,
	City VARCHAR(25) NOT NULL,
	StateCode CHAR(2) NOT NULL,
	PostalCode VARCHAR(10) NOT NULL
)
GO

CREATE SEQUENCE dbo.Sequence1 AS int
    START WITH 1
    INCREMENT BY 2 ;
GO
set nocount on

INSERT INTO dbo.Accounts (AccountNumber, AcctName, Address1, Address2, City, StateCode, PostalCode)
SELECT NEXT VALUE FOR dbo.Sequence1, 'Acct Name'+CONVERT(varchar(12),NEXT VALUE FOR dbo.Sequence1), 'Address '+CONVERT(varchar(12), Next Value for dbo.Sequence1),
'Address '+CONVERT(varchar(12), Next Value for dbo.Sequence1),'City '+CONVERT(varchar(12), Next value for dbo.Sequence1), 'OH', '45142'
GO 500000

CREATE UNIQUE CLUSTERED INDEX PK_Accounts_AccountNumber ON dbo.Accounts (
	AccountNumber
)
GO

SELECT COUNT(*)
from dbo.Accounts

*/


SET NOCOUNT ON
SET STATISTICS IO ON
-- Data type precedence will convert the AccountNumber to Int
-- Which causes a table scan to implicitly convert the values.

/* Excerpt from the Data Type Precedence chart */
/*
1. user-defined data types (highest)
2. sql_variant
3. xml
4. datetimeoffset
5. datetime2
6. datetime
7. smalldatetime
8. date
9. time
10.float
11.real
12.decimal
13.money
14.smallmoney
15.bigint
16.int
17.smallint
18.tinyint
19.bit
20.ntext
21.text
22.image
23.timestamp
24.uniqueidentifier
25.nvarchar (including nvarchar(max) )
26.nchar
27.varchar (including varchar(max) )
28.char
29.varbinary (including varbinary(max) )
30.binary (lowest)
*/
DECLARE @DistributorId INT
SET @DistributorId = 120021

SELECT *
FROM dbo.Accounts 
WHERE AccountNumber = @DistributorId
GO

-- Now with a specific datatype converted.
DECLARE @DistributorId INT
SET @DistributorId = 120021

SELECT *
FROM dbo.Accounts 
WHERE AccountNumber = CONVERT(NVARCHAR(100), @DistributorId)
GO

/*
Table 'Accounts'. Scan count 1, logical reads 3814, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
 SQL Server Execution Times:
   CPU time = 108 ms,  elapsed time = 32 ms.
   
Table 'Accounts'. Scan count 0, logical reads 3, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
 SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 0 ms.
*/

GO
CREATE INDEX IX_Accounts_AcctName on dbo.Accounts (AcctName)

SELECT * FROM dbo.Accounts
WHERE ISNULL(AcctName, '') = ''

SELECT * FROM dbo.Accounts
WHERE AcctName IS NULL --ISNULL(AcctName, '') = ''


CREATE INDEX IX_Accounts_Address2 on dbo.Accounts (Address2)

SELECT * FROM dbo.Accounts
where ISNULL(Address2,'') = '' 

SELECT * FROM dbo.Accounts
where Address2 IS NULL


SET STATISTICS IO OFF
SET NOCOUNT OFF


/*****************************************
	Schema Qualify Objects
******************************************/

/*
Contact Information:
Ben Miller
ben@benmiller.net
@DBAduck
*/
USE DEMO1
GO

/*
USE [master]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [testlogin]    Script Date: 3/6/2014 6:37:15 AM ******/
CREATE LOGIN [testlogin] WITH PASSWORD=N'Password1', DEFAULT_DATABASE=[master], 
		CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

USE [Demo1]
GO
/****** Object:  User [testlogin]    Script Date: 3/6/2014 6:38:17 AM ******/
CREATE USER [testlogin] FOR LOGIN [testlogin] WITH DEFAULT_SCHEMA=[dba]
GO

CREATE TABLE dbo.TestSchema (
	field1 VARCHAR(10)
)
GO
CREATE SCHEMA dba AUTHORIZATION [dbo]
GO
CREATE TABLE dba.TestSchema (
	field2 varchar(10)
)
insert into dbo.TestSchema values ('dbo')
insert into dba.TestSchema values ('dba')
grant select on dba.TestSchema to testlogin

GO
*/

-- Which table do I get?

SELECT *
FROM TestSchema

-- Lets try as testlogin
EXECUTE AS USER = 'testlogin'

select SUSER_NAME()

GO
SELECT *
FROM TestSchema
GO
REVERT
GO
SELECT *
FROM dba.TestSchema


SELECT *
FROM TestSchema

/**********************************************
	Plan Cache

***********************************************/
DBCC freeproccache

-- View the cached plans
SELECT DISTINCT
	CP.bucketid, CP.cacheobjtype, CP.objtype, CP.usecounts, CO.sqlbytes, CP.size_in_bytes, CO.[sql]
FROM sys.syscacheobjects CO
INNER JOIN sys.dm_exec_cached_plans CP ON CO.bucketid = CP.bucketid

-- Let's do a basic query
SELECT *
FROM  dbo.testschema

-- Let's do the same query, Kind Of
SELECT *
FROM dbo.TestSchema

-- You will see queries that have their own plan because of 
-- Case Sensitivity
SELECT *
FROM  dbo.TestSchema

GO
-- View the cached plans
/*
SELECT bucketid, usecounts, size_in_bytes, cacheobjtype, objtype
FROM sys.dm_exec_cached_plans
*/

-- View the cached plans
SELECT 
	CP.bucketid, CP.cacheobjtype, CP.objtype, CP.usecounts, CO.sqlbytes, CP.size_in_bytes, CO.[sql]
FROM sys.syscacheobjects CO
INNER JOIN sys.dm_exec_cached_plans CP ON CO.bucketid = CP.bucketid
WHERE [sql] LIKE 'SELECT %'


SELECT bucketid, usecounts, size_in_bytes, cacheobjtype, objtype
FROM sys.dm_exec_cached_plans
where bucketid in (
11129
,11704
,7391
)

-- turn on optimize for adhoc workloads
exec sp_configure 'Show advanced', 1
reconfigure

exec sp_configure 'Optimize for', 1
reconfigure

exec sp_configure 'Show advanced', 0
reconfigure

/* Turn it off */

exec sp_configure 'Show advanced', 1
reconfigure

exec sp_configure 'Optimize for', 0
reconfigure

exec sp_configure 'Show advanced', 0
reconfigure

GO

/********************************************
	SET NOCOUNT
*********************************************/
CREATE OR ALTER PROCEDURE dbo.Demo1
AS 
	SET NOCOUNT ON;

	SELECT * FROM dbo.Table1

	SET NOCOUNT OFF;

GO


/***************************************
	Overindexing
****************************************/

CREATE TABLE dbo.OverIndexed (
	id int NOT NULL IDENTITY(1,1),
	name1 char(20),
	name2 char(30),
	name3 char(40),
	name4 char(10),
	name5 char(20),
	name6 char(40),
	name7 char(20),
	name8 char(50),
	name9 char(40),
	name10 char(50),
	CONSTRAINT PK_OverIndexed_id PRIMARY KEY CLUSTERED (
		id
	)
)
CREATE INDEX IX_OverIndexed_name1 ON dbo.OverIndexed (name1)
CREATE INDEX IX_OverIndexed_name2 ON dbo.OverIndexed (name2)
CREATE INDEX IX_OverIndexed_name3 ON dbo.OverIndexed (name3)
CREATE INDEX IX_OverIndexed_name4 ON dbo.OverIndexed (name4)
CREATE INDEX IX_OverIndexed_name5 ON dbo.OverIndexed (name5)
CREATE INDEX IX_OverIndexed_name6 ON dbo.OverIndexed (name6)
CREATE INDEX IX_OverIndexed_name7 ON dbo.OverIndexed (name7)
CREATE INDEX IX_OverIndexed_name8 ON dbo.OverIndexed (name8)
CREATE INDEX IX_OverIndexed_name9 ON dbo.OverIndexed (name9)
CREATE INDEX IX_OverIndexed_name10 ON dbo.OverIndexed (name10)
CREATE INDEX IX_OverIndexed_name11 ON dbo.OverIndexed (name1)
CREATE INDEX IX_OverIndexed_name12 ON dbo.OverIndexed (name2)
CREATE INDEX IX_OverIndexed_name13 ON dbo.OverIndexed (name3)
CREATE INDEX IX_OverIndexed_name14 ON dbo.OverIndexed (name4)
CREATE INDEX IX_OverIndexed_name15 ON dbo.OverIndexed (name5)
CREATE INDEX IX_OverIndexed_name16 ON dbo.OverIndexed (name6)
CREATE INDEX IX_OverIndexed_name17 ON dbo.OverIndexed (name7)
CREATE INDEX IX_OverIndexed_name18 ON dbo.OverIndexed (name8)
CREATE INDEX IX_OverIndexed_name19 ON dbo.OverIndexed (name9)
CREATE INDEX IX_OverIndexed_name20 ON dbo.OverIndexed (name1)
CREATE INDEX IX_OverIndexed_name21 ON dbo.OverIndexed (name2)
CREATE INDEX IX_OverIndexed_name22 ON dbo.OverIndexed (name3)
CREATE INDEX IX_OverIndexed_name23 ON dbo.OverIndexed (name4)
CREATE INDEX IX_OverIndexed_name24 ON dbo.OverIndexed (name5)
CREATE INDEX IX_OverIndexed_name25 ON dbo.OverIndexed (name6)
CREATE INDEX IX_OverIndexed_name26 ON dbo.OverIndexed (name7)
CREATE INDEX IX_OverIndexed_name27 ON dbo.OverIndexed (name8)
CREATE INDEX IX_OverIndexed_name28 ON dbo.OverIndexed (name9)
CREATE INDEX IX_OverIndexed_name29 ON dbo.OverIndexed (name1)
CREATE INDEX IX_OverIndexed_name30 ON dbo.OverIndexed (name2)
CREATE INDEX IX_OverIndexed_name31 ON dbo.OverIndexed (name3)
GO

SET STATISTICS IO ON
SET NOCOUNT ON
GO
INSERT INTO [dbo].[OverIndexed]
           ([name1]
           ,[name2]
           ,[name3]
           ,[name4]
           ,[name5]
           ,[name6]
           ,[name7]
           ,[name8]
           ,[name9]
           ,[name10])
     VALUES
           ('Bob'
           ,'Jimmy'
           ,'George'
           ,'Jenny'
           ,'Anna'
           ,'Pedro'
           ,'Bradley'
           ,'Tim'
           ,'Jes'
           ,'Tim')
GO 100


DROP INDEX IX_OverIndexed_name11 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name12 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name13 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name14 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name15 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name16 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name17 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name18 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name19 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name20 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name21 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name22 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name23 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name24 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name25 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name26 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name27 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name28 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name29 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name30 ON dbo.OverIndexed
DROP INDEX IX_OverIndexed_name31 ON dbo.OverIndexed
GO

INSERT INTO [dbo].[OverIndexed]
           ([name1]
           ,[name2]
           ,[name3]
           ,[name4]
           ,[name5]
           ,[name6]
           ,[name7]
           ,[name8]
           ,[name9]
           ,[name10])
     VALUES
           ('Bob'
           ,'Jimmy'
           ,'George'
           ,'Jenny'
           ,'Anna'
           ,'Pedro'
           ,'Bradley'
           ,'Tim'
           ,'Jes'
           ,'Tim')
GO 100

DELETE TOP (100) FROM dbo.OverIndexed

/**************************************
	IN, NOT IN, EXISTS, NOT EXISTS

DROP INDEX [IX_Accounts_AcctName] ON dbo.Accounts
DROP INDEX [IX_Accounts_Address2] ON dbo.Accounts
DROP INDEX [PK_Accounts_AccountNumber] ON dbo.Accounts
ALTER TABLE dbo.Accounts ALTER COLUMN AccountNumber int not null

ALTER TABLE dbo.Accounts ADD CONSTRAINT PK_Accounts_AccountNumber PRIMARY KEY CLUSTERED (AccountNumber)

***************************************/
SET STATISTICS IO OFF
SET NOCOUNT ON

CREATE TABLE dbo.HoldingTable (
	id int NOT NULL PRIMARY KEY
)
CREATE SEQUENCE dbo.Numbers START WITH 1 INCREMENT BY 10

INSERT INTO dbo.HoldingTable (id) VALUES(NEXT VALUE FOR dbo.Numbers)
GO 5000

SET STATISTICS IO, TIME ON

SELECT * FROM dbo.Accounts
WHERE AccountNumber IN (SELECT id FROM dbo.HoldingTable)

SELECT * FROM dbo.Accounts A
WHERE EXISTS (SELECT 1 FROM dbo.HoldingTable B WHERE B.id = A.AccountNumber)

SELECT * FROM dbo.Accounts
WHERE AccountNumber NOT IN (SELECT id FROM dbo.HoldingTable)

SELECT * FROM dbo.Accounts A
WHERE NOT EXISTS (SELECT 1 FROM dbo.HoldingTable B WHERE B.id = A.AccountNumber)

