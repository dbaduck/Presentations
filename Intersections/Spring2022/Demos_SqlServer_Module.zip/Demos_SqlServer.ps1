# Common Knowledge
Verb-Sql  # SqlServer Related
Verb-AS # Analysis Serivces



# Notebooks
Invoke-SqlNotebook

#  SSAS
Add-RoleMember
Backup-ASDatabase
Invoke-ASCmd
Merge-Partition
Invoke-ProcessASDatabase
Invoke-ProcessCube
Invoke-ProcessDimension
Invoke-ProcessPartition
Invoke-ProcessTable
Remove-RoleMember
Restore-ASDatabase


# Availability Groups
Add-SqlAvailabilityDatabase
Add-SqlAvailabilityGroupListenerStaticIp
Disable-SqlAlwaysOn
Enable-SqlAlwaysOn
Grant-SqlAvailabilityGroupCreateAnyDatabase
Join-SqlAvailabilityGroup
New-SqlAvailabilityGroup
New-SqlAvailabilityGroupListener
New-SqlAvailabilityReplica
New-SqlHADREndpoint
Remove-SqlAvailabilityDatabase
Remove-SqlAvailabilityGroup
Remove-SqlAvailabilityReplica
Resume-SqlAvailabilityDatabase
Revoke-SqlAvailabilityGroupCreateAnyDatabase
Set-SqlAvailabilityGroup
Set-SqlAvailabilityGroupListener
Set-SqlAvailabilityReplica
Set-SqlAvailabilityReplicaRoleToSecondary
Set-SqlHADREndpoint
Suspend-SqlAvailabilityDatabase
Switch-SqlAvailabilityGroup
Test-SqlAvailabilityGroup
Test-SqlAvailabilityReplica
Test-SqlDatabaseReplicaState

# Always Encrypted - Column Encryption
Add-SqlColumnEncryptionKeyValue
Complete-SqlColumnMasterKeyRotation
Get-SqlColumnEncryptionKey
Get-SqlColumnMasterKey
Invoke-SqlColumnMasterKeyRotation
New-SqlCertificateStoreColumnMasterKeySettings
New-SqlCngColumnMasterKeySettings
New-SqlColumnEncryptionKey
New-SqlColumnEncryptionKeyEncryptedValue
New-SqlColumnEncryptionSettings
New-SqlColumnMasterKey
New-SqlColumnMasterKeySettings
New-SqlCspColumnMasterKeySettings
Remove-SqlColumnEncryptionKey
Remove-SqlColumnEncryptionKeyValue
Remove-SqlColumnMasterKey
Set-SqlColumnEncryption

# Utilities
Add-SqlLogin
Convert-UrnToPath
ConvertFrom-EncodedSqlName
ConvertTo-EncodedSqlName
Get-SqlDatabase
Get-SqlErrorLog
Get-SqlInstance
Get-SqlLogin
Get-SqlSensitivityClassification
Get-SqlSensitivityRecommendations
Get-SqlSmartAdmin
Start-SqlInstance
Stop-SqlInstance
Invoke-Sqlcmd
New-RestoreFolder
New-RestoreLocation
New-SqlAzureKeyVaultColumnMasterKeySettings
New-SqlCredential
Read-SqlTableData
Read-SqlViewData
Read-SqlXEvent
Remove-SqlCredential
Remove-SqlFirewallRule
Remove-SqlLogin
Remove-SqlSensitivityClassification
Save-SqlMigrationReport
Set-SqlAuthenticationMode
Set-SqlCredential
Set-SqlErrorLog
Set-SqlNetworkConfiguration
Set-SqlSensitivityClassification
Write-SqlTableData


# Sql Agent
Get-SqlAgent
Get-SqlAgentJob
Get-SqlAgentJobHistory
Get-SqlAgentJobSchedule
Get-SqlAgentJobStep
Get-SqlAgentSchedule

# Backup / Restore
Backup-SqlDatabase
Get-SqlBackupHistory
Get-SqlCredential
New-SqlBackupEncryptionOption
Restore-SqlDatabase


Add-SqlAzureAuthenticationContext
Add-SqlFirewallRule

# Vulnerability Assessment / Assessment
Export-SqlVulnerabilityAssessmentBaselineSet
Export-SqlVulnerabilityAssessmentScan
Get-SqlAssessmentItem
Import-SqlVulnerabilityAssessmentBaselineSet
Invoke-SqlAssessment
Invoke-SqlVulnerabilityAssessmentScan
New-SqlVulnerabilityAssessmentBaseline
New-SqlVulnerabilityAssessmentBaselineSet

# PBM
Invoke-PolicyEvaluation

# SmartAdmin
Set-SqlSmartAdmin
Test-SqlSmartAdmin

# Sql Server PowerShell Provider
SQLSERVER:

