# Common Knowledge
Verb-Dba  (most commands)
Verb-DbaDb (Having to do with a Database)
Verb-DbaAg (Having to do with an Availability Group)

# Parameters
-SqlInstance (most always is an Array)
-Database (most always is an Array)
-EnableException (always off by default, you can enable to be able to get raw exception)

# Data or Object
.GetType()
| Get-Member

# Default View
Is there more to the object?  Ensure that you know so that you can get the most out.

Connect-DbaInstance -SqlInstance ag01

Connect-DbaInstance -SqlInstance ag01 | Get-Member
$s = Connect-DbaInstance -SqlInstance ag01
$s.gettype()

$file = get-dbadbfile -sqlinstance ag01 -database db1
$file.gettype()
$file
# Surely there is more to this object than just these things

$AgInstances = "AG01","AG02"
# Splatting
$AG = @{
    SqlInstance = $AgInstances
}

$splatInstance = @{SqlInstance=@("AG01","AG01");"Database"="DB1" }

# Splatting
$splatInstance = @{
        SqlInstance = "AG01","AG02"
        Ben = "Bob"
    }
    
Connect-DbaInstance @splatInstance #-SqlCredential

function Get-FLower {
        [CmdLetBinding()]
        param (
                $Bob
        )

        $Bob
}

Get-Flower -Bob "Ben Miller"
Get-Flower "Ben Miller"

Get-Flower @splatInstance

# Predefine places combos

# Profile & Transcripting


# Windows Failover Clustering
Get-DbaWsfcAvailableDisk
Get-DbaWsfcCluster -ComputerName AG01
Get-DbaWsfcDisk
Get-DbaWsfcNetwork -ComputerName AG01
Get-DbaWsfcNetworkInterface
Get-DbaWsfcNode -Computer AG01
Get-DbaWsfcResource -ComputerName AG01
Get-DbaWsfcResourceType
Get-DbaWsfcRole -ComputerName AG01
Get-DbaWsfcSharedVolume



# AG Creation with AG Database
Add-DbaAgDatabase
Add-DbaAgListener
Add-DbaAgReplica
Disable-DbaAgHadr
Enable-DbaAgHadr
Get-DbaAgBackupHistory
Get-DbaAgDatabase
Get-DbaAgHadr
Get-DbaAgListener
Get-DbaAgReplica
Get-DbaAvailabilityGroup
Grant-DbaAgPermission
Invoke-DbaAgFailover
Join-DbaAvailabilityGroup
New-DbaAvailabilityGroup
Remove-DbaAgDatabase
Remove-DbaAgListener
Remove-DbaAgReplica
Remove-DbaAvailabilityGroup
Resume-DbaAgDbDataMovement
Revoke-DbaAgPermission
Set-DbaAgListener
Set-DbaAgReplica
Set-DbaAvailabilityGroup
Suspend-DbaAgDbDataMovement
Sync-DbaAvailabilityGroup
Test-DbaAvailabilityGroup


New-DbaAvailabilityGroup -Primary AG01 -Name DBATOOLSAG -ClusterType Wsfc -AutomatedBackupPreference Secondary -Confirm:$false

Get-DbaAvailabilityGroup -SqlInstance AG01 -AvailabilityGroup DBATOOLSAG | 
        Add-DbaAgReplica -SqlInstance AG02 -FailoverMode Manual -SeedingMode Manual

Add-DbaAgDatabase -SqlInstance AG01 -AvailabilityGroup DBATOOLSAG -Database DB1 `
        -Secondary AG02 -SeedingMode Manual -SharedPath \\SQL01\SQLBACKUP 



Get-DbaAvailabilityGroup -SqlInstance ag01

Add-DbaAgListener -SqlInstance AG01 -AvailabilityGroup DBATOOLSAG -Name AGLISTEN -Port 1433 -Dhcp

Invoke-DbaAgFailover -SqlInstance AG02 -AvailabilityGroup DBATOOLSAG -Confirm:$false
Invoke-DbaAgFailover -SqlInstance AG01 -AvailabilityGroup DBATOOLSAG -Confirm:$false

Remove-DbaAvailabilityGroup -SqlInstance AG01 -AvailabilityGroup DBATOOLSAG

Get-DbaEndpoint -SqlInstance AG01, AG02 -Type DatabaseMirroring | Remove-DbaEndpoint


# DBAtools Config stuff

Get-DbatoolsConfig

set-dbatoolsconfig -fullname commands.get-dbaregserver.defaultcms -value AG01
Get-DbaToolsConfigValue -fullname commands.get-dbaregserver.defaultcms

Get-DbaToolsConfigValue -FullName import.sqlpscheck
Set-DbaToolsConfig -FullName import.sqlpscheck -Value $false

# Persist it across sessions on that computer
Set-DbatoolsConfig -Name Import.SqlpsCheck -Value $false -PassThru | Register-DbatoolsConfig

# Remove all registered config
Unregister-DbatoolsConfig 


# Test in another window.
Import-Module sqlserver
Import-Module DBAtools



# Community tools installs
Install-DbaDarlingData
Install-DbaFirstResponderKit
Install-DbaMaintenanceSolution
Install-DbaMultiTooln
Install-DbaSqlWatch
Install-DbaWhoIsActive

# Invoke-ing Community Tools
Invoke-DbaWhoisActive -SqlInstance ag01
Install-DbaWhoIsActive -SqlInstance AG01 -Database master

Export-DbaDiagnosticQuery -sqlInstance AG01 

Invoke-DbaDiagnosticQuery -SqlInstance AG01 -UseSelectionHelper

#  Migration
Copy-DbaAgentAlert
Copy-DbaAgentJobCategory
Copy-DbaAgentJob
Copy-DbaAgentOperator
Copy-DbaAgentProxy
Copy-DbaAgentServer
Copy-DbaAgentSchedule
Copy-DbaBackupDevice
Copy-DbaCredential
Copy-DbaCustomError
Copy-DbaDatabase
Copy-DbaDataCollector
Copy-DbaDbAssembly
Copy-DbaDbMail
Copy-DbaDbQueryStoreOption
Copy-DbaEndpoint
Copy-DbaInstanceAudit
Copy-DbaInstanceAuditSpecification
Copy-DbaInstanceTrigger
Copy-DbaLinkedServer
Copy-DbaLogin
Copy-DbaPolicyManagement
Copy-DbaRegServer
Copy-DbaResourceGovernor
Copy-DbaSpConfigure
Copy-DbaStartupProcedure
Copy-DbaSysDbUserObject
Copy-DbaXESession
Start-DbaMigration -Source SQL01 -Destination SQL02 -BackupRestore -SharedPath "\\SQL01\SQLBACKUP" 

copy-dbaagentjob -source sql01 -destination sql02 -force
Test-DbaMigrationConstraint

get-dbatoolslog -error 

# Backup and Restore

Backup-DbaDatabase
$model = Get-DbaDbRecoveryModel -Sqlinstance SQL01 -Database DBLARGE

Format-DbaBackupInformation
Get-DbaDbBackupHistory -sqlinstance ag01 -lastfull | Restore-DbaDatabase -sqlinstance sql01 -ReuseSourceFolderStructure -TrustDbBackupHistory -whatif
Get-DbaDbBackupHistory -sqlinstance ag01 -lastfull | Restore-DbaDatabase -sqlinstance sql01 -ReuseSourceFolderStructure -TrustDbBackupHistory  -OutputScriptOnly



Get-DbaBackupInformation

Get-DbaDbExtentDiff
Get-DbaDbRestoreHistory
Get-DbaLastBackup
Invoke-DbaAdvancedRestore
Measure-DbaBackupThroughput -sqlinstance ag01
Read-DbaBackupHeader
Remove-DbaBackup
Remove-DbaDbBackupRestoreHistory
Restore-DbaDatabase
Select-DbaBackupInformation
Test-DbaBackupInformation
Test-DbaDbRecoveryModel
Test-DbaLastBackup

get-childitem -path \\sql01\sqlbackup -filter *.trn | Where LastwriteTime -gt (Get-Date).AddHours(-12) | Restore-DbaDatabase
Get-ChildItem -path \\sql01\sqlbackup -filter *.trn | restore-dbadatabase -sqlinstance sql01 

# WhatIf
dir \\sql01\sqlbackup | Remove-Item -whatif

# Login Management
Add-DbaDbRoleMember
Add-DbaServerRoleMember
Get-DbaDbOrphanUser -sqlinstance sql02 # -Database DBLARGE
Get-DbaDbRole
Get-DbaDbRoleMember
Get-DbaDbUser
Get-DbaLogin
Get-DbaServerRole
Get-DbaServerRoleMember
New-DbaDbRole
New-DbaDbUser
New-DbaLogin
New-DbaServerRole
Remove-DbaDbOrphanUser
Remove-DbaDbRole
Remove-DbaDbRoleMember
Remove-DbaDbUser
Remove-DbaLogin
Remove-DbaServerRole
Remove-DbaServerRoleMember
Rename-DbaLogin
Repair-DbaDbOrphanUser -sqlinstance sql02 -database DBLARGE
Copy-DbaLogin -Source sql01 -destination sql02 -login TestLogin
Set-DbaLogin
Sync-DbaLoginPermission
Test-DbaLoginPassword
Test-DbaWindowsLogin
Watch-DbaDbLogin


Invoke-Command -ComputerName AG01, AG02 -ScriptBlock { Install-Module dbatools -confirm:$false -force }


# Databases
Get-DbaDatabase
Get-DbaDbAssembly
Get-DbaDbCertificate
Get-DbaDbCheckConstraint
Get-DbaDbCompatibility -Sqlinstance sql01 | Where Database -notin @("master","model","msdb","tempdb") | Export-csv -path c:\demos\databases.csv -notypeinformation

$dbs = import-csv -path c:\demos\databases.csv

foreach($db in $dbs) {
        Set-DbaDbCompatibility -SqlInstance $db.ComputerName -Database $db.Database -Compatibility $db.Compatibility
}

$dbs | Write-DbaDbTableData -Sqlinstance sql01 -database DB01 -schema dbo -table DatabaseSettings -AutoCreateTable
$rows = Invoke-dbaquery -sqlinstance sql01 -database DB01 -Query "SELECT * FROM dbo.DatabaseSettings"

$rows 
Get-DbaDbFeatureUsage
Get-DbaDbIdentity
Get-DbaDbMemoryUsage
Get-DbaDbMirrorMonitor
Get-DbaDbObjectTrigger
Get-DbaDbPageInfo
Get-DbaDbPartitionFunction
Get-DbaDbPartitionScheme
Get-DbaDbQueryStoreOption
Get-DbaDbSchema
Get-DbaDbSharePoint
Get-DbaDbSpace
Get-DbaDbState
Get-DbaDbStoredProcedure
Get-DbaDbSynonym
Get-DbaDbTable
Get-DbaDbTrigger
Get-DbaDbUdf
Get-DbaDbUserDefinedTableType
Get-DbaDbView
Get-DbaHelpIndex
Get-DbaSuspectPage
Invoke-DbaDbClone
Invoke-DbaDbShrink
Invoke-DbaDbUpgrade
New-DbaDatabase
New-DbaDbSchema
New-DbaDbSynonym
Remove-DbaDatabase
Remove-DbaDatabaseSafely
Remove-DbaDbSchema
Remove-DbaDbSynonym
Remove-DbaDbTable
Remove-DbaDbUdf
Remove-DbaDbView
Rename-DbaDatabase
Set-DbaDbCompatibility
Set-DbaDbIdentity
Set-DbaDbOwner
Set-DbaDbQueryStoreOption
Set-DbaDbRecoveryModel
Set-DbaDbSchema
Set-DbaDbState
Show-DbaDbList
Test-DbaConnectionAuthScheme
Test-DbaDbCollation
Test-DbaDbCompatibility
Test-DbaDbOwner -sqlinstance sql01 -database db01
Test-DbaDbQueryStore -sqlinstance sql01 -database db01
Test-DbaOptimizeForAdHoc -sqlinstance sql01


$Name = "Ben Miller"

"My name is $servers"
'My name is $Name'
$dbs
"My name is $($dbs.Database -join ',')"
$var = @"
This is my string
and I love it $($dbs.Database -join ',')
"@

$var
Get-DbaDiskspace
# Filesystem and Storage
Expand-DbaDbLogFile
Get-DbaDbFile`
Get-DbaDbFileGroup
Get-DbaDbFileGrowth
Get-DbaDbFileMapping
Get-DbaDbLogSpace
Get-DbaDefaultPath
Get-DbaDiskSpace
Get-DbaFile
Move-DbaDbFile
New-DbaDbFileGroup
New-DbaDirectory
Remove-DbaDbFileGroup
Set-DbaDbFileGroup
Set-DbaDbFileGrowth
Set-DbaDefaultPath
Show-DbaInstanceFileSystem
Test-DbaDiskAlignment
Test-DbaDiskAllocation
Test-DbaPath

# Services
Get-DbaService -computername ag01
Get-DbaDbServiceBrokerService
Restart-DbaService
Start-DbaService
Stop-DbaService
Update-DbaServiceAccount


# Utilities
ConvertTo-DbaTimeline
Get-DbaBuild
Get-DbaDependency
Get-DbaInstanceInstallDate
Get-DbaLastGoodCheckDb
Get-DbaPowerPlan -computername ag01
Get-DbaProductKey
Get-DbaSchemaChangeHistory
Get-DbaUptime -sqlinstance ag01
Import-DbaCsv
Invoke-DbaBalanceDataFiles
Invoke-DbaDbDecryptObject
Invoke-DbaQuery
New-DbaSqlParameter
Join-DbaPath
Read-DbaTransactionLog
Repair-DbaInstanceName
Reset-DbaAdmin
Resolve-DbaPath
Select-DbaObject
Set-DbaMaxDop
Set-DbaPowerPlan -computername ag01 -PowerPlan 'High Performance'
Test-DbaBuild
Test-DbaInstanceName
Test-DbaMaxDop
Test-DbaPowerPlan
Update-DbaBuildReference4

# Connections

Connect-DbaInstance
Disconnect-DbaInstance
Get-DbaConnection
Test-DbaConnection

# Network
Get-DbaTcpPort -sqlinstance AG01
Set-DbaTcpPort

# General
Add-DbaExtendedProperty
Get-DbaExtendedProperty
Set-DbaExtendedProperty
Remove-DbaExtendedProperty

Add-DbaExtendedProperty -SqlInstance AG01 -Database db1 -Name version -Value "1.0.0"

Get-DbaExtendedProperty -sqlinstance ag01 -database DB1 

Get-DbaExtendedProperty -sqlinstance ag01 -database DB1  | Remove-DbaExtendedProperty 

#Export

Export-DbaCredential
Export-DbaDacPackage
Export-DbaDbRole
Export-DbaDbTableData
Export-DbaInstance
Export-DbaLinkedServer *
Export-DbaLogin -sqlinstance sql01 -path c:\demos
Export-DbaRegServer -sqlinstance ag01 -path c:\demos
Export-DbaRepServerSetting
Export-DbaScript
Export-DbaServerRole
Export-DbaSpConfigure
Export-DbaSysDbUserObject
Export-DbaUser


# SQL Agent

Get-DbaAgentAlert
Get-DbaAgentAlertCategory
Get-DbaAgentJob
Get-DbaAgentJobCategory
Get-DbaAgentJobHistory
Get-DbaAgentJobOutputFile
Get-DbaAgentJobStep
Get-DbaAgentLog
Get-DbaAgentOperator
Get-DbaAgentProxy
Get-DbaAgentSchedule
Get-DbaAgentServer
Get-DbaRunningJob
New-DbaAgentAlertCategory
New-DbaAgentJob
New-DbaAgentJobCategory
New-DbaAgentJobStep
New-DbaAgentOperator
New-DbaAgentProxy
New-DbaAgentSchedule
Remove-DbaAgentAlert
Remove-DbaAgentAlertCategory
Remove-DbaAgentJob
Remove-DbaAgentJobCategory
Remove-DbaAgentJobStep
Remove-DbaAgentOperator
Remove-DbaAgentProxy
Remove-DbaAgentSchedule
Set-DbaAgentAlert
Set-DbaAgentJob
Set-DbaAgentJobCategory
Set-DbaAgentJobOutputFile
Set-DbaAgentJobOwner
Set-DbaAgentJobStep
Set-DbaAgentOperator
Set-DbaAgentSchedule
Set-DbaAgentServer
Start-DbaAgentJob
Stop-DbaAgentJob
Test-DbaAgentJobOwner
