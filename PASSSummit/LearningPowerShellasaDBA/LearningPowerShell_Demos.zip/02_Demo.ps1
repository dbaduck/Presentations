﻿# Demo 2

# Variables
$name = "Ben Miller"

function prompt {
	Write-Host "$($executionContext.SessionState.Path.CurrentLocation.ProviderPath)" -NoNewline
}

$name
$NAME

# The escape character is the back tick ` and it will only escape the very next character
"This is a string that I will pipeline" `
	| Format-Table

"This is a string that I will pipeline" `
	| Format-Table

# In the second example I have a back-tick and then a space, which 
# means that the CRLF was not escaped, but the space so you get an error

# Arrays
$ary = @() # empty array
$ary = @(1, 2, 3)
$ary = 1,2,3

# Adding to the array
$ary += 4

$ary

# But arrays have side effects when dealing with a great number of items
$ary = @()

$start = Get-Date
1 .. 10000 | foreach { $ary += $_ }
$end = Get-Date

New-TimeSpan -Start $start -End $end

# Alternative
$arylist = New-Object -TypeName System.Collections.ArrayList

$start = Get-Date
1 .. 10000 | % { $null = $arylist.Add($_) }
$end = Get-Date

New-TimeSpan -Start $start -End $end

# Which one wins?  The ArrayList because it is a memory buffer
# Native PowerShell arrays are immutable and will be recreated every +=

# HashTables
$hash = @{ }

$hash.GetType()

$hash = @{ name = "Ben Miller"; state = "Utah" }
$hash

$hash.phone = "555-555-1212"

$hash

# Let's sort things
$hash | Sort-Object Name

$hash.GetEnumerator() | Sort-Object Value
$hash.GetEnumerator() | Sort-Object Key -Descending


# Notice we have used $_?  This is used to denote the current item in the pipeline
# Also there is $PSItem that contains the same thing

1 .. 20 | % { $_ }
1 .. 20 | % { $PSItem }

# Let's look at the modes of Pipeline
# All are ByValue in the .NET way, but let's look at ByPropertyName
function Get-MyName
{
	param (
		[Parameter(ValueFromPipelineByPropertyName=$true)]
		$name
	)
	
	Write-Output $name
}

Get-MyName -name "Ben Miller"
Get-MyName "Ben Miller"

$obj = "" | Select-Object name
$obj.name = "Ben Miller"

$obj

$obj | Get-MyName


function Get-MyName
{
	param (
		[Parameter(ValueFromPipeline = $true)]
		$inputObject
	)
	
	if ($inputObject.name)
	{
		Write-Output $inputObject.name
	}
	else
	{
		Write-Output "Object passed in does not contain 'name' as a property"
	}
}

Get-MyName -inputObject "Ben Miller"

Get-MyName -inputObject $obj

$obj | Get-MyName

