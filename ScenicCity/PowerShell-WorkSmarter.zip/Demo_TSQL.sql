CREATE TABLE dbo.Iterations (
	Id BIGINT NOT NULL IDENTITY(1,1),
	GatherDate DATETIME2(3) NOT NULL,
	CONSTRAINT PK_dbo_Iterations__Id PRIMARY KEY CLUSTERED (
		Id
	)
)

GO

CREATE PROCEDURE dbo.GetNewIteration
AS

SET NOCOUNT ON;

INSERT INTO dbo.Iterations (GatherDate)
OUTPUT inserted.Id AS IterationId
VALUES (GETDATE())

SET NOCOUNT OFF;
GO

ALTER TABLE dbo.stats_DiskSpace ALTER COLUMN ComputerName VARCHAR(128)
ALTER TABLE dbo.stats_DiskSpace ALTER COLUMN Name VARCHAR(64)
ALTER TABLE dbo.stats_DiskSpace ALTER COLUMN Label VARCHAR(32)
ALTER TABLE dbo.stats_DiskSpace ALTER COLUMN SizeInGB DECIMAL(18,2)
ALTER TABLE dbo.stats_DiskSpace ALTER COLUMN FreeInGB DECIMAL(18,2)
ALTER TABLE dbo.stats_DiskSpace ALTER COLUMN PercentFree DECIMAL(5,2)

USE [DBA]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[stats_DriveSpace](
	[Server] [VARCHAR](25) NOT NULL,
	[Name] [VARCHAR](25) NOT NULL,
	[Label] [VARCHAR](25) NULL,
	[SizeInGB] [DECIMAL](10, 2) NOT NULL,
	[FreeInGB] [DECIMAL](10, 2) NOT NULL,
	[PercentFree] [DECIMAL](5, 2) NOT NULL,
	[BlockSize] [INT] NOT NULL,
	[Iterationid] [INT] NOT NULL,
	[driveSpaceId] [BIGINT] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_dbo_stats_driveSpace__drivespaceid] PRIMARY KEY CLUSTERED 
(
	[driveSpaceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[stats_DatabaseSpace](
	[ComputerName] [NVARCHAR](55) NULL,
	[InstanceName] [NVARCHAR](55) NULL,
	[SqlInstance] [NVARCHAR](55) NULL,
	[Database] [NVARCHAR](55) NULL,
	[FileName] [NVARCHAR](55) NULL,
	[FileGroup] [NVARCHAR](55) NULL,
	[PhysicalName] [NVARCHAR](255) NULL,
	[FileType] [NVARCHAR](10) NULL,
	[UsedSpaceMB] [NUMERIC](18, 0) NULL,
	[FreeSpaceMB] [NUMERIC](18, 0) NULL,
	[FileSizeMB] [NUMERIC](18, 0) NULL,
	[PercentUsed] [NUMERIC](18, 0) NULL,
	[AutoGrowth] [NUMERIC](18, 0) NULL,
	[AutoGrowType] [NVARCHAR](25) NULL,
	[SpaceUntilMaxSizeMB] [NUMERIC](18, 0) NULL,
	[AutoGrowthPossibleMB] [NUMERIC](18, 0) NULL,
	[UnusableSpaceMB] [NUMERIC](18, 0) NULL,
	[Iterationid] [INT] NOT NULL,
	[databaseSpaceId] [BIGINT] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_dbo_stats_databaseSpace__drivespaceid] PRIMARY KEY CLUSTERED 
(
	[databaseSpaceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

SELECT
	s.name AS schemaname,
	t.name AS tablename,
	p.rows
FROM sys.schemas s
INNER JOIN sys.tables t ON s.schema_id = t.schema_id
INNER JOIN sys.partitions p ON t.object_id = p.object_id
WHERE t.is_ms_shipped = 0
	AND p.index_id < 2


/****** Object:  Table [dbo].[stats_Table]    Script Date: 6/12/2019 8:33:50 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[stats_Table](
	[servername] [nvarchar](128) NULL,
	[databasename] [nvarchar](128) NULL,
	[schemaname] [sysname] NOT NULL,
	[tablename] [sysname] NOT NULL,
	[rows] [bigint] NULL,
	[IterationId] int not null,
	[statsTableId] bigint NOT NULL IDENTITY(1,1) PRIMARY KEY
) ON [PRIMARY]
GO

