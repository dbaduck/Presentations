# Working Smarter not Harder

<#
Environment
* PowerShell Version
* Execution Policy
* Profile
* Modules Downloaded / Even for Offline

PowerShell Beginnings
* Help (about_ topics)
* Commands
* Variables
* Loops
* Conditional Statements
* Pipelines
* Functions

#>
$ServerName = "SQL01"
import-module dbatools

$server1 = "SQL01"
$server2 = "SQL02"


# PowerShell Version 5.1 or 7.5.1
$PSVersionTable.PSVersion

# Execution Policy
Get-ExecutionPolicy -Scope CurrentUser
Get-ExecutionPolicy -List
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force

# Profile
$profile
# Put this in your profile
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

# Start Transcript
Start-Transcript -Path "C:\Demos\Logs\Precon_Demo_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"

# Scopes
# CurrentUser or LocalMachine
# Default is LocalMachine and will require admin rights to install modules because it is in a protected folder
# CurrentUser is in your user profile and does not require admin rights

# Import dbatools module
# Import-Module dbatools -RequiredVersion 2.1.31
# Import-Module SqlServer

# Install SqlServer module
# install-module sqlserver -Scope CurrentUser -AllowClobber -Force

# PowerShell Beginnings
# Update-Help -Force (Run as Admin as some data goes into protected folders)
# Get-Help about_* -ShowWindow
# Get-Command -Module dbatools -Verb Get
# Get-Command -Module SqlServer
# Get-Command -Module dbatools | measure-object

# About topics
explorer.exe "C:\Windows\System32\WindowsPowerShell\v1.0\en-US"

# Variables
# All of them start with $
$modversion = "2.1.31"

# String replacements work with " but not '
$major = 2
$minor = 1
$patch = 31

$modversion = '$major.$minor.$patch'
$modversion

$modversion = "$($major)_$($minor)_$($patch)"
$modversion

# Comparison operators
# -eq (equals), -ne (not equals), -gt (greater than), -lt (less than), -ge (greater than or equal to), -le (less than or equal to)

# Case sensitivity
# -ceq (case equals), -cne (case not equals), -cgt (case greater than), -clt (case less than), -cge (case greater than or equal to), -cle (case less than or equal to)
# PowerShell is case-insensitive by default, but you can use the case-sensitive versions if needed.

# Loops
# For loop
for ($i = 1; $i -le 5; $i++) {
    Write-Host "Iteration $i"
}
# ForEach loop
$servers = @("SQL01", "SQL02", "SQL03")
foreach ($server in $servers) {
    Write-Host "Processing server: $server"
}

# Conditional Statements
# If statement
if ($modversion -eq "2.1.31") {
    Write-Host "Module version is correct."
} elseif ($modversion -eq "2.1.30") {
    Write-Host "Module version is 2.1.30."
} else { 
    Write-Host "Module version is not correct."
}


# Switch statement
switch ($modversion) {
    "2.1.31" { Write-Host "Module version is 2.1.31." }
    "2.1.30" { Write-Host "Module version is 2.1.30." }
    default { Write-Host "Unknown module version." }
}

# Pipelines
# Using the pipeline to pass data between commands
Get-Process | Where-Object { $_.CPU -gt 100 } | Select-Object -Property Name, CPU

# Functions
# Defining a simple function
function Get-ServerInfo {
    param (
        [string]$ServerName
    )
    $serverInfo = Get-DbaComputerSystem -ComputerName $ServerName
    
    $serverInfo
}

Get-ServerInfo -ServerName $ServerName



$iterationid = Invoke-DbaQuery -SqlInstance $ServerName -Database DBA -Query "EXEC dbo.GetNewIteration" -as SingleValue


$diskspacedt = Get-DbaDiskSpace -ComputerName $ServerName |
    select computername, Name,Label,sizeinGB,FreeInGB,Percentfree,BlockSize, @{label="IterationID"; expression = {$iterationid}}| 
    ConvertTo-DbaDataTable -ea stop
<#
Write-DbaDataTable -SqlInstance $ServerName -Database DBA -Schema dbo -Table stats_DriveSpace -InputObject $diskspacedt -ea stop
#>

Write-SqlTableData -ServerInstance $ServerName -DatabaseName DBA -SchemaName dbo -TableName stats_DriveSpace -InputData $diskspacedt

$dt = Get-DbaDbSpace -SqlInstance $ServerName |
        select ComputerName,InstanceName,SqlInstance,Database,FileName,FileGroup,`
        PhysicalName,FileType,UsedSpace,FreeSpace,FileSize,PercentUsed,`
        AutoGrowth,AutoGrowType,SpaceUntilMaxSize,AutoGrowthPossible,`
        UnusableSpace, @{n='IterationID'; e = {"$iterationid"}} | 
        ConvertTo-DbaDataTable -ea stop
<#      
Write-DbaDataTable -SqlInstance $ServerName -Database DBA -Schema dbo `
        -Table stats_DatabaseSpace -InputObject $dt -ea stop
#>

Write-SqlTableData -ServerInstance $ServerName -DatabaseName DBA -SchemaName dbo -TableName stats_DatabaseSpace -InputData $dt

start-dbamigration -Source SQL01 -Destination SQL02 -BackupRestore -SharedPath "\\SQL01\SQLBACKUP" -DisableJobsOnDestination

