﻿$filename = "$(Split-Path $profile)\Transcripts\Transcript_Demo_$(Get-Date -f 'yyyyMMdd_HHmmss')"
Start-Transcript -Path "$filename.txt"

Import-Module dbatools

Get-Command -Module dbatools -CommandType Function | measure-object
Get-Command -Module dbatools -Verb Test
Get-Command -Module dbatools -Verb Get


$server1 = Connect-DbaInstance -SqlInstance localhost  # -ApplicationIntent, -FailoverPartner
$server1.ConnectionContext.StatementTimeout

$smo = "Microsoft.SqlServer.Management.Smo"
$server2 = New-Object -TypeName "$smo.Server" -ArgumentList localhost
$server2.ConnectionContext.StatementTimeout

$server3 = Connect-DbaInstance -SqlInstance localhost -StatementTimeout 0
$server3.ConnectionContext.StatementTimeout


$db = Get-DbaDatabase -SqlInstance localhost -Database BEN
$db.PageVerify
$db.RecoveryModel
$db.RecoveryModel = "Simple"
$db.Alter()

$db.Drop()
$db.Gettype()


# what is the status of my database?
$disk = Get-DbaDiskSpace -ComputerName localhost

$var = Get-DbaDbFile -sqlinstance localhost -Database DEMODB

# is there more information?
Get-DbaDiskSpace -ComputerName localhost | Format-List *

Get-DbaDiskSpace -ComputerName localhost | Select SizeInGB


# search the error log
Get-DbaErrorLog -SqlInstance localhost -LogNumber 0 -Text "BACKUP"

# Get the DBCC information on the database(s)
Get-DbaLastGoodCheckDb -SqlInstance localhost -Database DEMODB, DEMODB2

# Get all logins (returns SMO)
Get-DbaLogin -SqlInstance localhost | where name -eq 'sa'

# Get specific login and see the type
Get-DbaLogin -SqlInstance localhost -Login 'sa'
(Get-DbaLogin -SqlInstance localhost -Login 'sa').GetType()


# Get me a server setting for Max Server Memory setting.
Get-DbaMaxMemory -SqlInstance localhost
Test-DbaMaxMemory -SqlInstance localhost
Set-DbaMaxMemory -SqlInstance localhost -Max 4096

# what is the status of my protocols on this server?
Get-DbaInstanceProtocol -ComputerName localhost

# Get the sp_configure like stuff
Get-DbaSpConfigure -SqlInstance localhost
Set-DbaSpConfigure

# Back me up
Backup-DbaDatabase -SqlInstance localhost -Database DEMODB


Get-DbaDbBackupHistory -SqlInstance localhost -LastFull -database DEMODB
Get-DbaDbBackupHistory -SqlInstance localhost -LastFull -database DEMODB | Format-List *


# use dba backup history to restore the database.
Get-DbaDbBackupHistory -SqlInstance localhost -LastFull -database DEMODB |
	Restore-DbaDatabase -SqlInstance localhost -DatabaseName DEMODB3 -DestinationFilePrefix bbb `
					-TrustDbBackupHistory

# use dba backup history to restore the database, but only get the script
Get-DbaDbBackupHistory -SqlInstance localhost -LastFull -database DEMODB |
Restore-DbaDatabase -SqlInstance localhost -DatabaseName DEMODB4 -DestinationFilePrefix bbb `
					-MaxTransferSize 1048576 -TrustDbBackupHistory -OutputScriptOnly


# get me some data
$dt = Invoke-DbaQuery -SqlInstance localhost -Database master `
	-Query "SELECT * FROM sys.master_files" -As DataTable

# put that data in a table.
Write-DbaDbTableData -SqlInstance localhost -Database DogFoodConDB -Table master_files1 `
	-Schema dbo -InputObject $dt 

Write-DbaDbTableData -SqlInstance localhost -Database DogFoodConDB -Table master_files2 `
					 -Schema dbo -InputObject $dt -AutoCreateTable

Stop-Transcript