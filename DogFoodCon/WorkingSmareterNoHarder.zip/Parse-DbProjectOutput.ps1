﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2019 v5.6.163
	 Created on:   	10/2/2019 11:03 PM
	 Created by:   	BenMiller(DBAduck)
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

Function Parse-DbProjectOutput
{
	param ($filepath, $outputpath)
	
	$counter = 1
	$linecount = 1
	
	foreach ($line in (Get-Content $filepath))
	{
		if ($counter -eq 1 -and $linecount -eq 1)
		{
			$line | Add-Content -Path "$outputpath\$($counter)_file.sql"
			$linecount += 1
		}
		else
		{
			$line | Add-Content -Path "$outputpath\$($counter)_file.sql"
			if ($line.StartsWith("GO"))
			{
				$counter += 1
			}
		}
	}	
	
}


Parse-DbProjectOutput -filepath "D:\Data\Dropbox\Documents (1)\MaritzCX\ReleaseAutomation\Kermit - Release Scripts\Customer DBs\CustomerDB_Kermit.sql" -outputpath d:\Temp\ParseDbProject
