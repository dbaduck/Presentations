/*
Contact Information:
Ben Miller
ben@benmiller.net
@DBAduck

USE [master]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [testlogin]    Script Date: 3/6/2014 6:37:15 AM ******/
CREATE LOGIN [testlogin] DEFAULT_DATABASE=[master]
GO
USE [DemoDB]
GO
/****** Object:  User [testlogin]    Script Date: 3/6/2014 6:38:17 AM ******/
CREATE USER [testlogin] FOR LOGIN [testlogin] WITH DEFAULT_SCHEMA=[dba]
GO

CREATE TABLE TestTable (
	field VARCHAR(10)
)

CREATE TABLE dbo.TestSchema (
	field1 VARCHAR(10)
)
GO
CREATE SCHEMA dba AUTHORIZATION [dbo]
GO
CREATE TABLE dba.TestSchema (
	field2 varchar(10)
)
INSERT INTO dbo.TestSchema VALUES ('dbo')
INSERT INTO dba.TestSchema VALUES ('dba')

GO
*/

-- Which table do I get?
SELECT *
FROM TestSchema


-- Lets try as testlogin
EXECUTE AS USER = 'testlogin'

GO
SELECT *
FROM Ben
GO
REVERT
GO
SELECT *
FROM dbo.Ben

SELECT *
FROM Ben
