USE UTCodeCamp
GO

CREATE TABLE dbo.Accounts (
	AccountNumber NVARCHAR(100) NOT NULL,
	AcctName VARCHAR(50) NOT NULL,
	Address1 VARCHAR(25) NOT NULL,
	Address2 VARCHAR(25) NULL,
	City VARCHAR(25) NOT NULL,
	StateCode CHAR(2) NOT NULL,
	PostalCode VARCHAR(10) NOT NULL
)
GO


CREATE UNIQUE CLUSTERED INDEX PK_Accounts_AccountNumber ON dbo.Accounts (
	AccountNumber
)
GO

SET NOCOUNT ON
SET STATISTICS IO ON
-- Data type precedence

DECLARE @DistributorId INT
SET @DistributorId = 120020

SELECT *
FROM dbo.Accounts 
WHERE AccountNumber = @DistributorId
GO

-- Now with a specific datatype converted.
DECLARE @DistributorId INT
SET @DistributorId = 120020

SELECT *
FROM dbo.Accounts 
WHERE AccountNumber = CONVERT(NVARCHAR(100), @DistributorId)
GO

/*
Table 'Accounts'. Scan count 9, logical reads 9092, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
 SQL Server Execution Times:
   CPU time = 108 ms,  elapsed time = 32 ms.
   
Table 'Accounts'. Scan count 0, logical reads 3, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
 SQL Server Execution Times:
   CPU time = 0 ms,  elapsed time = 0 ms.
*/