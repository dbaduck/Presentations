/*
Contact Information:
Ben Miller
ben@benmiller.net
@DBAduck
*/

CREATE TABLE TestTable (
	field VARCHAR(10)
)

CREATE TABLE dbo.TestSchema (
	field1 VARCHAR(10)
)
GO
CREATE SCHEMA dba AUTHORIZATION [dbo]
GO
CREATE TABLE dba.TestSchema (
	field2 varchar(10)
)
GO

-- Which table do I get?
SELECT *
FROM TestSchema

-- Lets try as testlogin
SELECT *
FROM TestSchema

-- If I am DBO or db_owner then I will get the dbo copy
-- If I have a default schema that is NOT dbo, then I will get dbo
-- If I have a default schema that is dba then it will get dba.TestSchema

DBCC freeproccache

-- View the cached plans
SELECT *
FROM sys.dm_exec_cached_plans

SELECT *
FROM sys.syscacheobjects

-- Let's do a basic query
SELECT *
FROM  dbo.testtable

-- Let's do the same query, Kind Of
SELECT *
FROM dbo.TestTable

-- You will see queries that have their own plan because of 
-- Case Sensitivity




