USE DEMODB
GO

CREATE TABLE dbo.Accounts (
	AccountNumber NVARCHAR(100) NOT NULL,
	AcctName VARCHAR(50) NOT NULL,
	Address1 VARCHAR(25) NOT NULL,
	Address2 VARCHAR(25) NULL,
	City VARCHAR(25) NOT NULL,
	StateCode CHAR(2) NOT NULL,
	PostalCode VARCHAR(10) NOT NULL
)
GO


CREATE UNIQUE CLUSTERED INDEX PK_Accounts_AccountNumber ON dbo.Accounts (
	AccountNumber
)
GO

CREATE INDEX IX_Accounts_PostalCode ON dbo.Accounts (
	PostalCode
)
GO

SET STATISTICS IO ON

SELECT AccountNumber, City, PostalCode
FROM (SELECT * FROM dbo.Accounts) AS A
WHERE A.PostalCode = '19347'
/*
Table 'Accounts'. Scan count 9, logical reads 9092, physical reads 0, read-ahead reads 18, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
*/
WITH CTE 
AS (
	SELECT *
	FROM dbo.Accounts
)
SELECT AccountNumber, City, PostalCode
FROM CTE
WHERE PostalCode = '19347'

SELECT AccountNumber, City, PostalCode
FROM dbo.Accounts
WHERE AccountNumber IN (SELECT AccountNumber FROM dbo.Accounts WHERE PostalCode = '19347')

SELECT AccountNumber, City, PostalCode
FROM dbo.Accounts A
WHERE EXISTS (SELECT * FROM dbo.Accounts WHERE A.AccountNumber = AccountNumber AND PostalCode = '19347')

