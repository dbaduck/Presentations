
set statistics io on
/*
DROP INDEX IX_CreationYear ON dbo.Users
*/
/* functions in where clause */
SELECT	
	COUNT(*)
FROM dbo.Users
WHERE YEAR(CreationDate) = 2018

/* now let's remove the function */
DECLARE @yearbegin datetime = '2018-01-01', @yearend datetime = '2019-01-01'

SELECT 
	COUNT(*)
FROM dbo.Users
WHERE CreationDate >= @yearbegin AND CreationDate < @yearend

/* (1 row affected)
Table 'Users'. Scan count 5, logical reads 40447, physical reads 1, page server reads 0, read-ahead reads 40035, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
(1 row affected)
Table 'Users'. Scan count 5, logical reads 3715, physical reads 0, page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
(1 row affected)
Table 'Users'. Scan count 1, logical reads 2855, physical reads 0, page server reads 0, read-ahead reads 4, page server read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob page server reads 0, lob read-ahead reads 0, lob page server read-ahead reads 0.
*/
/* What could we do if this is a common query? */
ALTER TABLE dbo.Users ADD CreationYear AS YEAR(CreationDate) PERSISTED

/* Add an index because it is persisted */
CREATE INDEX IX_CreationYear ON dbo.Users ([CreationYear])

/* functions in where clause */
/* Now let's try again */
SELECT	
	COUNT(*)
FROM dbo.Users
WHERE YEAR(CreationDate) = 2018


/* IN, EXISTS, NOT EXISTS, NOT IN */
CREATE INDEX IX_Location ON dbo.Users (Location) WITH (SORT_IN_TEMPDB=ON)

SELECT 
	COUNT(*)
FROM dbo.Users
WHERE Location IN ('Philadelphia, PA', 'Austin, TX')

SELECT 
	COUNT(*)
FROM dbo.Users
WHERE Location IN (SELECT [Location] FROM dbo.tLocation)

SELECT 
	COUNT(*)
FROM dbo.Users U
WHERE [U].[Location] IN (SELECT Location FROM dbo.tLocation) -- T WHERE T.Location = U.Location)

SELECT COUNT(*)
FROM dbo.Users U
WHERE U.Location NOT IN (SELECT Location FROM dbo.tLocation)

SELECT COUNT(*)
FROM dbo.Users U
WHERE NOT EXISTS (SELECT 1 FROM dbo.tLocation T WHERE T.[Location] = U.[Location])


