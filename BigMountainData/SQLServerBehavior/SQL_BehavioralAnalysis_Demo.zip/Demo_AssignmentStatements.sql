DECLARE @id INT , @name VARCHAR(10)

SET @id = 1  -- Single assignment statement
SELECT @id = 1, @name = 'Ben'  -- Multiple assignment statement
SET @id = (SELECT 1 FROM dbo.TestTable) -- Just don't do this

-- multiple selects in a table

INSERT INTO dbo.TestTable ( field )
VALUES  ( 'Ben' ), ( 'George' ) 

SELECT *
FROM dbo.testtable

-- No WHERE clause and SQL gets to decide the order
-- because we know that the only way to get the data
-- back in a specific order, use ORDER BY
DECLARE @name VARCHAR(10)

SELECT @name = field
FROM dbo.TestTable

SELECT @name AS NAME

-- Gets the last row value
DECLARE @name VARCHAR(10)

SELECT field
FROM dbo.TestTable

SELECT @name = field
FROM dbo.TestTable
ORDER BY field DESC

SELECT @name AS NAME

-- Now let's be specific
DECLARE @name VARCHAR(10)

SELECT @name = field
FROM dbo.TestTable
WHERE field = 'Ben'

SELECT @name AS NAME

SELECT (SELECT field FROM dbo.TestTable)
FROM dbo.TestTable


