/*
Contact Information:
Ben Miller
ben@benmiller.net
@DBAduck

*/

-- If I am DBO or db_owner then I will get the dbo copy
-- If I have a default schema that is NOT dbo, then I will get dbo
-- If I have a default schema that is dba then it will get dba.TestSchema

DBCC freeproccache

-- View the cached plans
SELECT DISTINCT
	CP.bucketid, CP.cacheobjtype, CP.objtype, CP.usecounts, CO.sqlbytes, CP.size_in_bytes, CO.[sql]
FROM sys.syscacheobjects CO
INNER JOIN sys.dm_exec_cached_plans CP ON CO.bucketid = CP.bucketid

-- Let's do a basic query
SELECT *
FROM  dbo.testtable

-- Let's do the same query, Kind Of
SELECT *
FROM dbo.TestTable

-- You will see queries that have their own plan because of 
-- Case Sensitivity
SELECT *
FROM  dbo.TestTable

GO
-- View the cached plans
/*
SELECT bucketid, usecounts, size_in_bytes, cacheobjtype, objtype
FROM sys.dm_exec_cached_plans
*/

-- View the cached plans
SELECT 
	CP.bucketid, CP.cacheobjtype, CP.objtype, CP.usecounts, CO.sqlbytes, CP.size_in_bytes, CO.[sql]
FROM sys.syscacheobjects CO
INNER JOIN sys.dm_exec_cached_plans CP ON CO.bucketid = CP.bucketid
WHERE [sql] LIKE 'SELECT %'

