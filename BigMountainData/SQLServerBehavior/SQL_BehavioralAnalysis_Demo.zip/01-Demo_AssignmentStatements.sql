USE DemoDB
GO
/*
-- Used to Create the demo environment

CREATE TABLE dbo.TestTable (field VARCHAR(20))
GO
INSERT INTO dbo.TestTable ( field )
VALUES  ( 'Ben' ), ( 'George' ) 

CREATE TABLE dbo.TestTableUpdate (
	Name varchar(20), [Description] varchar(20)
)
INSERT INTO dbo.TestTableUpdate 
VALUES ('Ben', 'The Best'), ('George', 'Of the Jungle')

GO
*/
DECLARE @id INT , @name VARCHAR(10)

SET @id = 1  -- Single assignment statement - ANSI way
SELECT @id = 1, @name = 'Ben'  -- Multiple assignment statement
SET @id = (SELECT 1 FROM dbo.TestTable) -- ANSI way

-- multiple selects in a table


SELECT *
FROM dbo.testtable
GO
-- No WHERE clause and SQL gets to decide the order
-- because we know that the only way to get the data
-- back in a specific order, use ORDER BY
DECLARE @name VARCHAR(10)

SELECT @name = field
FROM dbo.TestTable

SELECT @name AS NAME
GO
-- Gets the last row value
DECLARE @name VARCHAR(10)

SELECT field
FROM dbo.TestTable
ORDER BY field DESC

SELECT @name = field
FROM dbo.TestTable
ORDER BY field DESC

SELECT @name AS NAME
GO
-- Now let's be specific
DECLARE @name VARCHAR(10)

SELECT @name = field
FROM dbo.TestTable
WHERE field = 'Ben'

SELECT @name AS NAME

SELECT (SELECT field FROM dbo.TestTable)
FROM dbo.TestTable

GO
-- ANSI way throws an error
DECLARE @name VARCHAR(10)

SELECT field
FROM dbo.TestTable

SET @name = (SELECT field FROM dbo.TestTable)

SELECT @name AS NAME

GO
/*
** Let's look at the update statement
** for assignment
** You will notice that the assignment
** happens BEFORE the actual update 
** of the table
** 
SELECT *
from dbo.TestTableUpdate

*/
DECLARE @Name varchar(20), @Description varchar(20)

UPDATE dbo.TestTableUpdate
SET @Name = Name,
	@Description = [Description],
	Name = 'Benji'
WHERE Name = 'Ben'

SELECT @Name as Name, @Description as [Description]

SELECT Name, [Description]
FROM dbo.TestTableUpdate

GO
